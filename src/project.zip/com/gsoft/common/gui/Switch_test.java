package com.gsoft.common.gui;

public class Switch_test {
	static void a() {
		switch(3) {
		
		case 1:
			break;
		case 2:
			return;
		case 0:break;
		default:
			return;
		}
		
		int a = 0;
		
		
	}
	
	static void b() {
		switch(-300) {
		case -100:break;
		case 0:
			break;
		case 300:
			return;
		default:
			return;
		}
		
		int b = 0;
		
		switch(3) {
		case 0:
			java.lang.String[] arr1Dim = new java.lang.String[2];
			java.lang.String element1Dim = arr1Dim[0];
			
			int[][] arr2Dim = new int[2][3];
			int element2Dim = arr2Dim[0][0];
			
			int[][][] arr3Dim = new int[2][3][1];
			int element3Dim = arr3Dim[0][0][0];
		case 1:
			break;
		case 2:
			return;
		default:
			return;
		}
		
		
		switch(3) {
		case 0:
			java.lang.String[] arr1Dim = new java.lang.String[2];
			java.lang.String element1Dim = arr1Dim[0];
			
			int[][] arr2Dim = new int[2][3];
			int element2Dim = arr2Dim[0][0];
			
			int[][][] arr3Dim = new int[2][3][1];
			int element3Dim = arr3Dim[0][0][0];
			
			arr1Dim = new java.lang.String[2];
			element1Dim = arr1Dim[0];
			
			arr2Dim = new int[2][3];
			element2Dim = arr2Dim[0][0];
			
			arr3Dim = new int[2][3][1];
			element3Dim = arr3Dim[0][0][0];
			
			arr1Dim = new java.lang.String[2];
			element1Dim = arr1Dim[0];
			
		
		case 1:
			break;
		case 2:
			return;
		default:
			return;
		}
		
	}
}