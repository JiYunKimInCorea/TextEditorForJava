package com.gsoft.common.java.util;

public class Properties {
	/**Creates an empty property list with no default values.*/
	Properties() {
		
	}
	/**Creates an empty property list with the specified defaults.*/
	Properties(Properties defaults) {
		
	}
	/**Searches for the property with the specified key in this property list.*/
	java.lang.String	getProperty(java.lang.String key) {
		return null;
	}
	
	
}