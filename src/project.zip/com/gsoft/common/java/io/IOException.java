package com.gsoft.common.java.io;

public class IOException extends java.lang.Exception
{
	/**Constructs an IOException with null as its error detail message.*/
	IOException() {
		
	}
	/**Constructs an IOException with the specified detail message.*/
	IOException(String message) {
		
	}
	/**Constructs an IOException with the specified detail message and cause.*/
	IOException(String message, Throwable cause) {
		
	}
	/**Constructs an IOException with the specified cause and a detail message of (cause==null ? null : cause.toString()) (which typically contains the class and detail message of cause).*/
	IOException(Throwable cause) {
		
	}
	
}