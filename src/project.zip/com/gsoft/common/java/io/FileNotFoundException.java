package com.gsoft.common.java.io;

public class FileNotFoundException extends IOException {
	/**Constructs a FileNotFoundException with null as its error detail message.*/
	FileNotFoundException() {
		
	}
	/**Constructs a FileNotFoundException with the specified detail message.*/
	FileNotFoundException(String s) {
		
	}
	
}