package com.gsoft.common.java.lang;

public class Error extends java.lang.Throwable {
	/**Constructs a new error with null as its detail message.*/
	Error() {
		
	}
	/**Constructs a new error with the specified detail message.*/
	Error(java.lang.String message) {
	 		
	}
	/**Constructs a new error with the specified detail message and cause.*/
	Error(java.lang.String message, java.lang.Throwable cause) {
		 
	}
	/**Constructs a new error with the specified detail message, cause, suppression enabled or disabled, and writable stack trace enabled or disabled.*/
	Error(java.lang.String message, java.lang.Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		
	}
	/**Constructs a new error with the specified cause and a detail message of (cause==null ? null : cause.toString()) (which typically contains the class and detail message of cause).*/
	Error(java.lang.Throwable cause) {
		
	}
	
}