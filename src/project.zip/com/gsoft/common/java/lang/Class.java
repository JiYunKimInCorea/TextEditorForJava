package com.gsoft.common.java.lang;

public class Class {

}