package com.gsoft.common.java.lang;

public class VirtualMachineError extends java.lang.Error {
	/**Constructs a VirtualMachineError with no detail message.*/
	VirtualMachineError() {
		
	}
	/**Constructs a VirtualMachineError with the specified detail message.*/
	VirtualMachineError(java.lang.String message) {
		
	}
	/**Constructs a VirtualMachineError with the specified detail message and cause.*/
	VirtualMachineError(java.lang.String message, java.lang.Throwable cause) {
		
	}
	/**Constructs an a VirtualMachineError with the specified cause and a detail message of (cause==null ? null : cause.toString()) (which typically contains the class and detail message of cause).*/
	VirtualMachineError(java.lang.Throwable cause) {
		
	}
	
}