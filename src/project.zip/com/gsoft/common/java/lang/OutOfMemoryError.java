package com.gsoft.common.java.lang;

public class OutOfMemoryError extends java.lang.VirtualMachineError {
	/**Constructs an OutOfMemoryError with no detail message.*/
	OutOfMemoryError() {
		
	}
	/**Constructs an OutOfMemoryError with the specified detail message.*/
	OutOfMemoryError(java.lang.String s) {
		
	}
	
	
}