package com.gsoft.common.java.lang;

public class Byte {
	public static byte BYTE_MIN_VALUE = -2^7;
	public static byte BYTE_MAX_VALUE = 2^7-1;
	
	byte parseByte(String str) {
		return 0;
	}
}