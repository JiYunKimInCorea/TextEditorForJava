package com.gsoft.common;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.util.Log;

import com.gsoft.DataTransfer.pipe.Pipe;
import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Code.CodeStringType;
import com.gsoft.common.Compiler_types.AccessModifier;
import com.gsoft.common.Compiler_types.Error;
import com.gsoft.common.Compiler_types.FindArrayInitializerParams;
import com.gsoft.common.Compiler_types.FindClassParams;
import com.gsoft.common.Compiler_types.FindControlBlockParams;
import com.gsoft.common.Compiler_types.FindSpecialBlockParams;
import com.gsoft.common.Compiler_types.FindFuncCallParam;
import com.gsoft.common.Compiler_types.FindFunctionParams;
import com.gsoft.common.Compiler_types.FindIndependentFuncCallParams;
import com.gsoft.common.Compiler_types.FindStatementParams;
import com.gsoft.common.Compiler_types.FindVarParams;
import com.gsoft.common.Compiler_types.FindVarUseParams;
import com.gsoft.common.Compiler_types.IndexForHighArray;
import com.gsoft.common.Compiler_types.Template;
import com.gsoft.common.Compiler_types.TypeCast;
import com.gsoft.common.Compiler_types.AccessModifier.AccessPermission;
import com.gsoft.common.Compiler_gui.TextView;
import com.gsoft.common.Encoding.EncodingFormatException;
import com.gsoft.common.IO.FileHelper;
import com.gsoft.common.IO.TextFormat;
import com.gsoft.common.PostFixConverter.CodeStringEx;
import com.gsoft.common.Util.Array;
import com.gsoft.common.Util.ArrayListCodeString;
import com.gsoft.common.Util.ArrayListIReset;
import com.gsoft.common.Util.ArrayListInt;
import com.gsoft.common.Util.ArrayListString;
import com.gsoft.common.Util.Hashtable_FullClassName;
import com.gsoft.common.Compiler_types.HighArray_CodeString;
import com.gsoft.common.Util.Stack;
import com.gsoft.common.Util.StackTracer;
import com.gsoft.common.gui.Control;

public class CompilerHelper {
	
	public static String curPackageName;
	public static String[] glistOfFilesInPackage;
	
	
	/** blank�� comment(comment�� ã�� ����)�� skip.
     *  reverse�� false�̸� startIndex()���� endIndex()���� �ε����� ������Ű�鼭 �˻�, �� ã���� endIndex()+1
	 *  reverse�� true�̸� endIndex()���� startIndex()���� �ε����� ���ҽ�Ű�鼭 �˻�, �� ã���� startIndex()-1*/
	public static int SkipBlank(CodeString src, boolean reverse, int startIndex, int endIndex)
    {
        int i;
        int resultIndex = -1;
        if (!reverse)
        {
            for (i = startIndex; i <= endIndex; i++)
            {
            	CodeChar c = src.charAt(i);
            	if (CompilerHelper.IsComment(c)) continue;
                if (CompilerHelper.IsBlank(c.c)) continue;
                break;
            }
            resultIndex = i;
        }
        else
        {
            for (i = endIndex; i >= startIndex; i--)
            {
            	CodeChar c = src.charAt(i);
            	if (CompilerHelper.IsComment(c)) continue;
                if (CompilerHelper.IsBlank(c.c)) continue;
                break;
            }
            /*if (i >= startIndex) resultIndex = i;
            else resultIndex = startIndex();*/
            resultIndex = i;
        }
        return resultIndex;
    }
	
	static public void showMessage(boolean replaceOrAdd, String message) {
		try{
			CommonGUI.loggingForMessageBox.setText(replaceOrAdd, message, false);
			CommonGUI.loggingForMessageBox.setHides(false);
			Control.view.postInvalidate();
		}catch(Exception e) {
			
		}
		
	}
	
	
	
	/**  Compiler.projectAlreadyLoaded�� true�̸� true�� ���� �׷��� ������ false�� �����Ѵ�.
	 * ���α׷� ���۽ÿ��� false�̹Ƿ� ������ false�� �����Ѵ�.
	 * decompressAndroidAndProjectSrc_sub()���� ������ Ǯ�� Compiler.projectAlreadyLoaded�� true�� �ȴ�.
	 * */
	public synchronized static boolean projectSrcAlreadyExists() {
		if (Compiler.projectAlreadyLoaded) return true;
		else return false;
	}
	
	/**  Compiler.gsoftAlreadyLoaded�� true�̸� true�� ���� �׷��� ������ false�� �����Ѵ�. 
	 * ���α׷� ���۽ÿ��� false�̹Ƿ� ������ false�� �����Ѵ�. 
	 * decompressAndroidAndProjectSrc_sub()���� ������ Ǯ�� Compiler.gsoftAlreadyLoaded�� true�� �ȴ�.
	 * */
	public synchronized static boolean gsoftAlreadyExists() {
		if (Compiler.gsoftAlreadyLoaded) return true;
		else return false;
	}
	
	/**  /mnt/sdcard/janeSoft/gsoft/android�� �����ϸ� true�� ���� �׷��� ������ false�� �����Ѵ�.*/
	public synchronized static boolean androidJavaLibAlreadyExists() {
		
		// /sdcard/gsoft/android
		//String destFilename =  Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "gsoft" + File.separator + "android";
		String destFilename = Control.pathAndroid_Final + File.separator + "android";
		File file = new File(destFilename);
		if (file.exists()) return true;
		else return false;
	}
	
	
	static class ThreadDecompressAndroidAndProjectSrc extends Thread {
		public void run() {
			
			decompressAndroidAndProjectSrc_sub();          				            				        				
			
		}
	}
	
	public static void decompressAndroidAndProjectSrc_sub() {
		boolean success = true;
		
			//  /sdcard/gsoft �� ���ϵ��� �ùٸ��� ������ /sdcard/gsoft�� /sdcard/gsoft.zip�� ��� �����
			// ���� ������ Ǭ��.
			//boolean r = IO.FileHelper.testFileWork();
		//if (androidJavaLibAlreadyExists()==false) {
		
		
		// ������ ������ ���� �����Ƿ� ����Ʈ�� �ٲ���´�.
		Control.pathAndroid = Control.pathAndroid_Final;
		CommonGUI_SettingsDialog.settings.pathAndroid = Control.pathAndroid_Final;
			
			// /sdcard/janeSoft/gsoft
			String destFilename =  Control.pathAndroid_Final;
			showMessage(true, "Deleting " + destFilename + ".. Please don't close and wait..");
			FileHelper.delete(destFilename);
			// /sdcard/gsoft.zip
			destFilename =  Control.pathJaneSoft + File.separator + "gsoft.zip";
			FileHelper.delete(destFilename);
			success = decompressAndroidJavaLib();
			
			if (success==false) {
				//Compiler.errors.add(new Error(compiler, 0,0,"Can't load android library."));
			}
			else {
				Compiler.androidJavaLibAlreadyLoaded = true;
				showMessage(false, "Decompress completed.");
				CommonGUI.loggingForMessageBox.setHides(true);
			}
		//}
		
		// ���α׷����۽ÿ��� /sdcard/janeSoft/project/com�� ����� �ٽ� ��ġ�Ѵ�.
		//if (projectSrcAlreadyExists()==false) {
			
			// /sdcard/janeSoft/project/com
			destFilename =  Control.pathProjectSrc + File.separator + "com";
			showMessage(true, "Deleting " + destFilename + ".. Please don't close and wait..");
			FileHelper.delete(destFilename);
			// /sdcard/janeSoft/project.zip
			destFilename =  Control.pathJaneSoft + File.separator + "project.zip";
			FileHelper.delete(destFilename);
			success = decompressProjectSrc();
			
			if (success==false) {
				//Compiler.errors.add(new Error(compiler, 0,0,"Can't load project files."));
			}
			else {
				Compiler.projectAlreadyLoaded = true;
				showMessage(false, "Decompress completed.");
				CommonGUI.loggingForMessageBox.setHides(true);
			}
		//}			
	
	}
	
	/** �����带 ����Ͽ� ������ ���������� �����Ͽ� ������ �����Ѵ�.
	 * slave �� ������ ���� ������ �������� �ʴ´�.*/
	public static void decompressAndroidAndProjectSrc() {
		if (CommonGUI_SettingsDialog.settings.usesChildCompilerProcess) {
			if (Control.isMasterOrSlave) {
				ThreadDecompressAndroidAndProjectSrc thread = new ThreadDecompressAndroidAndProjectSrc();
				thread.start();
			}
		}
		else {
			ThreadDecompressAndroidAndProjectSrc thread = new ThreadDecompressAndroidAndProjectSrc();
			thread.start();
		}
		
	}
	
	
	/** ���������� ��� asset\lib\project.zip ������ c:\TextEditorForJava\janeSoft\project.zip �� �Űܼ�
	 * c:\TextEditorForJava\janeSoft\project �� ������ �����ϰ� c:\TextEditorForJava\janeSoft\project.zip �� �����.
	 * @return ���������� �����ϸ� true �� �����Ѵ�.
	 */
	public static boolean decompressProjectSrc() {
		OutputStream os = null;
		InputStream is = null;
		
		byte[] buf = new byte[1000];
		
		String srcFilename = null;
		try{
			
			
			Context context = Control.view.getContext();
			AssetManager asset = context.getAssets();
			
			// asset�� �ִ� "gsoft.zip" ������ sdcard(��ü���:/sdcard/janeSoft/project.zip)�� �ű��.
			is = asset.open("lib"+File.separator+"project.zip");
			
			srcFilename = Control.pathJaneSoft + File.separator + "project.zip";
			File srcFile = new File(srcFilename);
			
			try {
				os = new FileOutputStream(srcFile);
				FileHelper.move(buf, is, os);
				}catch(Exception e) {
					return false;
				}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
		
		try {
			
			String destFilename =  Control.pathJaneSoft + File.separator + "project";
			
			// sdcard�� �Ű��� jar������ ������ Ǭ��.
			showMessage(true, "Decompressing project.zip.. Please don't close and wait..");
			boolean r = com.gsoft.common.Util.JarFile.decompress(srcFilename, destFilename);
			// /sdcard/janeSoft/project.zip ������ �����.
			FileHelper.delete(srcFilename);
			
			if (r) {
				Control.pathProjectSrc = destFilename;
				//Control.settingsDialog.editTextDirectory.setText(0, 
				//		new CodeString(Control.pathAndroid+File.separator,Color.BLACK));
				return true;
			}
			else {
				showMessage(true, "Failed decompressing project.zip....");
				Thread.sleep(4000);
				return false;
			}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
	}
	
	/**asset�� �ִ� gsoft.zip�� /sdcard/janeSoft/gsoft.zip�� �Űܼ� 
	 * /sdcard/janeSoft/gsoft�� ������ �����Ѵ�.
	 * ���������� ��� asset\lib\gsoft.zip ������ c:\TextEditorForJava\janeSoft\gsoft.zip �� �Űܼ�
	 * c:\TextEditorForJava\janeSoft\gsoft �� ������ �����ϰ� c:\TextEditorForJava\janeSoft\gsoft.zip �� �����.
	 * ������ ���������� Ǯ���� CommonGUI_SettingsDialog.settings.pathAndroid�� 
	 * c:\TextEditorForJava\janeSoft\gsoft ���� �ٲ�� �ȴ�.
	 * */
	public static boolean decompressAndroidJavaLib() {
		OutputStream os = null;
		InputStream is = null;
		
		byte[] buf = new byte[1000];
		
		String srcFilename = null;
		try{
			Context context = Control.view.getContext();
			AssetManager asset = context.getAssets();
			
			// asset�� �ִ� "AndroidJavaLib.zip" ������ sdcard(��ü���:/sdcard/gsoft.zip)�� �ű��.
			is = asset.open("lib"+File.separator+"gsoft.zip");
			
			srcFilename = Control.pathJaneSoft + File.separator + "gsoft.zip";
			File srcFile = new File(srcFilename);
			
			try {
				os = new FileOutputStream(srcFile);
				FileHelper.move(buf, is, os);
				}catch(Exception e) {
					return false;
				}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
		
		try {
			
			String destFilename =  Control.pathAndroid_Final;
					
			
			// sdcard�� �Ű��� jar������ ������ Ǭ��.
			showMessage(true, "Decompressing AndroidJavaLib.zip.. Please don't close and wait..");
			boolean r = com.gsoft.common.Util.JarFile.decompress(srcFilename, destFilename);
			// �Ű��� /sdcard/AndroidJavaLib.zip ������ �����.
			FileHelper.delete(srcFilename);
			
			if (r) {
				Control.pathAndroid = destFilename;
				if (CommonGUI_SettingsDialog.settingsDialog!=null) {
					CommonGUI_SettingsDialog.settingsDialog.editTextDirectory.setText(0, 				
						new CodeString(Control.pathAndroid+File.separator,Color.BLACK));
				}
				CommonGUI_SettingsDialog.settings.pathAndroid = destFilename;
				return true;
			}
			else {
				showMessage(true, "Failed decompressing AndroidJavaLib.zip....");
				Thread.sleep(4000);
				return false;
			}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
	}
	
	
	/**asset�� �ִ� gsoft.zip�� /sdcard/janeSoft/gsoft.zip�� �Űܼ� /sdcard/janeSoft/gsoft�� ������ �����Ѵ�.
	 * ���������� ��� asset\lib\gsoft.zip ������ c:\TextEditorForJava\janeSoft\gsoft.zip �� �Űܼ�
	 * c:\TextEditorForJava\janeSoft\gsoft �� ������ �����ϰ� c:\TextEditorForJava\janeSoft\gsoft.zip �� �����.
	 * @return ���������� �����ϸ� true �� �����Ѵ�.
	 */
	public static boolean decompressGSoft() {
		OutputStream os = null;
		InputStream is = null;
		
		byte[] buf = new byte[1000];
		
		String srcFilename = null;
		try{
			Context context = Control.view.getContext();
			AssetManager asset = context.getAssets();
			
			// asset�� �ִ� "gsoft.zip" ������ sdcard(��ü���:/sdcard/gsoft.zip)�� �ű��.
			is = asset.open("lib"+File.separator+"gsoft.zip");
			
			srcFilename = Control.pathJaneSoft + File.separator + "gsoft.zip";
			File srcFile = new File(srcFilename);
			
			try {
				os = new FileOutputStream(srcFile);
				FileHelper.move(buf, is, os);
				}catch(Exception e) {
					return false;
				}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
		
		try {
			
			// /sdcard/janeSoft/gsoft �� ������ �����Ѵ�.
			String destFilename1 =  Control.pathJaneSoft + File.separator + "gsoft";
			
			//String destFilename2 =  destFilename1 + File.separator + "com" + File.separator + "gsoft";
			
						
			
			// sdcard �� �Ű��� zip ������ ������ Ǭ��.
			showMessage(true, "Decompressing gsoft.zip.. Please don't close and wait..");
			boolean r = com.gsoft.common.Util.JarFile.decompress(srcFilename, destFilename1);
			// /sdcard/gsoft.zip ������ �����.
			FileHelper.delete(srcFilename);
			
			if (r) {
				Control.pathAndroid = destFilename1;
				if (CommonGUI_SettingsDialog.settingsDialog!=null) {
					CommonGUI_SettingsDialog.settingsDialog.editTextDirectory.setText(0, 
						new CodeString(Control.pathAndroid+File.separator,Color.BLACK));
				}
				return true;
			}
			else {
				showMessage(true, "Failed decompressing gsoft.zip....");
				Thread.sleep(4000);
				return false;
			}
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}
		finally {
			FileHelper.close(is);
			FileHelper.close(os);
		}
	}
	
	
	public static CodeString findComment(CodeString input, int textColor) throws Exception
    {
        int i, j;
        char[] result = new char[input.length()];
        int[] resultColors = new int[input.length()];
        byte[] resultTypes = new byte[input.length()]; 
        int count = 0;
        
        for (i = 0; i < input.length(); )
        {
        	// "/*"
            if (input.charAt(i).c == '/' && 
            		(i + 1 < input.length() && input.charAt(i + 1).c == '*'))
            {	
            	int startOfComment = i;
            	int endOfComment = input.length()-1;
            	boolean isDocuComment = false;            	
            	                	
                for (j = i+2; j < input.length(); j++)
                {
                	if (input.charAt(j).c == '*' && 
                			(j + 1 < input.length() && input.charAt(j + 1).c == '/'))
                    {
                		endOfComment = j + 1;
                		break;
                    }
                }
                
                // "/**" ��ť��Ʈ �ּ�,  /**/�� �ƴ�
                if (j<input.length() && i+2<input.length() && input.charAt(i+2).c=='*' && 
                		i+3<input.length() && input.charAt(i+3).c!='/') { 
                	isDocuComment = true;
                }
                
                int k;
                if (isDocuComment==false) {
                    for (k=startOfComment; k<=endOfComment; k++) {
                    	result[count] = input.charAt(k).c;
                        resultColors[count] = Compiler.commentColor;
                        resultTypes[count++] = CodeStringType.Comment;
                    }
                }
                else {
                	int a;
                	a=0;
                	for (k=startOfComment; k<=endOfComment; k++) {
                    	result[count] = input.charAt(k).c;
                        resultColors[count] = Compiler.docuCommentColor;
                        resultTypes[count++] = CodeStringType.DocuComment;
                    }
                }
                i = endOfComment + 1;
                
               
            }
        	// "//"
            else if (input.charAt(i).c == '/' && 
            		(i + 1 < input.length() && input.charAt(i + 1).c == '/'))
            {
            	for (j = i; j < input.length(); j++)
                {
                	result[count] = input.charAt(j).c;
                    resultColors[count] = Compiler.commentColor;
                    resultTypes[count++] = CodeStringType.Comment;
                    i = j+1;
                    
                    if (input.charAt(j).c == '\r' && 
                    		(j + 1 < input.length() && input.charAt(j + 1).c == '\n')) {
                    	// ������ '\n'�ֱ�
                    	result[count] = input.charAt(j+1).c;
                        resultColors[count] = Compiler.commentColor;
                        resultTypes[count++] = CodeStringType.Comment;
                        i = j+2;
                        //listOfComments.add(new Point(startOfComment, endOfComment));
                    	break;
                    }
                    else if (input.charAt(j).c == '\n') { // �̹� �־���
                    	//listOfComments.add(new Point(startOfComment, endOfComment));
                    	break;
                    }
                    
                }
            }
                        
            else	// �ּ��� �ƴ� ���
            {
            	result[count] = input.charAt(i).c;
                resultColors[count] = textColor;
                resultTypes[count++] = CodeStringType.Text;
                i++;
            }
        }
        result = Array.Resize(result, count);
        resultColors = Array.Resize(resultColors, count);
        resultTypes = Array.Resize(resultTypes, count);
        return new CodeString(result, resultColors, resultTypes);
    }
	
	
	
	public static ArrayListCodeString findComment(ArrayListCodeString src, int textColor) throws Exception
    {
        int i, j;
        ArrayListCodeString r = new ArrayListCodeString(src.count); 
        int count = 0;
        //listOfComments.resizeInc = 100;
        //listOfComments.reset();
        
        for (i = 0; i < src.count; )
        {
        	// "/*"
            if (CompilerHelper.IsConstant(src.getItem(i))==false && src.getItem(i).equals("/") && 
            		(i + 1 < src.count && CompilerHelper.IsConstant(src.getItem(i+1))==false && src.getItem(i + 1).equals("*")))
            {	
            	int startOfComment = i;
            	int endOfComment = src.count-1;
            	boolean isDocuComment = false;            	
            	                	
                for (j = i+2; j < src.count; j++)
                {
                	if (CompilerHelper.IsConstant(src.getItem(j))==false && src.getItem(j).equals("*") && 
                			(j + 1 < src.count && CompilerHelper.IsConstant(src.getItem(j+1))==false && src.getItem(j + 1).equals("/")))
                    {
                		endOfComment = j + 1;
                		break;
                    }
                }
                
                // "/**" ��ť��Ʈ �ּ�,  /**/�� �ƴ�
                if (j<src.count && i+2<src.count && CompilerHelper.IsConstant(src.getItem(i+2))==false && src.getItem(i+2).equals("*") && 
                		i+3<src.count && CompilerHelper.IsConstant(src.getItem(i+3))==false && src.getItem(i+3).equals("/")==false) { 
                	isDocuComment = true;
                }
                
                int k;
                if (isDocuComment==false) {
                    for (k=startOfComment; k<=endOfComment; k++) {
                    	/*result[count] = src.getItem(k).c;
                        resultColors[count] = Compiler.commentColor;
                        resultTypes[count++] = CodeStringType.Comment;*/
                    	CodeString str = src.getItem(k);
                    	str.setType(CodeStringType.Comment);
                    	str.setColor(Compiler.commentColor);
                    	r.add(str);
                    }
                }
                else {
                	int a;
                	a=0;
                	for (k=startOfComment; k<=endOfComment; k++) {
                    	/*result[count] = src.getItem(k).c;
                        resultColors[count] = Compiler.docuCommentColor;
                        resultTypes[count++] = CodeStringType.DocuComment;*/
                		CodeString str = src.getItem(k);
                    	str.setType(CodeStringType.DocuComment);
                    	str.setColor(Compiler.docuCommentColor);
                    	r.add(str);
                    }
                }
                i = endOfComment + 1;
                
               
            }
        	// "//"
            else if (CompilerHelper.IsConstant(src.getItem(i))==false && src.getItem(i).equals("/") && 
            		(i + 1 < src.count && CompilerHelper.IsConstant(src.getItem(i+1))==false && src.getItem(i + 1).equals("/")))
            {
            	for (j = i; j < src.count; j++)
                {
                	/*result[count] = src.getItem(j).c;
                    resultColors[count] = Compiler.commentColor;
                    resultTypes[count++] = CodeStringType.Comment;*/
            		if (src.getItem(j).equals("��Ƽ�ǵ���")) {
            			int a;
            			a=0;
            			a++;
            		}
            		CodeString str = src.getItem(j);
                	str.setType(CodeStringType.Comment);
                	str.setColor(Compiler.commentColor);
                	r.add(str);
                    i = j+1;
                    
                    if (src.getItem(j).equals("\r") && 
                    		(j + 1 < src.count && src.getItem(j + 1).equals("\n"))) {
                    	// ������ '\n'�ֱ�
                    	/*result[count] = src.getItem(j+1).c;
                        resultColors[count] = Compiler.commentColor;
                        resultTypes[count++] = CodeStringType.Comment;*/
                    	CodeString str2 = src.getItem(j+1);
                    	str2.setType(CodeStringType.Comment);
                    	str.setColor(Compiler.commentColor);
                    	r.add(str2);
                        i = j+2;
                        //listOfComments.add(new Point(startOfComment, endOfComment));
                    	break;
                    }
                    else if (src.getItem(j).equals("\n")) { // �̹� �־���
                    	//listOfComments.add(new Point(startOfComment, endOfComment));
                    	break;
                    }
                    
                }
            }
                        
            else	// �ּ��� �ƴ� ���
            {
            	if (CompilerHelper.IsConstant(src.getItem(i))) {
            		/*result[count] = src.getItem(i).c;
	                resultColors[count] = Compiler.keywordColor;
	                resultTypes[count++] = CodeStringType.Constant;*/
            		CodeString str = src.getItem(i);
                	str.setType(CodeStringType.Constant);
                	str.setColor(Compiler.keywordColor);
                	r.add(str);
	                i++;
            	}
            	else {
	            	/*result[count] = src.getItem(i).c;
	                resultColors[count] = textColor;
	                resultTypes[count++] = CodeStringType.Text;*/
            		CodeString str = src.getItem(i);
                	str.setType(CodeStringType.Text);
                	str.setColor(Compiler.textColor);
                	r.add(str);
	                i++;
            	}
            }
        }
        /*result = Array.Resize(result, count);
        resultColors = Array.Resize(resultColors, count);
        resultTypes = Array.Resize(resultTypes, count);
        return new CodeString(result, resultColors, resultTypes);*/
        return r;
    }
	
	/** ���丮���� parentClassNameFull�� childClassNameShort��� �̸��� 
	 * ����(inner) Ŭ������ �����ϴ��� Ȯ���Ѵ�.
	 * @param parentClassNameFull : java.lang.String, com.gsoft.common.gui.Control �� ���� �̸�
	 * @param childClassNameShort : String, Control�� ���� ª�� �̸�
	 * @param usesCache : glistOfFilesInPackage�� ����� ���ϸ���Ʈ�� packageName�� �ִ� ���ϸ���Ʈ�� ������ ���̶��
	 * usesCache�� true�϶� ���� ����Ʈ�� ��°� �ƴ϶� glistOfFilesInPackage�� ĳ�÷μ� ���ǰ� 
	 * usesCache�� false�̸� glistOfFilesInPackage�� ���� �����.
	 * */
	public static boolean hasInnerClass(String parentClassNameFull, String childClassNameShort, 
			boolean usesCache) {
		
		
		String[] listPackage = null;
		//packageName : com.gsoft.common.gui �� ���� �̸�, parentClassNameFull���� ��Ű���� �̸��̾�� �Ѵ�.
		// �� com.gsoft.common.Compiler.CodeString���� packageName�� com.gsoft.common�̴�. 
		String packageName = getPackageName(parentClassNameFull);
		if (packageName==null) return false;
		
		if (usesCache && glistOfFilesInPackage!=null && packageName.equals(curPackageName)) {
			listPackage = glistOfFilesInPackage;
		}
		else {
			String pathPackage =  packageName.replace(".", File.separator);
			String path = Control.pathAndroid + File.separator + pathPackage;
			File dirPackage = new File(path);
			listPackage = dirPackage.list();
			curPackageName = packageName;
			glistOfFilesInPackage = listPackage;
		}
		
		int i;
		/*for (i=0; i<packageName.length(); i++) {
			if (packageName.charAt(i)!=parentClassNameFull.charAt(i)) break;
		}*/
		
		// ��Ű���̸��� ������ parentClassName
		// parent�� com.gsoft.common.gui.Buttons.Button, child�� ButtonState�� ���
		// parentClassNameExceptPackageName�� Buttons.Button-> Buttons$Button
		// childClassNameWithDollar�� Buttons$Button$ButtonState.class �� �ȴ�.
		String parentClassNameExceptPackageName = 
			parentClassNameFull.substring(packageName.length()+1, parentClassNameFull.length());
		parentClassNameExceptPackageName = parentClassNameExceptPackageName.replace(".", "$");
		
		// ���丮�ȿ� �ִ� ���� �̸�
		String childClassNameWithDollar = parentClassNameExceptPackageName + "$" +  childClassNameShort + 
				".class";
		
		for (i=0; i<listPackage.length; i++) {
			if (listPackage[i].equals(childClassNameWithDollar)) return true;
		}
		
		return false;
	}
	
	
	static FindClassParams loadClassFromSrc(String fullName) {
		FileInputStream stream=null;
		BufferedInputStream bis=null;
		TextFormat format = TextFormat.MS949_Korean;
		com.gsoft.common.Compiler_types.Language lang = com.gsoft.common.Compiler_types.Language.Java;
		
		
		try {
			if (CompilerHelper.exists(Compiler.mlistOfAllClassesHashed,fullName)==false) {
				CommonGUI.loggingForMessageBox.setText(true, "loadClassFromSrc()-"+fullName, false);
				CommonGUI.loggingForMessageBox.setHides(false);
				Control.view.postInvalidate();
				
				Compiler compiler = new Compiler();
				String fullNameSlash = fullName.replace('.', File.separatorChar);
				String path = Control.pathProjectSrc + File.separator + fullNameSlash;
				
				String srcPath = CompilerHelper.getSourceFilePath(path);
				if (srcPath==null) {
					int a;
					a=0;
					a++;
					CompilerHelper.printMessage(CommonGUI.textViewLogBird, "can't find its source file : " + fullName);
				}
				srcPath += ".java";
				
				stream = new FileInputStream(srcPath);
				int bufferSize = (int) (FileHelper.getFileSize(srcPath)*IO.DefaultBufferSizeParam);
				bis = new BufferedInputStream(stream, bufferSize);
				
				String input = IO.readString(bis, format);
				//String input = IO.readString_UsingJavaNIO(srcPath, format);
				
				compiler.start2(input, lang, Compiler.backColor, srcPath);
				
				int i;
				for (i=0; i<compiler.mlistOfAllDefinedClasses.count; i++) {
					FindClassParams c = (FindClassParams) compiler.mlistOfAllDefinedClasses.getItem(i);
					if (c.name.equals(fullName)) return c;
				}
				FindClassParams r = (FindClassParams) compiler.mlistOfClass.list[0];
				return r;
			}
			else {
				FindClassParams r = CompilerHelper.getFindClassParams(Compiler.mlistOfAllClassesHashed, fullName);
				return r;
			}
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			Log.e("Load Error", e1.toString());
		}
		catch (EncodingFormatException e1) {
		}
		catch (Exception e1) {
			// TODO Auto-generated catch block
			Log.e("Load Error", e1.toString());
		}
		catch (OutOfMemoryError e1) {
			Log.e("Load Error", e1.toString());
		}
		finally {
			FileHelper.close(bis);
			FileHelper.close(stream);
		}
		return null;
	}
	
	/** fullName�� ������ Ŭ������ ĳ�ÿ� ��ϵǾ� �ִ����� ���� Ȯ���ϰ� ������
	 * �ڹ�(.java) �ҽ� ������ �о Ŭ������ �װ��� �ʵ�� �޼ҵ���� Ÿ���� ���ϰ� Ŭ���� ĳ�ÿ� ����ϰ� ��ӵ� �Ͽ�
	 * �� Ŭ������ FindClassParams�� �����Ѵ�.
	 * @param fullClassNameIncludingTemplateExceptArray : Ŭ������ ���ø� Ŭ������ ��� ���ø� Ÿ�� �̸��� �����ϰ� �迭�� �������� ���� Ŭ���� Ǯ �̸��̴�.
	 * 
	 * @return
	 */
	static FindClassParams loadClassFromSrc_onlyInterface(String fullNameIncludingTemplateExceptArray) {
		FileInputStream stream=null;
		BufferedInputStream bis=null;
		TextFormat format = TextFormat.MS949_Korean;
		com.gsoft.common.Compiler_types.Language lang = com.gsoft.common.Compiler_types.Language.Java;
		
		String fullName = fullNameIncludingTemplateExceptArray;
		if (fullName.equals("EditRichText.Character")) {
			int a;
			a=0;
			a++;
		}
		
		//Ŭ������ ���ø� Ŭ������ ��� ���ø� Ÿ�� �̸��� �����ϰ� �迭�� �������� ���� Ŭ���� Ǯ �̸��̴�.
		fullName = CompilerHelper.getArrayElementType(fullName);
		
		try {
			FindClassParams classParams = CompilerHelper.getFindClassParams(Compiler.mlistOfAllClassesHashed, fullName);
			
			if (classParams==null) {
				
				String fullNameExceptTemplate = CompilerHelper.getTemplateOriginalType(fullName);
				
				if (CompilerHelper.IsDefaultType(fullNameExceptTemplate)) {
					return null;
				}
				
				
				
				Compiler compiler = new Compiler();
				String fullNameSlash = fullNameExceptTemplate.replace('.', File.separatorChar);
				String path = Control.pathProjectSrc + File.separator + fullNameSlash;
				if (path.contains("EncodingFormatException")) {
					int a;
					a=0;
					a++;
				}
				String srcPath = CompilerHelper.getSourceFilePath(path);
				boolean addsNewly = false;
				
				if (srcPath==null) {
					// java.lang.String�� �ҽ������� �����Ƿ� ���� ���� �ҽ������� �����ؾ� �Ѵ�.
					// ���� ���� �ҽ������� ��ġ�� ã�´�.
					srcPath = CompilerHelper.getSourceFilePathAddingComGsoftCommon(fullNameExceptTemplate);
					
					String fullNameSlash2 = fullNameExceptTemplate.replace('.', File.separatorChar);
					String pathAddingComGsoftCommon = Control.pathProjectSrc + File.separator + "com" + File.separator + "gsoft" + File.separator +
							"common" + File.separator + fullNameSlash2 + ".java";
					
					if (Compiler.AlreadyLoadedClassFromSrc_onlyInterface(pathAddingComGsoftCommon)) {
						// Ŭ���� ĳ�ÿ� �ִ����� �̹� Ȯ�������Ƿ� null �� �����Ѵ�.
						// java.lang.Float�� Ŭ���� ���� �ε尡 �����ϰ� 
						// com.gsoft.common.java.lang ��Ű�� �ҽ����Ͽ��� ���ǵǾ� ������ �����Ƿ�
						// java.lang.Float�� �Ź� �ʿ��� ������ �ҽ������� �ε��� �ʿ䰡 ���� 
						// �̹� �ε��� �ҽ����� ����Ʈ���� �װ��� Ȯ���Ѵ�.
						return null;
					}
					if (Compiler.AlreadyLoadedClassFromSrc_onlyInterface_failed(pathAddingComGsoftCommon)) {
						// Ŭ���� ĳ�ÿ� �ִ����� �̹� Ȯ�������Ƿ� null �� �����Ѵ�.
						// java.lang.Short�� Ŭ���� ���� �ε尡 �����ϰ� 
						// com.gsoft.common.java.lang �ҽ����Ͽ��� ���ǵǾ� ������ �����Ƿ�
						// java.lang.Short �� �Ź� �ʿ��� ������ �ҽ������� �ε带 �õ��� �ʿ䰡 ���� 
						// �̹� �ε��� �ҽ����� ���� ����Ʈ���� �װ��� Ȯ���Ѵ�.
						return null;
					}
					if (srcPath==null) {
						int a;
						a=0;
						a++;
						// �ҽ������� �ε尡 ���������Ƿ� ��θ� �߰��Ѵ�.
						Compiler.mlistOfLoadClassFromSrc_onlyInterface_failed.add(pathAddingComGsoftCommon);
						Log.e("can't find its source file : ", fullName);
						CompilerHelper.printMessage(CommonGUI.textViewLogBird, "can't find its source file : " + fullName);
						return null;
					}
					addsNewly = true;
				}
				srcPath += ".java";
			
				Log.e("Trys to read its source file : ", srcPath);
				CompilerHelper.printMessage(CommonGUI.textViewLogBird, "Trys to read its source file : " + srcPath);
				
				
				CommonGUI.loggingForMessageBox.setText(true, "loadClassFromSrc_onlyInterface()-"+fullName, false);
				CommonGUI.loggingForMessageBox.setHides(false);
				Control.view.postInvalidate();
				
				//compiler.filename = srcPath;
				
				stream = new FileInputStream(srcPath);
				bis = new BufferedInputStream(stream);
				
				String input = IO.readString(bis, format);
				//String input = IO.readString_UsingJavaNIO(srcPath, format);
				
				compiler.start_onlyInterface(compiler, input, lang, fullName, srcPath, addsNewly);
				// �ҽ������� �ε������Ƿ� ��θ� �߰��Ѵ�.
				Compiler.mlistOfLoadClassFromSrc_onlyInterface.add(srcPath);
				
				// ���ҽ��� �����Ѵ�.
				input = null;
				
				int i;
				for (i=0; i<compiler.mlistOfAllDefinedClasses.count; i++) {
					FindClassParams c = (FindClassParams) compiler.mlistOfAllDefinedClasses.getItem(i);
					if (c.name.equals(fullNameExceptTemplate)) {
						if (c.template!=null) {
							Compiler.applyTypeNameToChangeToTemplateClass(compiler, c, fullName);
							return c;
						}
						return c;
					}
				}
				return null;
				//FindClassParams r = (FindClassParams) compiler.mlistOfClass.list[0]; 
				//return r;
			}
			else {		// ĳ�ÿ� ������		
				return classParams;
			}
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			Log.e("Load Error", e1.toString());
		}
		catch (EncodingFormatException e1) {
		}
		catch (Exception e1) {
			// TODO Auto-generated catch block
			Log.e("Load Error", e1.toString());
		}
		catch (OutOfMemoryError e1) {
			Log.e("Load Error", e1.toString());
		}
		finally {
			FileHelper.close(bis);
			FileHelper.close(stream);
		}
		return null;
	}
	
	/** Compiler�� checkTypeNameInFileList()���� ���ϸ���Ʈ�� ������ ������ �� Ŭ������ �����ϴ����� �˱����� ȣ���� �ȴ�.*/
	/*static FindClassParams loadClassFromSrc_onlyClass(String fullName) {
		FileInputStream stream=null;
		BufferedInputStream bis=null;
		TextFormat format = TextFormat.KSC;
		com.gsoft.common.Compiler.Language lang = com.gsoft.common.Compiler.Language.Java;
		
		
		try {
			// Ŭ���� ĳ�ø� Ȯ���Ѵ�.
			FindClassParams classParams = CompilerHelper.getFindClassParams(Compiler.mlistOfAllClassesHashed, fullName);
			
			if (classParams==null) { //Ŭ����ĳ�ÿ� ������
				CommonGUI.loggingForMessageBox.setText(true, "loadClassFromSrc_onlyClass()-"+fullName, false);
				CommonGUI.loggingForMessageBox.setHides(false);
				Control.view.postInvalidate();
				
				Compiler compiler = new Compiler();
				String fullNameSlash = fullName.replace('.', File.separatorChar);
				String path = Control.pathProjectSrc + File.separator + fullNameSlash;
				
				String srcPath = CompilerHelper.getSourceFilePath(path);
				srcPath += ".java";
				
				if (compiler.getShortName(fullName).equals("Array")) {
					int a;
					a=0;
					a++;
				}
				
				stream = new FileInputStream(srcPath);
				//int bufferSize = (int) (FileHelper.getFileSize(path, true)*IO.DefaultBufferSizeParam);
				bis = new BufferedInputStream(stream);
				
				String input = IO.readString(bis, format);
				//String input = IO.readString_UsingJavaNIO(srcPath, format);
				
				compiler.start_onlyClass(compiler, input, lang, fullName);
				
				int i;
				for (i=0; i<compiler.mlistOfAllDefinedClasses.count; i++) {
					FindClassParams c = (FindClassParams) compiler.mlistOfAllDefinedClasses.getItem(i);
					if (c.name.equals(fullName)) return c;
				}
				FindClassParams r = (FindClassParams) compiler.mlistOfClass.list[0]; 
				return r;
			}
			else {// ĳ�ÿ� ������
				 
				return classParams;
			}
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			Log.e("Load Error", e1.toString());
		}
		catch (EncodingFormatException e1) {
		}
		catch (Exception e1) {
			// TODO Auto-generated catch block
			Log.e("Load Error", e1.toString());
		}
		catch (OutOfMemoryError e1) {
			Log.e("Load Error", e1.toString());
		}
		finally {
			FileHelper.close(bis);
			FileHelper.close(stream);
		}
		return null;
	}*/
	
	/**@param  packageName : package com.gsoft.common.gui ���忡�� ��Ű��
	 * @return : java.lang.String, com.gsoft.common.gui.Control �� ���� �̸�
	 *  @param usesCache : glistOfFilesInPackage�� ����� ���ϸ���Ʈ�� packageName�� �ִ� ���ϸ���Ʈ�� ������ ���̶��
	 * usesCache�� true�϶� ���� ����Ʈ�� ��°� �ƴ϶� glistOfFilesInPackage�� ĳ�÷μ� ���ǰ� 
	 * usesCache�� false�̸� glistOfFilesInPackage�� ���� �����.*/
	public static String[] getSamePackageClasses(String packageName, boolean usesCache) {
		String pathPackage =  packageName.replace(".", File.separator);
		String path = Control.pathAndroid + File.separator + pathPackage;
		File dirPackage = new File(path);
		String[] listPackage = null;
		
		try{
		
		
		if (usesCache && glistOfFilesInPackage!=null && packageName.equals(curPackageName)) {
			listPackage = glistOfFilesInPackage;
		}
		else {				
			listPackage = dirPackage.list();
			curPackageName = packageName;
			glistOfFilesInPackage = listPackage; 
		}
		
		if (listPackage==null) return null;
		
		ArrayListString r = new ArrayListString(listPackage.length);
		int i;
		for (i=0; i<listPackage.length; i++) {
			String str = listPackage[i];
			if (str.contains("$")==false) {
				str = packageName + "." + str;
				int indexDotClass = str.indexOf(".class");
				if (indexDotClass!=-1) {
					str = str.substring(0, indexDotClass);
					r.add(str);
				}
			}
		}
		return r.getItems();
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return null;
		}
	}
	
	/** varUse�� Ÿ��ĳ��Ʈ�� �ؾ��ϴ��� Ȯ���Ѵ�. Ÿ��ĳ��Ʈ�� �ؾ��ϸ� full name Ÿ���� �����Ѵ�.
	 * (long)buffer.length���� varUse�� buffer�� ��� Ÿ��ĳ��Ʈ�� �ؼ��� �ȵȴ�.
	 	((java.lang.Object)buffer[i]).equals("(")���� varUse�� buffer�� ��� Ÿ��ĳ��Ʈ�� �ؾ��Ѵ�.
		(int)i+0 ���� varUse�� i�� ��� Ÿ��ĳ��Ʈ�� �ؾ��Ѵ�.
		(int)(a+(char)b)+c �� ���⿡�� �ذ��� �� ����.*/
	public static String mustTypeCast(Compiler compiler, HighArray_CodeString src, FindVarUseParams varUse) {
		boolean r = false;
		int i;
		int rightPair;
		// (long)buffer.length���� varUse�� buffer�� ��� Ÿ��ĳ��Ʈ�� �ؼ��� �ȵȴ�.
		// ((java.lang.Object)buffer[i]).equals("(")���� varUse�� buffer�� ��� Ÿ��ĳ��Ʈ�� �ؾ��Ѵ�.
		// (int)i+0 ���� varUse�� i�� ��� Ÿ��ĳ��Ʈ�� �ؾ��Ѵ�.
		for (i=varUse.index()+1; i<src.count; i++) {
			CodeString str = src.getItem(i);
			if (CompilerHelper.IsBlank(str) || CompilerHelper.IsComment(str)) continue;
			else if (str.equals("(")) {
				rightPair = CompilerHelper.CheckParenthesis(src, "(", ")", i, src.count-1, false);
				if (rightPair!=-1) i = rightPair;
			}
			else if (str.equals("[")) {
				rightPair = CompilerHelper.CheckParenthesis(src, "[", "]", i, src.count-1, false);
				if (rightPair!=-1) i = rightPair;
			}
			else if (str.equals(")")) {
				r = true;
				break;
			}
			else if (CompilerHelper.IsOperator(str)) { // ����� �ּ��� ������ ������
				r = true;
				break;
			}
			else if (str.equals(";") || str.equals(",")) {
				r = true;
				break;
			}
			else {  // '.'
				break;
			}
		}
		if (r==false) return null;
		r = false;
		
		int leftParent, rightParent;
		int typeIndex = -1;
		
		rightParent = compiler.SkipBlank(src, true, 0, varUse.index()-1);
		
		CodeString str = src.getItem(rightParent);
		
		if (str.equals(")")) {
			leftParent = CompilerHelper.CheckParenthesis(src, "(", ")", 0, rightParent, true);
			if (leftParent!=-1) {
				typeIndex = compiler.IsType(src, true, rightParent-1, null);
				if (typeIndex!=-1) {
					int tempLeftPair = compiler.SkipBlank(src, true, 0, typeIndex-1);
					if (tempLeftPair==leftParent) { // ��ȣ���� Ÿ��ĳ��Ʈ��
						if ( compiler.IsIdentifier( src.getItem(varUse.index()) ) ) { // (Ÿ��)id
							r = true;
						}
						/*else if (src.getItem(rightParent+1).equals("(")) { // (Ÿ��)(����)
							int rightParent2 = CompilerHelper.CheckParenthesis(src, "(", ")", rightParent+1, src.count-1, false);
							continue;
						}*/
					}
				}
			}
		}
		if (r) {
			return compiler.getFullNameType(compiler, typeIndex, rightParent-1);
		}
		return null;
		
	}
	
	/**���Ͽ� ����Ѵ�.*/
	public static void printStackTrace(File file, Exception e) {
		if (file==null) return;
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file);
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			CodeString stackTraceMessage = (new StackTracer(e)).getMessage();
			IO.writeString(bos, stackTraceMessage.str, TextFormat.UTF_8, false, true);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		finally {
			if (fos!=null)
				try {
					fos.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		}
	}
	/**LogBird�� ����Ѵ�.*/
	public static void printStackTrace(TextView tv, Exception e) {
		//boolean isSlave = false;
		if (CommonGUI_SettingsDialog.settings.usesChildCompilerProcess) {
			if (Control.isMasterOrSlave==false) {
				//isSlave = true;
				Socket socket = Pipe.socketToMain_client;
				try {
					OutputStream outputStream = socket.getOutputStream();
					//"logWrite"-numOfProcess(Control.numOfCurProcess)-log message
					// ������ ��������.
					IO.writeString(outputStream, "logWrite", TextFormat.UTF_8, true, true);
					int numOfProcess = Control.numOfCurProcess;
					IO.writeString(outputStream, numOfProcess+"", TextFormat.UTF_8, true, true);
					CodeString stackTraceMessage = (new StackTracer(e)).getMessage();
					IO.writeString(outputStream, stackTraceMessage.str, TextFormat.UTF_8, true, true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		
		if (tv==null) return;
		CodeString stackTraceMessage = (new StackTracer(e)).getMessage();
		tv.setText(tv.numOfLines, stackTraceMessage);
		tv.vScrollPosToLastPage();
		
	}
	/**LogBird�� ����Ѵ�.*/
	/*public static void printLog(TextView tv, String message) {
		if (tv==null) return;
		CodeString str = new CodeString(message, Compiler.textColor);
		tv.setText(tv.numOfLines, str);
		tv.vScrollPosToLastPage();
	}*/
	/**LogBird�� ����Ѵ�.*/
	public static void printMessage(TextView tv, String message) {
		//boolean isSlave = false;
		if (CommonGUI_SettingsDialog.settings.usesChildCompilerProcess) {
			if (Control.isMasterOrSlave==false) {
				//isSlave = true;
				Socket socket = Pipe.socketToMain_client;
				try {
					OutputStream outputStream = socket.getOutputStream();
					//"logWrite"-numOfProcess(Control.numOfCurProcess)-log message
					// ������ ��������.
					IO.writeString(outputStream, "logWrite", TextFormat.UTF_8, true, true);
					int numOfProcess = Control.numOfCurProcess;
					IO.writeString(outputStream, numOfProcess+"", TextFormat.UTF_8, true, true);
					IO.writeString(outputStream, message, TextFormat.UTF_8, true, true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		}
		//if (isSlave==false) {
			if (tv==null) return;
			CodeString strMessage = new CodeString(message, Color.RED);
			if (strMessage.str.contains("getClass")) {
				int a;
				a=0;
				a++;
			}
			tv.setText(tv.numOfLines, strMessage);
			tv.vScrollPosToLastPage();
			Control.view.invalidate();
		//}
	}
	
	static boolean isFileExist(String path) {
		File file = new File(path);
		if (file.exists()) return true;
		else return false;
		
	}
	
	/** �ش� Ŭ������ �����ڰ� ������ ����Ʈ �����ڸ� �����. enum���� �����Ѵ�.
	 * ����� �������̽��� ��쿡�� �߰��ȴ�. ������ �����Ѵ�.<br>
	 * this.setOnTouchListener(new View.OnTouchListener() {<br>
			public boolean onTouch(View v, MotionEvent event) {<br>
				return false;<br>
			}<br>
	   }<br>

*/
	public static void makeDefaultConstructorIfConstructorNotExist(Compiler compiler, FindClassParams classParams) {
		if (classParams.isEnum) return;
		// void setOnTouchListener(new View.onTouchListener() {});�̷� ��츦 �����Ѵ�.
		//if (classParams.isInterface) return;
		
		
		if (constructorExists(compiler, classParams)==false) {
			makeDefaultConstructor(compiler, classParams);
		}
	}
	
	/** classParams�� �����ڰ� �����ϴ����� Ȯ���Ѵ�.*/
	public static boolean constructorExists(Compiler compiler, FindClassParams classParams) {
		if (classParams.isEnum) return false;
		int i;
		String shortName = compiler.getShortName(classParams.name);
		for (i=0; i<classParams.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) classParams.listOfFunctionParams.getItem(i);
			if (func.name.equals(shortName)) return true;
		}
		return false;
	}
	
	/** classParams�� ����Ʈ �����ڸ� �����.*/
	public static void makeDefaultConstructor(Compiler compiler, FindClassParams classParams) {
		if (classParams.isEnum) return;
		FindFunctionParams func=null;
		String fullname = classParams.name;
		String name = compiler.getShortName(fullname);
		func = new FindFunctionParams(compiler, name);
		func.returnType = fullname;
		func.parent = classParams;
		func.isConstructor = true;
		int i;
		if (func.listOfFuncArgs==null) {
			func.listOfFuncArgs = new ArrayListIReset(0);
		}
		if (func.accessModifier==null){
			func.accessModifier = new AccessModifier(compiler, -1, -1);
		}
		func.accessModifier.accessPermission = AccessPermission.Public;
		func.isFake = true;
		classParams.listOfFunctionParams.add(func);
	}
	
	/**classParams �� static �ʵ尡 �ִ����� Ȯ���Ͽ� static �����ڸ� �ʿ���ϴ����� �����.*/
	public static boolean requiresStaticConstructor(FindClassParams classParams) {
		int i;
		for (i=0; i<classParams.listOfVariableParams.count; i++) {
			FindVarParams var = (FindVarParams) classParams.listOfVariableParams.getItem(i);
			if (var.accessModifier!=null && var.accessModifier.isStatic) return true;
		}
		return false;
	}
	
	/** classParams �� static �ʵ尡 ������ �װ͵��� �ʱ�ȭ�ϱ� ���� 
	 * static �����ڸ� �����.
	 * @param classParams
	 */
	public static FindFunctionParams makeStaticConstructor(FindClassParams classParams, String nameOfStaticConstructor) {
		// �̹� ��������� ����
		if (classParams.staticConstructorThatCompilerMakes!=null) 
			return classParams.staticConstructorThatCompilerMakes;
		
		FindFunctionParams func = new FindFunctionParams(classParams.compiler, nameOfStaticConstructor);
		func.accessModifier = new AccessModifier(classParams.compiler, -1, -1);
		func.accessModifier.isStatic = true;
		func.isConstructor = true;
		func.isConstructorThatInitializesStaticFields = true;
		func.parent = classParams;
		classParams.staticConstructorThatCompilerMakes = func;
		func.isFake = true;
		
		return func;
	}
	
	/**public ColorDialog(View owner, Rectangle bounds) {<br>
		super(owner, bounds);<br>
	}<br>
	constructor���� super() �Ǵ� super(xxx) ȣ���� �ִ����� Ȯ���Ѵ�.
	��¥ try-block�� �� �ڿ� �� �Լ��� ȣ���ϸ� super()�� ã�� �� ����.
	���� �� �Լ��� ��¥ try-block�� ���� ���� ȣ���ؾ� �������� ����� ���� �� �ִ�.
	*/
	public static boolean hasFuncCallToConstructorOfSuperClass(Compiler compiler, 
			FindFunctionParams constructor) {
		FindStatementParams statement = null;
		if (constructor.listOfStatements.count>0) {
			statement = (FindStatementParams) constructor.listOfStatements.getItem(0);
		}
		else {
			return false;
		}
		
		if (statement.isFake==false) {
			int indexSuper = 
					compiler.SkipBlank(compiler.mBuffer, false, statement.startIndex(), compiler.mBuffer.count-1);
			if (compiler.mBuffer.getItem(indexSuper).equals("super")==false)
				return false;
			//int indexInListOfVarUses = 
					//compiler.getIndexInmListOfAllVarUses2(constructor.listOfAllVarUsesForFunc, 0, indexSuper, true);
			FindVarUseParams varUseSuper =
					compiler.getVarUseWithIndex(((FindClassParams)constructor.parent).listOfAllVarUsesForFuncHashed, 
							"super", indexSuper);
			//FindVarUseParams varUseSuper = constructor.listOfAllVarUsesForFunc.getItem(indexInListOfVarUses);
			try{
			if (varUseSuper!=null && /*varUseSuper.name!=null && varUseSuper.name.equals("super") &&*/ 
				varUseSuper.listOfFuncCallParams!=null && varUseSuper.listOfFuncCallParams.count>=0)
				return true;
			}catch(Exception e) {
				e.printStackTrace();
				int a;
				a=0;
				a++;
			}
		}
		else {
			// statement�� super();�̴�.
			if (statement instanceof FindIndependentFuncCallParams)
				return true;
		}
		return false;
	}
	
	/**public ColorDialog(View owner, Rectangle bounds) {<br>
			super(owner, bounds);<br>
	   }<br>
	   constructor���� super() �Ǵ� super(xxx) ȣ���� �ִ����� Ȯ���� �� 
	   ������ ����Ʈ ����Ŭ���� ������ ȣ��, super()�� �����.
	   ��¥ try-catch������ ��������� ȣ���ؾ� �Ѵ�.
	*/
	public static void makeFuncCallToDefaultConstructorOfSuperClass(Compiler compiler, 
			FindFunctionParams constructor) {
		boolean hasSuperCall = hasFuncCallToConstructorOfSuperClass(compiler, constructor);
		if (hasSuperCall==false) {
			FindIndependentFuncCallParams superCall = new FindIndependentFuncCallParams(compiler, -1, -1);
			constructor.listOfStatements.insert(0, superCall);
			superCall.isFake = true;
			
			FindVarUseParams varUseSuper = new FindVarUseParams(null);
			if (constructor.findBlockParams==null) {
				int a;
				a=0;
				a++;
			}
			varUseSuper.index = null
					/*IndexForHighArray.indexRelative(varUseSuper, compiler.mBuffer, constructor.findBlockParams.startIndex()+1)*/;
			varUseSuper.name = "super";
			varUseSuper.originName = "super";
			if (varUseSuper.listOfFuncCallParams==null) {
				varUseSuper.listOfFuncCallParams = new ArrayListIReset(1);
			}
			varUseSuper.classToDefineThisVarUse = (FindClassParams) constructor.parent;
			varUseSuper.funcToDefineThisVarUse = constructor;
			varUseSuper.isFake = true;
			
			compiler.mlistOfAllVarUses.insert(varUseSuper.index(), varUseSuper);
			
		}
		
	}
	
	static int indexOf(String str, int startIndex, char c) {
		int i;
		for (i=startIndex; i<str.length(); i++) {
			if (str.charAt(i)==c) {
				return i;
			}
		}
		return -1;
	}
	
	static int indexOf(String str, int startIndex, char c, boolean reverse) {
		if (reverse) {
			int i;
			for (i=startIndex; i>=0; i--) {
				if (str.charAt(i)==c) {
					return i;
				}
			}
			return -1;
		}
		return -1;
	}
	
	/** <summary>startIndex���� endIndex���� 
     * '{,(,['(charOfLeftPair)�� '},),]'(charOfRightPair)�� ���ÿ� �ְ� ���� ���� �´��� Ȯ���Ѵ�. 
    * block������ Ȯ���ؾ� ��Ȯ�� pair�� ã�� �� �ִ�. 
    * �ٽø��� ��ȣ������ ��ĥ �� �ִ�. ó�� ���� ��ȣ�� ���� �ε����� �����Ѵ�. 
    * reverse�� false�̸� startIndex���� endIndex���� �ε����� ������Ű�鼭 �˻�, �� ã���� -1�� ����
	 *  reverse�� true�̸� endIndex���� startIndex���� �ε����� ���ҽ�Ű�鼭 �˻�, �� ã���� -1�� ����
	 *  </summary>
	 *  @param startIndex : isReverse�� false�� ��� charOfLeftPair�� �ε������� �Ѵ�.
	 *  �׷��� ��ȣ�� ���� �´´�.
	 *  @param endIndex :	isReverse�� true�� ��� charOfRightPair�� �ε������� �Ѵ�. 
	 *  �׷��� ��ȣ�� ���� �´´�.*/
    public static int CheckParenthesis(HighArray_CodeString src, 
    		String charOfLeftPair, String charOfRightPair, 
    		int startIndex, int endIndex, boolean isReverse) 
    {
        int i;
        
        Stack<String> stack = new Stack<String>();
        if (isReverse==false) {
        	if (startIndex<0) return -1;
	        for (i = startIndex; i <= endIndex; i++)
	        {
	        	CodeString str = src.getItem(i);
	        	if (CompilerHelper.IsComment(str)) continue;
	        	if (CompilerHelper.IsConstant(str)) continue;
	            if (str.equals(charOfLeftPair))
	            { 
	                stack.Push(charOfLeftPair);
	            }
	            else if (str.equals(charOfRightPair))
	            {
	            	if (stack.len==2) { 
	            		// �ֻ��� class����(1)�ȿ��� �ι�° ����(�Լ� Ȥ�� Ŭ����)�� �ݴ� } 
	            		int a;
	            		a=0;
	            		a++;
	            	}
	            	if (stack.len>0)
	                {
	            		stack.Pop();
	            		if (stack.len==0) {
	            			return i;
	            		}
	                }
	            }            
	        } // for
        }
        else {
        	for (i = endIndex; i >= startIndex; i--)
	        {
	        	CodeString str = src.getItem(i);
	        	if (CompilerHelper.IsComment(str)) continue;
	        	if (CompilerHelper.IsConstant(str)) continue;
	            if (str.equals(charOfRightPair))
	            { 
	                stack.Push(charOfRightPair);
	            }
	            else if (str.equals(charOfLeftPair))
	            {
	            	if (stack.len==2) { 
	            		// �ֻ��� class����(1)�ȿ��� �ι�° ����(�Լ� Ȥ�� Ŭ����)�� �ݴ� } 
	            		int a;
	            		a=0;
	            		a++;
	            	}
	            	if (stack.len>0)
	                {
	            		stack.Pop();
	            		if (stack.len==0) {
	            			return i;
	            		}
	                }
	            }            
	        } // for
        }
        
        return -1;
    }
    
    /** <summary>startIndex���� endIndex���� 
     * '{,(,['(charOfLeftPair)�� '},),]'(charOfRightPair)�� ���ÿ� �ְ� ���� ���� �´��� Ȯ���Ѵ�. 
    * block������ Ȯ���ؾ� ��Ȯ�� pair�� ã�� �� �ִ�. 
    * �ٽø��� ��ȣ������ ��ĥ �� �ִ�. ó�� ���� ��ȣ�� ���� �ε����� �����Ѵ�. 
    * reverse�� false�̸� startIndex���� endIndex���� �ε����� ������Ű�鼭 �˻�, �� ã���� -1�� ����
	 *  reverse�� true�̸� endIndex���� startIndex���� �ε����� ���ҽ�Ű�鼭 �˻�, �� ã���� -1�� ����
	 *  ���ǻ��� : ��Ʈ���� �ּ��� �־�� �ȵȴ�.
	 *  </summary>*/
    public static int CheckParenthesis(String str, 
    		String charOfLeftPair, String charOfRightPair, 
    		int startIndex, int endIndex, boolean isReverse) 
    {
        int i;
        
        Stack<String> stack = new Stack<String>();
        if (isReverse==false) {
	        for (i = startIndex; i <= endIndex; i++)
	        {
	        	char c = str.charAt(i);
	        	//if (CompilerHelper.IsComment(c)) continue;
	        	//if (CompilerHelper.IsBlank(c.c)) continue;
	            if (c==charOfLeftPair.charAt(0))
	            { 
	                stack.Push(charOfLeftPair);
	            }
	            else if (c==charOfRightPair.charAt(0))
	            {
	            	if (stack.len==2) { 
	            		// �ֻ��� class����(1)�ȿ��� �ι�° ����(�Լ� Ȥ�� Ŭ����)�� �ݴ� } 
	            		int a;
	            		a=0;
	            		a++;
	            	}
	            	if (stack.len>0)
	                {
	            		stack.Pop();
	            		if (stack.len==0) {
	            			return i;
	            		}
	                }
	            }            
	        } // for
        }
        else {
        	for (i = endIndex; i >= startIndex; i--)
	        {
	        	char c = str.charAt(i);
	        	//if (CompilerHelper.IsComment(c)) continue;
	        	//if (CompilerHelper.IsBlank(c.c)) continue;
	            if (c==charOfRightPair.charAt(0))
	            { 
	                stack.Push(charOfRightPair);
	            }
	            else if (c==charOfLeftPair.charAt(0))
	            {
	            	if (stack.len==2) { 
	            		// �ֻ��� class����(1)�ȿ��� �ι�° ����(�Լ� Ȥ�� Ŭ����)�� �ݴ� } 
	            		int a;
	            		a=0;
	            		a++;
	            	}
	            	if (stack.len>0)
	                {
	            		stack.Pop();
	            		if (stack.len==0) {
	            			return i;
	            		}
	                }
	            }            
	        } // for
        }
        
        return -1;
    }
    
    /** str�� int[], buffer[i]���� ��� int, buffer�� �ε����� �����Ѵ�. Ʋ�� �迭�� ��� -1�� ����*/
    public static int getArrayNameIndex(Compiler compiler, HighArray_CodeString src, int index) {
		int r = -1;
		int i;
		int leftPair;
		if (index<0) return -1;
		if (src.getItem(index).equals("]")==false) return -1;
		for (i=index; i>=0; i--) {
			if (src.getItem(i).equals("]")) {
				leftPair = CheckParenthesis(src, "[", "]", 0, i, true);
				if (leftPair!=-1) {
					i = leftPair;
				}
				else {
					Compiler.errors.add(new Error(compiler, i, i, "] not paired."));
					return -1;
				}
			}
			else break;
		}
		r = i;
		return r;
	}
    
    /** �迭�������� �ƴϸ� �迭Ÿ�Լ������� Ȯ���Ѵ�. 
     * @param startIndexArraySubscription : [�� �ε���
     * @param endIndexArraySubscription : ]�� �ε��� ���� �����̳� �ּ� ���԰���*/
    public static boolean isArrayElement(Compiler compiler, int startIndexArraySubscription, 
    		int endIndexArraySubscription) {
    	for (int i=startIndexArraySubscription; i<=endIndexArraySubscription; i++) {
    		CodeString str = compiler.mBuffer.getItem(i);
    		if (IsBlank(str) || IsComment(str)) continue;
    		else if (compiler.IsIdentifier(str) || CompilerHelper.IsNumber2(str)!=0) return true;
    		else if (IsConstant(str)) return true;
    	}
		return false;
    	
    	
    }
    
    /** int[] a;���� b=a[1];���� fullnameOfArrayType�� int[]�̰� varUse�� a[1]�̸� int�� �����Ѵ�.
     * Ʋ���� errors�� ������ ����Ѵ�.*/
    public static String getTypeOfArrayElement(Compiler compiler, String fullnameOfArrayType, FindVarUseParams varUse) {
    	int dimension1 = CompilerHelper.getArrayDimension(compiler, fullnameOfArrayType);
    	int dimension2 = CompilerHelper.getArrayDimension(compiler, varUse.name);
    	if (dimension1!=dimension2) {
    		Compiler.errors.add(new Error(compiler, varUse.index(), varUse.index(), "Array dimension invalid. : "+fullnameOfArrayType+"-"+varUse.name));
    	}
    	else {
    		String r = CompilerHelper.getArrayElementType(fullnameOfArrayType);
    		return r;
    	}
		return null;
    	
    }
    
    public static int getMaxArrayLengthInCurDepth(FindArrayInitializerParams topArray, 
			FindArrayInitializerParams array) {
    	ArrayListInt listOfLength = topArray.listOfLength;
    	int curDepth = array.depth;
    	return listOfLength.getItem(curDepth);
    	
    }
	
	/** str�� int[], buffer[i]�� ��� ���� 1�� �����Ѵ�. �迭�� �ƴϸ� 0�� ����*/
	public static int getArrayDimension(Compiler compiler, String str) {
		int dimensionOfArray = 0;
		int i;
		int leftPair;
		if (str==null) {
			int a;
			a=0;
			a++;
		}
		if (str.length()<1) return 0;
		if (str.charAt(str.length()-1)!=']') return 0;
		for (i=str.length()-1; i>=0; i--) {
			if (str.charAt(i)==']') {
				leftPair = CheckParenthesis(str, "[", "]", 0, i, true);
				if (leftPair!=-1) {
					i = leftPair;
				}
				else {
					Compiler.errors.add(new Error(compiler, i, i, "] not paired."));
					return 0;
				}
				dimensionOfArray++;
			}
			else break;
		}
		return dimensionOfArray;
	}
	
	/** str�� int[]�� ��� ÷�ڸ� �� ���� Ÿ�� int�� �����Ѵ�. str�� Ÿ���̸��̾�� �Ѵ�. 
	 * int[10][10]�� ���� �迭���Ҵ� int�� �����Ѵ�. str�� �ּ��̳� �ֳ����̼ǵ��� �־�� �ȵȴ�.*/
	public static String getArrayElementType(String str) {
		if (str.length()<=0) return null;
		if (str==null) return null;
		int indexRightPair = str.length()-1;
		int indexLefttPair;
		int typeStartIndex=0, typeEndIndex;
		int index = indexRightPair;
		char c;
		while (true) {
			if (index==-1) {
				int a;
				a=0;
				a++;
			}
			c = str.charAt(index);
			if (c==']') {
				indexLefttPair = CheckParenthesis(str, "[", "]", 0, indexRightPair, true);
				if (indexLefttPair==-1) { // error
					return null;
				}
				index = indexLefttPair-1;
				indexRightPair = index;
			}
			else {
				typeEndIndex = index;
				break;
			}
		}
		String type = str.substring(typeStartIndex, typeEndIndex+1);
		return type;
		
		/* while (true) {
			if (str.contains("[]")) {
				str = str.substring(0, str.length()-2); // ������ []�� ����
			}
			else break;
		}
		return str;*/
	}
	
	/** str�� Ÿ���̸��̾�� �Ѵ�. str�� int�̰� dimension�� 1�� ��� int[]�� �����Ѵ�.*/
	public static String getArrayType(String str, int dimension) {
		int i;
		String r = str;
		for (i=0; i<dimension; i++) {
			r += "[]";
		}
		return r;
	}
	
	/*public static String getTemplateOriginalType(ArrayListCodeString src, String template, 
			int startIndex, int endIndex) {
		boolean isTemplate = false;
		int indexTemplateLeftPair = template.indexOf("<");
		int indexTemplateRightPair = -1;
		
		String strTemplate = "";
		if (indexTemplateLeftPair!=-1) {
			int indexTemplateLeftPairInmBuffer = Skip(src, false, "<", startIndex, endIndex);
			int indexTemplateRightPairInmBuffer = 
					CompilerHelper.CheckParenthesis(src, "<", ">", indexTemplateLeftPairInmBuffer, endIndex, false);
			
			indexTemplateRightPair = 
				CompilerHelper.CheckParenthesis(template, "<", ">", indexTemplateLeftPair, template.length()-1, false);
			isTemplate = true;
			if (indexTemplateRightPair!=-1) {
				// Stack<Object>���� <Object>�κ��� ���Ѵ�. 
				//strTemplate = str.substring(indexTemplateLeftPair, indexTemplateRightPair+1);
				strTemplate = 
						"<"+getFullNameType(src, indexTemplateLeftPairInmBuffer+1, indexTemplateRightPairInmBuffer-1)+">";
				// ������ Stack�κ�
				template = template.substring(0, indexTemplateLeftPair);
				
			}
		}
		
		int i;
		String r = typeName + templateStr;
		return r;
	}*/
	
	/** mlistOfAllTemplates���� leftPair�� ���ø��� ã�� �����Ѵ�. rightPair�� �ƹ� ���̳� �־ �ȴ�.*/
	public static Template getTemplate(Compiler compiler, int leftPair, int rightPair) {
		ArrayListIReset list = compiler.mlistOfAllTemplates;
		int i;
		for (i=0; i<list.count; i++) {
			Template t = (Template) list.getItem(i);
			if (t.indexLeftPair()==leftPair/* && t.indexRightPair==rightPair*/)
				return t;
		}
		return null;
	}
	
	/** fullname�� ���ø��̸� ���ø� ��ȣ �ȿ� �ִ� Ÿ���� �����Ѵ�.*/
	public static String getTemplateTypeInPair(String fullname) {
		int indexTemplateLeftPair = fullname.indexOf("<");
		
		String r = null;
		if (indexTemplateLeftPair!=-1) {			
			int indexTemplateRightPair = 
					CompilerHelper.CheckParenthesis(fullname, "<", ">", 
							indexTemplateLeftPair, fullname.length()-1, false);
			if (indexTemplateRightPair==-1) return null;
			else {
				r = fullname.substring(indexTemplateLeftPair+1, indexTemplateRightPair);
				return r;
			}
		}
		return fullname;
	}
	
	/** fullname�� ���ø��̸� ���ø��� ������ ���� Ÿ���̸��� �����Ѵ�.*/
	public static String getTemplateOriginalType(String fullname) {
		if (fullname==null) {
			int a;
			a=0;
			a++;
			return null;
		}
		int indexTemplateLeftPair = fullname.indexOf("<");
		
		String r = null;
		if (indexTemplateLeftPair!=-1) {
			r = fullname.substring(0, indexTemplateLeftPair);
			return r;
		}
		return fullname;
	}
	
	public static String getTemplateType(String typeName, String templateStr) {
		int i;
		String r = typeName + templateStr;
		return r;
	}
	
	/**@param fullClassName : java.lang.String�� ���� �̸�*/
	static String getPackageName(String fullClassName) {
		String pathPackage =  fullClassName.replace(".", File.separator);
		int indexSeparator=0;
		String path = pathPackage;
		String r = null;
		
		while (true) {
			indexSeparator = indexOf(pathPackage, indexSeparator+1, File.separatorChar);
			if (indexSeparator==-1) {
				break;
			}
			path = pathPackage.substring(0, indexSeparator);
			String fullPath = Control.pathAndroid + File.separator + path;
			File dirPackage = new File(fullPath);
			if (dirPackage.exists()==false) {
				break;
			}
			else {
				r = path;
			}
		}
		if (r!=null) {
			r = r.replace(File.separator, ".");
		}
		return r;
	}
	
	/** str�� ���丮�����ڴ� File.separatorChar�̴�.*/
	static boolean isFile(String str) {
		File file = new File(str);
		if (file.isFile()) return true;
		return false;
	}
	
	/** fullNameExceptTemplate ��� �ҽ������� ã�� �� ������ 
	 * "com.gsoft.common."�� fullNameExceptTemplate �տ� �ٿ��� �ҽ� ������ 
	 * �����ϴ��� Ȯ���Ѵ�.
	 * @param fullNameExceptTemplate : ������� java.lang.String
	 * @return
	 */
	static String getSourceFilePathAddingComGsoftCommon(String fullNameExceptTemplate) {
		String fullNameSlash = fullNameExceptTemplate.replace('.', File.separatorChar);
		String path = Control.pathProjectSrc + File.separator + "com" + File.separator + "gsoft" + File.separator +
				"common" + File.separator + fullNameSlash;
		
		String r = getSourceFilePath(path);
		return r;
	}
	
	/** /mnt/sdcard/project_src/com/gsoft/common/gui/control/container���� 
	 * �ҽ����Ϻκ��� /mnt/sdcard/project_src/com/gsoft/common/gui/control�̴�. 
	 * path���� �ڿ� Ȯ���ڴ� ������ �ʴ´�.*/ 
	static String getSourceFilePath(String path) {
		// /mnt/sdcard/project_src/com/gsoft/common/gui�� ��´�.
		String dir = getDirectory(path);
		if (dir==null) return null;
		int indexStart = dir.length()+1; ///mnt/sdcard/project_src/com/gsoft/common/gui/�� ����
		int indexSrcFile = path.indexOf(File.separator, indexStart);
		String r;
		if (indexSrcFile!=-1) {			
			r = path.substring(0, indexSrcFile);
			//  /mnt/sdcard/project_src/com/gsoft/common/gui/control
		}
		else {
			r = path;
		}
		
		String rIncludeingJava = r + ".java";
		
		if (isFileExist(rIncludeingJava)) {
			return r; 
		}
		// /mnt/sdcard/project/com/gsoft/common/Encoding/EncodingFormatException.java�� �������� �ʴ´�.
		
		int separator = r.length();
		String javaPath, javaPathExceptExt;
		// ���࿡ /mnt/sdcard/project/com/gsoft/common/Encoding/EncodingFormatException/InnerClass2��
		// /mnt/sdcard/project/com/gsoft/common/Encoding.java��� �ҽ� ������ �ִٸ� 
		// ������ ���ؼ� �� �ҽ������� �����ϴ����� Ȯ���ؾ� �Ѵ�.
		while (true) {
			separator = indexOf(r, separator-1, File.separatorChar, true);
			if (separator==-1) return null;
			javaPathExceptExt = r.substring(0, separator);
			javaPath = javaPathExceptExt + ".java";
			
			if (isFileExist(javaPath)) {
				return javaPathExceptExt; 
			}
			
		}
		
		
	}
	
	/** str�� ���丮�����ڴ� File.separatorChar�̴�.*/
	static boolean isDirectory(String str) {
		File file = new File(str);
		if (file.isDirectory()) return true;
		return false;
	}
	
	/** /mnt/sdcard/gsoft/com/gsoft/common/Util���� ���丮�κ��� /mnt/sdcard/gsoft/com/gsoft/common�̴�.*/ 
	static String getDirectory(String path) {
		String originalPath = new String(path);
		int separator=0;
		int separatorOld=0;
		boolean r=false;
		
		r = isDirectory(path);
		if (r) {
			return path;
		}
		
		while (separator!=-1) {
			separator = indexOf(originalPath, separator, File.separatorChar);
			if (separator==-1) {
				r = isDirectory(originalPath);
				if (r) return originalPath;
				else {
					String dir = originalPath.substring(0, separatorOld);
					return dir;
				}
			}
			path = originalPath.substring(0, separator+1);
			r = isDirectory(path);
			if (r) {
				separatorOld = separator;
			}
			else {
				String dir = originalPath.substring(0, separatorOld);
				return dir;
			}
			separator++;
		}
		return null;
	}
	
	/**���Ͻÿ��� ".class"�� �ٴ´�. 
	 * @param classPath : ���丮�� ���Ե� �����̸��̹Ƿ� Ȯ���ڰ� �ƴ� 
	 * ���丮 �����ڴ� File.separatorChar�̹Ƿ� Ȯ���� �ܿ� '.'�� �־�� �ȵȴ�. 
	 * ����Ŭ������ ǥ���ϴ� '$'�� �������� �ִ�. ".class"�� �پ �ȵȴ�.
	 * */
	static String fixClassPath(String classPath) {
		classPath = FileHelper.getFilenameExceptExt(classPath);
		
		String path = classPath;
		int separator=0;
		int separatorOld=0;
		boolean r=false;
		
		while (separator!=-1) {
			separator = indexOf(classPath, separator, File.separatorChar);
			if (separator==-1) {
				path = classPath + ".class";
				r = isFileExist(path);
				break;
			}
			
			path = classPath.substring(0, separator+1);
			
			r = isFileExist(path);
			
			if (r) {
				String remainder=null;
				try {
				remainder = classPath.substring(separatorOld+1, classPath.length());
				
				remainder = remainder.replace(File.separatorChar, '$');
				path = classPath.substring(0, separatorOld+1) + remainder + ".class";
				}catch(Exception e) {
					e.printStackTrace();
					CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
				}
				boolean r2 = isFileExist(path);
				if (r2)	break;
			}
			if (r==false) {
				String remainder=null;
				try {
				remainder = classPath.substring(separatorOld+1, classPath.length());
				
				remainder = remainder.replace(File.separatorChar, '$');
				path = classPath.substring(0, separatorOld+1) + remainder + ".class";
				}catch(Exception e) {
					e.printStackTrace();
					CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
				}
				r = isFileExist(path);
				break;
			}
			
			separatorOld = separator;
			separator++;
		}
		if (r)  return path;
		else return null;
	}
	
	/** ���� ����ϴ� java ��Ű���� Ŭ�������� ��� ���� �迭(Compiler_types.glistOfJavaClassesForThread)��
	 * �ִ� Ŭ�������� ������(ThreadReadingJavaClassesUsingWell)�� Ȱ���Ͽ� loadClass()�� �о� ĳ�ÿ�
	 * ����Ͽ� ������ ���δ�.
	 */
	public static void startThreadReadingJavaClassesUsingWell() {
		ThreadReadingJavaClassesUsingWell thread = new ThreadReadingJavaClassesUsingWell();
		thread.start();
	}
	
	/** ���� ����ϴ� java ��Ű���� Ŭ�������� ��� ���� �迭(Compiler_types.glistOfJavaClassesForThread)��
	 * �ִ� Ŭ�������� ������(ThreadReadingJavaClassesUsingWell)�� Ȱ���Ͽ� loadClass()�� �о� ĳ�ÿ�
	 * ����Ͽ� ������ ���δ�.
	 */
	public static class ThreadReadingJavaClassesUsingWell extends Thread {
		public void run() {
			int i;
			Compiler compiler = new Compiler();
			for (i=0; i<Compiler_types.glistOfJavaClassesForThread.length; i++) {
				String fullName = Compiler_types.glistOfJavaClassesForThread[i];
				loadClass(compiler, fullName);
			}
		}
	}
	
	
	/** ������ �޼��带 �̹� ����Ͽ����� true, �װ� �ƴϸ� false�� �����Ѵ�.
	 * findMembersInherited() ���� ����� �ϴٺ��� �ߺ��ؼ� ����� �� ��쵵 �����Ƿ�
	 * (Ư�� java.lang.Object�� ���) �װ��� ���ϱ� ���� ȣ���Ѵ�.
	 * */
	public static 
	boolean hasInherittedMember(FindClassParams classParams, FindVarParams var, FindFunctionParams func) {
		if (var!=null) {
			boolean r = classParams.hasVarInheritted(var);
			return r;
		}
		if (func!=null) {
			boolean r = classParams.hasFuncInheritted(func);
			return r;
		}
		return false;
	}
	
	
		
	
	/** inner class�� �Բ� �������� �ְ� �ƴҼ��� �ִ�.
	 * compiler.mlistOfAllClasses�� �̹� �ε�� Ŭ������ �ִٸ� �װ��� �����ϰ�,
	 * ���ٸ� �� Ŭ������ Ŭ�������Ͽ��� �ε��ϰ� compiler.mlistOfAllClasses�� ����ϰ� �����Ѵ�.
	 * ���� ��ӱ��� �Ѵ�.(�ܺ� Ŭ�������� loadClass���� ���, ���Ͽ��� �����ϴ� Ŭ�������� ���� ����� �ؾ��Ѵ�.)
	 * Ŭ���� �ε尡 �����ϸ� �ҽ����Ͽ��� �ε��Ѵ�(loadClassFromSrc_onlyInterface ����). 
	 * @param compiler : � compiler�� �����ϴ�.
	 * @param fullName : java.lang.String�� ���� �̸�
	 * @param fullNameIncludingTemplateAndArray : Ŭ������ ���ø� Ŭ������ ��� ���ø� Ÿ�� �̸��� �����ϰ� �迭�� �����ϴ� Ŭ���� Ǯ �̸��̴�.*/
	public static FindClassParams loadClass(Compiler compiler, String fullNameIncludingTemplateAndArray) {
		String fullName = fullNameIncludingTemplateAndArray;
		if (fullName==null || fullName.equals("")) return null;
		
		String typeNameInTemplatePair = null;
		if (fullName.contains("<")) {
			int a;
			a=0;
			a++;
			typeNameInTemplatePair = CompilerHelper.getTemplateTypeInPair(fullName);
		}
		
		//Ŭ������ ���ø� Ŭ������ ��� ���ø� Ÿ�� �̸��� �����ϰ� �迭�� �������� ���� Ŭ���� Ǯ �̸��̴�.
		try {
		fullName = CompilerHelper.getArrayElementType(fullName);
		}catch(Exception e) {
			int a;
			a=0;
			a++;
			e.printStackTrace();
		}
		
		if (fullName.equals("java.lang.Number")) {
			int a;
			a=0;
			a++;
		}
		if (compiler.getShortName(fullName).equals("PoolOfButton")) {
			int a;
			a=0;
			a++;
		}
		if (compiler.getShortName(fullName).equals("float")) {
			int a;
			a=0;
			a++;
		}
		/*if (fullName.contains("Stack") && fullName.contains("<")) {
			int a;
			a=0;
			a++;			
			FindClassParams r = CompilerHelper.loadClassFromSrc_onlyInterface(fullName);
			Compiler.applyTypeNameToChangeToTemplateClass(compiler, r, fullName);
			if (r==null) return null;
		}*/
		if (compiler.IsDefaultType(fullName)) {
			return null;
		}
		try {
			//if (CompilerHelper.exists(Compiler.mlistOfAllClasses,fullName)==false) {
			// Ŭ���� ĳ�ø� Ȯ���Ѵ�.
			FindClassParams classParams = CompilerHelper.getFindClassParams(Compiler.mlistOfAllClassesHashed, fullName);
			
			if (classParams==null) { // ĳ�ÿ� ������
				String classPath;
				String fullNameExceptTemplate = CompilerHelper.getTemplateOriginalType(fullName);
				classPath = fullNameExceptTemplate.replace('.', File.separatorChar); 
				classPath = Control.pathAndroid + File.separator + classPath + ".class";
				
				if (fullNameExceptTemplate.equals("com.gsoft.common.Encoding.EncodingFormatException")) {
					int a;
					a=0;
					a++;
				}
				
				String path = fixClassPath(classPath);
				
				if (path!=null) classPath = path;
				else {
					// Ŭ���� �н��� �߸��Ǿ� �ҽ� �ε带 �õ��� ��
					// (������� ���̺귯���� ��ġ���� �ʰų� ���̺귯�� ��ΰ� Ʋ�� ���)
					// �ҽ��� �ε��ϱ� ���� �ҽ� �ε尡 �̹� �����ߴٸ� �ٽ� �ε����� �ʴ´�.
					if (PathClassLoader.failedLoadingAlready(classPath)) {
						return null;
					}
					// Ŭ�����н��� �߸��Ǿ����� �ҽ��� �ε��Ѵ�.
					FindClassParams r = CompilerHelper.loadClassFromSrc_onlyInterface(fullName);
					if (r==null) {
						// �ҽ� �ε尡 �����ϸ� Ŭ���� �ε� ���� ����Ʈ�� ����Ͽ�
						// �ٽ� �ε� ���� �ʴ´�.
						//PathClassLoader.listOfClassesToFailLoading.add(classPath);
						return null;
					}
				}
				
				// Ŭ���� ���� �ε尡 �̹� �����ߴٸ�
				if (PathClassLoader.failedLoadingAlready(classPath)) {
					// �����ϸ� �ҽ��� �ε��Ѵ�.
					FindClassParams r = CompilerHelper.loadClassFromSrc_onlyInterface(fullName);
					if (r==null) return null;
					return null;
				}
				
				// Ŭ���� ������ �ε��Ѵ�.
				// Ŭ���� ���� �ε尡 �����ϸ� ���� ����Ʈ(failedLoadingAlready())�� ����Ѵ�.
				PathClassLoader loader = new PathClassLoader(classPath, typeNameInTemplatePair, fullName, false);
				if (loader!=null && loader.classParams!=null) {
					Compiler.mlistOfAllClasses.add(loader.classParams);
					Compiler.mlistOfAllClassesHashed.input(loader.classParams);
					if (!loader.classParams.hasInherited) {
						compiler.FindMembersInherited(loader.classParams);
					}
					return loader.classParams;
				}
				
				// �����ϸ� �ҽ��� �ε��Ѵ�.
				String shortName = compiler.getShortName(fullNameExceptTemplate);
				if (shortName.equals("IO")) {
					int a;
					a=0;
					a++;
				}
				FindClassParams r = CompilerHelper.loadClassFromSrc_onlyInterface(fullName);
				if (r==null) return null;
				
				return r;
			}
			else { // ĳ�ÿ� ������
				if (typeNameInTemplatePair!=null) {
					classParams.changeToTemplate(typeNameInTemplatePair);
				}
				//compiler.FindClassesFromTypeDecls(compiler, result)
				classParams.compiler.FindMembersInherited(classParams);
				return classParams;
			}
			
		}catch(Exception e) {
			try{
			Log.e("error", e.getMessage());
			}catch(Exception e2) {}
			//e.printStackTrace();
			//CompilerHelper.printStackTrace(textViewLogBird, e);
		}
		return null;
	}
	
	
	/*public static boolean exists(ArrayList listOfClasses, String fullClassName) {
		int i;
		for (i=0; i<listOfClasses.count; i++) {
			FindClassParams item = (FindClassParams) listOfClasses.getItem(i);
			if (item.name!=null) {
				if (item.name.equals(fullClassName)) return true;
			}
		}
		return false;
	}*/
	
	public static boolean exists(Hashtable_FullClassName listOfClassesHashed, String fullClassName) {
		FindClassParams item = listOfClassesHashed.getData(fullClassName);
		if (item!=null) return true;
		return false;
	}
	
	/*public static FindClassParams getFindClassParams(ArrayList listOfClasses, String fullClassName) {
		int i;
		for (i=0; i<listOfClasses.count; i++) {
			FindClassParams item = (FindClassParams) listOfClasses.getItem(i);
			if (item.name!=null) {
				if (item.name.equals(fullClassName)) return item;
			}
		}
		return null;
	}*/
	
	/** @param fullClassNameIncludingTemplateExceptArray : Ŭ������ ���ø� Ŭ������ ��� ���ø� Ÿ�� �̸��� �����ϰ� �迭�� �������� ���� Ŭ���� Ǯ �̸��̴�.*/
	public static synchronized 
	FindClassParams getFindClassParams(Hashtable_FullClassName listOfClassesHashed, String fullClassNameIncludingTemplateExceptArray) {
		synchronized(listOfClassesHashed) {
			FindClassParams item = listOfClassesHashed.getData(fullClassNameIncludingTemplateExceptArray);
			return item;
		}
	}
	
	/** fullName�� ���ø��� �迭��ȣ�� ���Եɰ�� 
	 * shortName�� ���ø�, �迭��ȣ�� ������ ������ '.', '/', '\\', '$' ���� �̸��� �����Ѵ�.
	 * '.', '/', '\\', '$'  �� ������ ���� fullName�� �����Ѵ�.
	 * @param fullName
	 * @return
	 */
	public static String getShortName(String fullName) {
		if (fullName==null) return null;
		int i;
		for (i=fullName.length()-1; i>=0; i--) {
			if (fullName.charAt(i)=='.') break;
			else if (fullName.charAt(i)=='/') break;
			else if (fullName.charAt(i)=='\\') break;
			else if (fullName.charAt(i)=='$') break;
		}
		return fullName.substring(i+1, fullName.length());
	}
	
	/** �ڹ� Ÿ�Ը� �����ϴ�. int, char, float�� �⺻Ÿ��*/
    public static boolean IsDefaultType(String c) {
    	if (c==null) return false;
    	int i;
    	if (Compiler.TypesOfJava==null) return false;
    	for (i=0; i<Compiler.TypesOfJava.length; i++) {
    		if (c.equals(Compiler.TypesOfJava[i])) return true;
    	}
    	return false;
    }
	
	/** �ּ�, ��ť�ּ�, �ֳ����̼������� Ȯ���Ѵ�.*/
	public static boolean IsComment(CodeChar c) {
		if (c.type==CodeStringType.Comment ||
				c.type==CodeStringType.DocuComment ||
				c.type==CodeStringType.Annotation) return true;
		return false;
	}
	
	/** �ּ�, ��ť�ּ�, �ֳ����̼��̸� true, �׷��������� false*/
	public static boolean IsComment(CodeString str) {
		if (str==null || str.count<=0) {
			int a;
			a=0;
			a++;
		}
		CodeChar c = str.charAt(0); 
		if (c.type==CodeStringType.Comment ||
				c.type==CodeStringType.DocuComment ||
				c.type==CodeStringType.Annotation) return true;
		return false;
	}
	
	/** ��ť�ּ�*/
	public static boolean IsRegularComment(CodeString str) {
		CodeChar c = str.charAt(0); 
		if (c.type==CodeStringType.Comment) return true;
		return false;
	}
	
	/** ��ť�ּ�*/
	public static boolean IsDocuComment(CodeString str) {
		CodeChar c = str.charAt(0); 
		if (c.type==CodeStringType.DocuComment) return true;
		return false;
	}
	
	/** �ֳ����̼������� Ȯ���Ѵ�.*/
	public static boolean IsAnnotation(CodeString str) {
		CodeChar c = str.charAt(0); 
		if (c.type==CodeStringType.Annotation) return true;
		return false;
	}
	
	/** ���(�ο빮, ����, �Ҹ��� ��)������ Ȯ���Ѵ�. ���⼭ �ο빮�� "abc", 'a'�� ���Ѵ�. 
	 * ���ڴ� ����, �ε��Ҽ����� ���Ѵ�. ���� null�� �����Ѵ�.*/
	public static boolean IsConstant(CodeString str) {
		if (str.equals("null")) return true;
		if (str.equals("true") || str.equals("false")) return true;
		CodeChar c = str.charAt(0); 
		if (c.type==CodeStringType.Constant) return true;
	
		if (str.equals("0xff")) {
			int a;
			a=0;
			a++;
		}
		int isNumber = IsNumber2(str);
		if (isNumber!=0) {
			return true;
		}
		return false;
	}
	
	/*public static boolean IsNumber(CodeString str) {
		int i;
		char ch;
		int lenOfStr = str.length();
		if (lenOfStr>1) {
			// ù��° ����
			ch = str.charAt(0).c;
			if ((('0'<=ch && ch<='9') || ch=='-' || ch=='+')==false) {
				return false;
			}
			
			// �߰���
			boolean isDotFound = false;
			// -.3f(x), +.2f(x)
			if (str.charAt(1).c=='.' && 
					(str.charAt(0).c=='-' || str.charAt(0).c=='+') ) return false;
			for (i=1; i<lenOfStr-1; i++) {			
				ch = str.charAt(i).c;
				if (isDotFound && ch=='.') return false; // �Ҽ����� �ΰ� �̻��ΰ��
				if (ch=='.') {					
					isDotFound = true;
				}
				if (ch=='-' || ch=='+') return false;
				if ((('0'<=ch && ch<='9') || ch=='.')==false) {					
					return false;
				}
			}
		
			// ������ ����
			ch = str.charAt(lenOfStr-1).c;
			if (str.str.contains(".")) { // �Ǽ�
				if ((('0'<=ch && ch<='9') || ch=='f' || ch=='d')==false) {
					return false;
				}
			}
			else { // ����
				if ((('0'<=ch && ch<='9') || ch=='c' || ch=='i' || ch=='s' || ch=='l')==false) {
					return false;
				}
			}
		}
		else if (lenOfStr==1) {
			ch = str.charAt(0).c;
			if (('0'<=ch && ch<='9')==false) return false;
			else return true;
		}
		else {
			return false;
		}
		
		int posOfDot = str.indexOf(".");
		if (posOfDot==-1) return true;
		if (posOfDot==0 || posOfDot>=str.length()-1)
			return false;
		else return true;
	}*/
	
	/** 16������ �ƴϸ� 0�� ����, 16���� char�̸� 1, 16���� short�̸� 2,
	 * 16���� integer�̸� 3�� ����, 16���� long�̸� 4��, 
	 * 16���� float�̸� 5��, 16���� double�̸� 6�� �����Ѵ�.
	 * 16���� byte�̸� 7�� �����Ѵ�.*/
	public static int IsHexa(CodeString str) {
		return IsHexa(str.str);
	}
	
	
	/** 16������ �ƴϸ� 0�� ����, 16���� char�̸� 1, 16���� short�̸� 2,
	 * 16���� integer�̸� 3�� ����, 16���� long�̸� 4��, 
	 * 16���� float�̸� 5��, 16���� double�̸� 6�� �����Ѵ�.
	 * 16���� byte�̸� 7�� �����Ѵ�.*/
	public static int IsHexa(String str) {
		int i;
		char ch1, ch2, ch;
		int lenOfStr = str.length();
		
		if (lenOfStr>2) {
			// ù��° ����
			ch1 = str.charAt(0);
			ch2 = str.charAt(1);
			// 16������ ��� +, -�� ��ȣ�� ������ �ȵȴ�. �ݵ�� 0x�� �����ؾ� �Ѵ�.
			if ((ch1=='0' && (ch2=='x' || ch2=='X'))==false) return 0;
			
			/*for (i=2; i<lenOfStr-1; i++) {
				ch = str.charAt(i).c;
				if ( (('0'<=ch && ch<='9') || 
					 ('a'<=ch && ch<='f') || ('A'<=ch && ch<='F'))==false )
					return false;
			}*/
			
			
			// �߰���
			boolean isDotFound = false;
			// 0x.0011
			if (str.charAt(2)=='.') return 0;
			for (i=2; i<lenOfStr-1; i++) {			
				ch = str.charAt(i);
				if (isDotFound && ch=='.') return 0; // �Ҽ����� �ΰ� �̻��ΰ��
				if (ch=='.') {					
					isDotFound = true;
				}
				if (ch=='-' || ch=='+') return 0;
				if ( (('0'<=ch && ch<='9') || 
						 ('a'<=ch && ch<='f') || ('A'<=ch && ch<='F'))==false ) {					
					return 0;
				}
			}
			
			// ������ ����
			/*ch = str.charAt(lenOfStr-1).c;
			if (str.str.contains(".")) { // �Ǽ�
				if ((('0'<=ch && ch<='9') || ch=='f' || ch=='d')==false) {
					return true;
				}
			}
			else { // ����
				if ((('0'<=ch && ch<='9') || (ch=='c' || ch=='s' || ch=='i' || ch=='l'))==false) {
					return true;
				}
			}*/
			
			// ������ ����
			ch = str.charAt(lenOfStr-1);
			if (str.contains(".")) { // �Ǽ�
				// 16������ ��� ���̻� f�� ����Ҽ� ����.
				if ( (('0'<=ch && ch<='9') || (('a'<=ch && ch<='f') || ('A'<=ch && ch<='F')) || 
						(ch=='d' || ch=='D'))==false ) {
					return 0;
				}
			}
			else { // ����
				if ( (('0'<=ch && ch<='9')  || (('a'<=ch && ch<='f') || ('A'<=ch && ch<='F')) ||
					(ch=='c' || ch=='s' || ch=='i' || ch=='l' || ch=='C' || ch=='S' || ch=='I' || ch=='L'))==false ) {
					return 0;
				}
			}
		}
		
		else {
			return 0;
		}
		
		int posOfDot = str.indexOf(".");
		if (posOfDot==-1) {// ����
			if (ch=='c' || ch=='C') return 1;//char
			else if (ch=='s' || ch=='S') return 2;//short
			else if (ch=='i' || ch=='I') return 3;//int
			else if (ch=='l' || ch=='L') return 4;//long
			//else return 3; //���̻簡 ������ int
			else { // ���̻簡 ������
				//int integer = Integer.parseInt(str.str);
				/*try {
					integerLong = IO.hexaToLong(str.str);
					if (Byte.MIN_VALUE<=integerLong && integerLong<Byte.MAX_VALUE) return 7;
					else if (Short.MIN_VALUE<=integerLong && integerLong<Short.MAX_VALUE) return 2;
					else if (Integer.MIN_VALUE<=integerLong && integerLong<Integer.MAX_VALUE) return 3;
					else return 4; // long
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return 0;
				}*/
				return IO.isNumber2OfHexa(str);
				
			}
		}
		if (posOfDot==0 || posOfDot>=str.length()-1)
			return 0;
		else { //�Ǽ�
			//if (ch=='f') return 5;//float
			//else 
			// 16������ ��� ���̻� f�� ����Ҽ� ����.
			if (ch=='d' || ch=='D') return 6;//double
				
			// �Ҽ����� ������ ���̻簡 ������
			float f = Float.parseFloat(str);
			if (Float.MIN_VALUE<=f && f<Float.MAX_VALUE) return 5;
			return 6;
		}
	}
	
	/** 0�� �ƴϸ� not number�� ����, 1�̸� char��, 2�̸� short��,
	 * 3�̸� integer�� ����, 4�̸� long��, 5�̸� float��, 6�̸� double�� �����Ѵ�. 
	 * 7�̸� byte�� �����Ѵ�.*/
	public static String getNumberString(int numberType) {
		switch(numberType) {
		case 0 : return "not number";
		case 1 : return "char";
		case 2 : return "short";
		case 3 : return "integer";
		case 4 : return "long";
		case 5 : return "float";
		case 6 : return "double";
		case 7 : return "byte";
		}
		return null;
	}
	
	/** str�� �����̸� 'f', 'd', 'l"�� ���� ���̻縦 ������ ��Ʈ���� �����Ѵ�.*/
	public static String getNumberRemovingLastFix(String str) {		
		if (str.length()>0) {
			char chLast = str.charAt(str.length()-1);
			if (('A'<=chLast && chLast<='Z') || ('a'<=chLast && chLast<='z')) {
				int r = IsNumber2(str);
				if (r!=0) {
					String result = str.substring(0, str.length()-1);
					return result;
				}
			}
		}
		return str;
	}
	
	
	/** ���ڰ� �ƴϸ� 0�� ����, char�̸� 1, short�̸� 2,
	 * integer�̸� 3�� ����, long�̸� 4��, float�̸� 5��, double�̸� 6�� �����Ѵ�. 
	 * byte�̸� 7�� �����Ѵ�.
	 * 16������ ��� CompilerHelper.IsHexa(str)�� �����Ѵ�.*/
	public static int IsNumber2(CodeString str) {
		return IsNumber2(str.str);
	}
	
	

	
	/** ���ڰ� �ƴϸ� 0�� ����, char�̸� 1, short�̸� 2,
	 * integer�̸� 3�� ����, long�̸� 4��, float�̸� 5��, double�̸� 6�� �����Ѵ�. 
	 * byte�̸� 7�� �����Ѵ�.
	 * 16������ ��� CompilerHelper.IsHexa(str)�� �����Ѵ�.*/
	public static int IsNumber2(String str) {
		if (str.equals("127")) {
			int a;
			a=0;
			a++;
		}
		// 16������ ��� 
		int hexa = CompilerHelper.IsHexa(str);
		if (hexa!=0) return hexa;
		
		int i;
		char ch;
		int lenOfStr = str.length();
		if (lenOfStr>1) {
			// ù��° ����
			ch = str.charAt(0);
			if ((('0'<=ch && ch<='9') || ch=='-' || ch=='+')==false) {
				return 0;
			}
			
			// �߰���
			boolean isDotFound = false;
			// -.3f(x), +.2f(x)
			if (str.charAt(1)=='.' && 
					(str.charAt(0)=='-' || str.charAt(0)=='+') ) return 0;
			for (i=1; i<lenOfStr-1; i++) {			
				ch = str.charAt(i);
				if (isDotFound && ch=='.') return 0; // �Ҽ����� �ΰ� �̻��ΰ��
				if (ch=='.') {					
					isDotFound = true;
				}
				if (ch=='-' || ch=='+') return 0;
				if ((('0'<=ch && ch<='9') || ch=='.')==false) {					
					return 0;
				}
			}
		
			// ������ ����
			ch = str.charAt(lenOfStr-1);
			if (str.contains(".")) { // �Ǽ�
				if ( (('0'<=ch && ch<='9') || 
						(ch=='f' || ch=='d' || ch=='F' || ch=='D') )==false) {
					return 0;
				}
			}
			else { // ����
				if ( (('0'<=ch && ch<='9') || 
					(ch=='c' || ch=='s' || ch=='i' || ch=='l' || ch=='C' || ch=='S' || ch=='I' || ch=='L'))==false ) {
					return 0;
				}
			}
		}
		else if (lenOfStr==1) {
			ch = str.charAt(0);
			if (('0'<=ch && ch<='9')==false) return 0;
			else return 7; // byte
		}
		else {
			return 0;
		}
		
				
		int posOfDot = str.indexOf(".");
		if (posOfDot==-1) {// ����
			if (ch=='c' || ch=='C') return 1;//char
			else if (ch=='s' || ch=='S') return 2;//short
			else if (ch=='i' || ch=='I') return 3;//int
			else if (ch=='l' || ch=='L') return 4;//long
			else { // ���̻簡 ������
				int integer = Integer.parseInt(str);
				if (IO.BYTE_MIN_VALUE<=integer && integer<=IO.BYTE_MAX_VALUE) return 7;
				else if (IO.SHORT_MIN_VALUE<=integer && integer<=IO.SHORT_MAX_VALUE) return 2;
				else if (IO.INTEGER_MIN_VALUE<=integer && integer<=IO.INTEGER_MAX_VALUE) return 3;
				else return 4; // long
			}
		}
		if (posOfDot==0 || posOfDot>=str.length()-1)
			return 0;
		else { //�Ǽ�
			if (ch=='f' || ch=='F') return 5;//float
			else if (ch=='d' || ch=='D') return 6;//double
			
			// �Ҽ����� ������ ���̻簡 ������
			float f = Float.parseFloat(str);
			if (Float.MIN_VALUE<=f && f<Float.MAX_VALUE) return 5;
			else return 6; // double
		}
	}

	
	public static boolean IsBlank(char c)
    {
        if (c == ' ' || c == '\t' || c == '\r' || c == '\n') return true;
        return false;
    }

	/** " ", "\t", "\r", "\n" */
    public static boolean IsBlank(CodeString c)
    {
        if (c.equals(" ") || c.equals("\t") || c.equals("\r") || c.equals("\n")) return true;
        return false;
    }
    
    /** ������ ������ ������*/
    public static boolean IsSeparator(char c)
    {    	
        if (c == '[' || c == ']' || c == '{' || c == '}' || c == '(' || c == ')' ||
            c == '=' || c == ';' || c == ':' || c == ',' || c == '.' || c == '@' ||
            c == '\\')
            return true;
        if (IsOperator(c)) return true;
        if (CompilerHelper.IsBlank(c)) return true;
        return false;
    }

    /** ������ ������ ������*/
    public static boolean IsSeparator(CodeString c)
    {
    	//if (IsSeparator(c.charAt(0).c)) return true;
        if (c.equals("[") || c.equals("]") || c.equals("{") || c.equals("}") || c.equals("(") || c.equals(")") ||
           c.equals("=") || c.equals(";") || c.equals(":") || c.equals(",") || c.equals(".") || c.equals("@") ||
           c.equals("\\"))
            return true;
        if (IsOperator(c)) return true;
        if (CompilerHelper.IsBlank(c)) return true;
        return false;
    }
    
    public static boolean isInteger(String typeName) {
    	if (typeName.equals("boolean") || typeName.equals("byte") || typeName.equals("char") ||
				typeName.equals("short") || typeName.equals("int"))
    		return true;
    	return false;
    }
    
    /** c == '+' || c == '-' || c == '*' || c == '/' || c == '<' || c == '>' || c == '~' ||
        c == '|' || c == '&' || c == '!' || c == '%' || c == '=' || c == '^'
            ������ '='�� �����Ѵ�. "=="*/
    public static boolean IsOperator(char c)
    {
        if (c == '+' || c == '-' || c == '*' || c == '/' || c == '<' || c == '>' || c == '~' ||
            c == '|' || c == '&' || c == '!' || c == '%' || c == '=' || c == '^' || 
            c == '?' || c == ':') return true;
        return false;
    }
    
    /** ���̰� ���� 1�� ���Ǵ� �����ڵ�, c.equals("~") || c.equals("!") || c.equals("^") || 
	        c.equals("?") || c.equals(":") || c.equals("instanceof")*/
    public static boolean IsOperatorLen1(CodeString c) {
    	if (c.equals("~") || c.equals("!") || c.equals("^") || 
	        c.equals("?") || c.equals(":") || c.equals("instanceof")) return true;
    	return false;
    }
    
    public static boolean IsCompositiveOperator(CodeString op1, CodeString op2, CodeString op3) {
    	if (op1.equals("<") || op2.equals("<") || op3.equals("<")) {
    		return true;
    	}
    	if (op1.equals(">") || op2.equals(">") || op3.equals(">")) {
    		return true;
    	}
    	return false;
    }
    
    public static boolean IsCompositiveOperator(CodeString op1, CodeString op2) {
    	if (op2.equals("=")) {
    		// ��Ģ����
    		if (op1.equals("+") || op1.equals("-") || op1.equals("*") || op1.equals("/") ||
    			op1.equals("%") || 
    			op1.equals("|") || op1.equals("&") || op1.equals("^") || op1.equals("~")) {
        		return true;
        	}
    		// ���迬��
    		if (op1.equals("!") || op1.equals("=") || op1.equals("<") || op1.equals(">"))
    			return true;
    		return false;
    	}
    	if (op1.equals("<")) {
    		// shift����
    		if (op2.equals("<")) return true;
    		// ���迬��
    		if (op2.equals("=")) return true;
    		return false;
    	}
    	else if (op1.equals(">")) {
    		// shift����
    		if (op2.equals(">")) return true;
    		// ���迬��
    		if (op2.equals("=")) return true;
    		return false;
    	}
    	else if (op1.equals("&")) {
    		// ��������
    		if (op2.equals("&")) return true;
    		return false;
    	}
    	else if (op1.equals("|")) {
    		// ��������
    		if (op2.equals("|")) return true;
    		return false;
    	}
    	return false;
    }
    
    /** >, <, ==, !=, >=, <=*/
    public static boolean IsRelationOperator(String str) {
    	if (str.equals(">") || str.equals("<") || str.equals("==") || str.equals("!=") ||
    			str.equals(">=") || str.equals("<="))
    		return true;
    	return false;
    }

    /** c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/") || c.equals("<") || c.equals(">") || c.equals("~") ||
        c.equals("|") || c.equals("&") || c.equals("!") || c.equals("%") || c.equals("=") || c.equals("^")
            ������ '='�� �����Ѵ�. "=="*/
    public static boolean IsOperator(CodeString c)
    {
    	/*int len = c.length();
    	if (len==2) {
	    	if (IsOperator(c.charAt(0).c)) {
	    		if (IsOperator(c.charAt(1).c)) {
	    			return true; // "<=" �̷���� "<"�� �������̹Ƿ� true
	    		}
	    		else return false; //-1�̸� �����ڰ� �ƴϴ�.
	    	}
	    	else return false;
    	}
    	else if (len==3) {
	    	if (IsOperator(c.charAt(0).c)) {
	    		if (IsOperator(c.charAt(1).c)) {
	    			if (IsOperator(c.charAt(2).c)) {
	    				return true; // "<=" �̷���� "<"�� �������̹Ƿ� true
	    			}
	    			else return false;
	    		}
	    		else return false;
	    	}
	    	else return false;
    	}
    	else if (len==1) {
	        if (c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/") || c.equals("<") || c.equals(">") || c.equals("~") ||
	            c.equals("|") || c.equals("&") || c.equals("!") || c.equals("%") || c.equals("=") || c.equals("^") || 
	            c.equals("?") || c.equals(":")) return true;
    	}
    	else {
    		if (c.equals("instanceof")) return true;
    		return false;
    	}
    	
        return false;*/
    	
    	return IsOperator(c.str);
    }
    
    /** c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/") || c.equals("<") || c.equals(">") || c.equals("~") ||
    c.equals("|") || c.equals("&") || c.equals("!") || c.equals("%") || c.equals("=") || c.equals("^")
        ������ '='�� �����Ѵ�. "=="*/
public static boolean IsOperator(String c)
{
	int len = c.length();
	if (len==2) {
    	if (IsOperator(c.charAt(0))) {
    		if (IsOperator(c.charAt(1))) {
    			return true; // "<=" �̷���� "<"�� �������̹Ƿ� true
    		}
    		else return false; //-1�̸� �����ڰ� �ƴϴ�.
    	}
    	else return false;
	}
	else if (len==3) {
    	if (IsOperator(c.charAt(0))) {
    		if (IsOperator(c.charAt(1))) {
    			if (IsOperator(c.charAt(2))) {
    				return true; // "<=" �̷���� "<"�� �������̹Ƿ� true
    			}
    			else return false;
    		}
    		else return false;
    	}
    	else return false;
	}
	else if (len==1) {
        if (c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/") || c.equals("<") || c.equals(">") || c.equals("~") ||
            c.equals("|") || c.equals("&") || c.equals("!") || c.equals("%") || c.equals("=") || c.equals("^") || 
            c.equals("?") || c.equals(":")) return true;
	}
	else {
		if (c.equals("instanceof")) return true;
		return false;
	}
	
    return false;
}
    
    /**c.equals("!") || c.equals("~")*/
    public static boolean IsOperatorForOne(CodeString c)
    {
        if (c.equals("!") || c.equals("~")) return true;
        return false;
    }
    
    /**c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/") || 
            c.equals("|") || c.equals("&") || c.equals("%")  || c.equals("^") 
            �ڿ� "="�� �ٴ´�. ������ <�� "<<="�� ���ϰ� >�� ">>="�� ���ϰ� ^�� "^="(�ŵ�����)�� ���Ѵ�.
            IsLValue()�� �����Ѵ�.*/
    public static boolean IsAssignOperator(CodeString c)
    {
        if (c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/") || 
            c.equals("|") || c.equals("&") || c.equals("%")  || c.equals("^")) return true;
        return false;
    }
    
    /** +=, -=, *=, /=, |=, &=, %=, ^=, <<=, >>= �� ���Ѵ�.
     * "+="�� op1�� +�̰�, op2�� =�� �ȴ�. op3�� null�� �� �ִ�.*/
    public static boolean IsAssignOperator(CodeString op1, CodeString op2, CodeString op3) {
    	if (IsAssignOperator(op1) && op2.equals("=")) {
    		return true;
    	}
    	if (op1.equals("<") && op2.equals("<") && op3.equals("="))
    		return true;
    	if (op1.equals(">") && op2.equals(">") && op3.equals("="))
    		return true;
    	return false;
    }
    
    
    /** 1  2.5f  +  3  +   --> ù��° +�� ������ float�� getTypeOfOperator���� ���ϵǰ�,
	listOfTypes���� ù�ΰ��� ���۷��尡 �����Ǿ� float�� ����ȴ�. 
	3�� ������ float  int�� �ǰ�,
	�ι�° +�� ������ �������� float int�̱� ������ float�� getTypeOfOperator���� ���ϵǰ�,
	���������� listOfTypes���� �ΰ��� ���۷��尡 �����Ǿ� ����°� �ȴ�.
	������ float�� ������ Ÿ������ ���ϵȴ�.
	@param listOfTypes : ���۷��常 ����� �����̴�.���۷����ʹ� ���⿡ ����.*/
public static 
	CodeStringEx getTypeOfOperator(Compiler compiler, FindFuncCallParam funcCall, ArrayListIReset listOfTypes, CodeStringEx operator) {
		int startIndex = funcCall.startIndex();
		int endIndex = funcCall.endIndex();
		int i;
		
		if (operator!=null && operator.indicesInSrc!=null && 
				operator.indicesInSrc.count>0 && operator.indicesInSrc.list[0]==5384) {
			int a;
			a=0;
			a++;
		}
		
		// �ϴ� �̷��� �Ѵ�. �����ڰ� ����ִ� ������ Ÿ��ó��
		CodeStringEx oldType = null, curType;
		
		if (2471<=startIndex && endIndex<=2494) {
			int a;
			a=0;
			a++;
		}
		
		try{
		if (listOfTypes.count==1) {
			if (listOfTypes.getItem(listOfTypes.count-1)==null) {
				listOfTypes.count -= 1;
				return new CodeStringEx("null");
			}
			if (listOfTypes.getItem(listOfTypes.count-1).equals("null")) {
				listOfTypes.count -= 1;
				return new CodeStringEx("null");
			}
		}
		}catch(Exception e) {
			e.printStackTrace();
			int a;
			a=0;
			a++;
		}
		
		// ���׿�����, int i4 = -((-1)+2) + (~(-1)+(~1)); 
		// ���⿡�� -((-1)+2)�� -�� ���Ѵ�. -1�� ���ֺм��⿡�� �ϳ��� ��Ʈ������ ��������.
		if ((operator.equals("+")  && operator.isPlusOrMinusForOne) || 
			(operator.equals("-") && operator.isPlusOrMinusForOne)) {
			if (listOfTypes.count>0) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-1);				
				if (oldType==null) {
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				if (oldType.equals("byte")) {
					allowsOperator(oldType, null, operator);					
				}
				else if (oldType.equals("char") || oldType.equals("int") || oldType.equals("short") ||
						oldType.equals("long")) {
					allowsOperator(oldType, null, operator);
				}
				else if (oldType.equals("float") || oldType.equals("double")) {
					allowsOperator(oldType, null, operator);
				}
				else {
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				// ���ÿ��� ������ 1���� ���۷��带 ������.
				listOfTypes.count -= 1;
				
				// oldType�� operator�� Ÿ������ �ٲ۴�.
				if (operator.value!=null) {
					oldType.setStrAndTypeFullName(operator.typeFullName, operator.typeFullName);
				}
				return oldType;
			}
		}
		
		if (operator.equals("?")) {
			if (listOfTypes.count>0) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-1);
				if (oldType==null) {
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				if (oldType.equals("boolean")) {
				}
				else {
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				// ���ÿ��� ������ 1���� ���۷��带 ������.
				listOfTypes.count -= 1;
				
				// oldType�� operator�� Ÿ������ �ٲ۴�.
				if (operator.value!=null) {
					oldType.setStrAndTypeFullName(operator.typeFullName, operator.typeFullName);
				}
				return oldType;
			}
		}
		
		else if (operator.equals("!")) {
			if (listOfTypes.count>0) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-1);
				if (oldType==null) {
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				if (oldType.equals("boolean")) {
				}
				else {
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				// ���ÿ��� ������ 1���� ���۷��带 ������.
				listOfTypes.count -= 1;
				
				// oldType�� operator�� Ÿ������ �ٲ۴�.
				if (operator.value!=null) {
					oldType.setStrAndTypeFullName(operator.typeFullName, operator.typeFullName);
				}
				return oldType;
			}
		}
		
		else if (operator.equals("~")) {
			if (listOfTypes.count>0) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-1);
				if (oldType==null) {
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("int") || oldType.equals("short") ||
					oldType.equals("long")) {
					allowsOperator(oldType, null, operator);
				}
				else { // float, double���� ����
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType));
					listOfTypes.count -= 1;
					return new CodeStringEx("null");
				}
				// ���ÿ��� ������ 1���� ���۷��带 ������.
				listOfTypes.count -= 1;
				
				// oldType�� operator�� Ÿ������ �ٲ۴�.
				if (operator.value!=null) {
					oldType.setStrAndTypeFullName(operator.typeFullName, operator.typeFullName);
				}
				return oldType;
			}
		}
		
		if (operator.equals(":")) {
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {					
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (oldType.equals("byte")) {
						if (curType.equals("byte") || curType.equals("char") || 
							curType.equals("short") || curType.equals("int") || curType.equals("long") || 
							curType.equals("float") || curType.equals("double")) {
							// oldType�� curType���� �ٲ۴�.
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("char") || oldType.equals("short")) {
						if (curType.equals("byte")) {
							
						}
						else if (curType.equals("char") || 
							curType.equals("short") || curType.equals("int") || curType.equals("long") || 
							curType.equals("float") || curType.equals("double")) {
							// oldType�� curType���� �ٲ۴�.
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("int")) {
						if (curType.equals("byte") || curType.equals("char") || curType.equals("short")) {
							
						}
						else if (curType.equals("int") || curType.equals("long") || 
							curType.equals("float") || curType.equals("double")) {
							// oldType�� curType���� �ٲ۴�.
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("long")) {
						if (curType.equals("byte") || curType.equals("char") ||
							curType.equals("short") || curType.equals("int")) {
							
						}
						else if (curType.equals("long") || 
							curType.equals("float") || curType.equals("double")) {
							// oldType�� curType���� �ٲ۴�.
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("float")) {
						if (curType.equals("byte") || curType.equals("char") ||
							curType.equals("short") || curType.equals("int")) {
							
						}
						else if (curType.equals("long")) {
							
						}
						else if (curType.equals("float") || curType.equals("double")) {
							// oldType�� curType���� �ٲ۴�.
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("double")) {
						if (curType.equals("byte") || curType.equals("char") ||
							curType.equals("short") || curType.equals("int") || curType.equals("long") ||
							curType.equals("float") || curType.equals("double")) {
							
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else {
						if (TypeCast.isCompatibleType(compiler, oldType, curType, 0, null)==false) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							
						}
					}
				}//for
				// ���ÿ��� ������ 3���� ���۷��带 ������.
				listOfTypes.count -= 3;
				
				// oldType�� operator�� Ÿ������ �ٲ۴�.
				if (operator.value!=null) {
					oldType.setStrAndTypeFullName(operator.typeFullName, operator.typeFullName);
				}
				return oldType;
			}//if (listOfTypes.count>1) {
		}//if (operator.equals(":")) {
		
		// +, -, *, /, %, �� float-float�� �����ϴ�.boolean-boolean�Ұ���
		else if ((operator.equals("+") && operator.isPlusOrMinusForOne==false) || 
			(operator.equals("-") && operator.isPlusOrMinusForOne==false) || 
			operator.equals("*") || operator.equals("/") ||	operator.equals("%")) {
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (oldType.equals("boolean")) {
						if (curType.equals("boolean")) {							
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							if (operator.equals("+")) {//'+'���길 ����
								Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
							else {
								Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("void")) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else if (oldType.equals("byte")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte")) {
							allowsOperator(oldType, curType, operator);
						}
						else if (curType.equals("int")) {
							allowsOperator(oldType, curType, operator);
							// oldType�� curType���� �ٲ۴�.
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("short")) {
							allowsOperator(oldType, curType, operator);
							// oldType�� curType���� �ٲ۴�.
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("long")) {
							// ���� ���۷���� long���� �ٲ��.
							allowsOperator(oldType, curType, operator);
							// oldType�� curType���� �ٲ۴�.
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("float") || curType.equals("double")) {
							// ���� ���۷���� float�� double���� �ٲ��.
							allowsOperator(oldType, curType, operator);
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("char")) {
							// ���� ���۷���� int�� �ٲ��.
							allowsOperator(oldType, curType, operator);
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("java.lang.String")) {
							// ���� ���۷���� String���� �ٲ��.
							if (operator.equals("+")) {
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							}
							else {
								Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
							//return curType;
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("byte")) {
					else if (oldType.equals("int") || oldType.equals("short") || oldType.equals("long")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte")) {
							allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("int")) {
							boolean b = allowsOperator(oldType, curType, operator);
							if (oldType.equals("short")) {
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
								oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
							}
							else if (oldType.equals("long")) {
								// curType�� oldType���� �ٲ��.
								curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
							}
						}
						else if (curType.equals("short")) {
							// ���� ���۷���� int�� �ٲ��.
							allowsOperator(oldType, curType, operator);
							if (oldType.equals("int")) {
								curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
							}
							else if (oldType.equals("long")) {
								curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
							}
						}
						else if (curType.equals("long")) {
							// ���� ���۷���� long���� �ٲ��.
							allowsOperator(oldType, curType, operator);
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("float") || curType.equals("double")) {
							// ���� ���۷���� float�� double���� �ٲ��.					
							allowsOperator(oldType, curType, operator);
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("char")) {
							// ���� ���۷���� int�� �ٲ��.
							allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("java.lang.String")) {
							if (operator.equals("+")) {
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							}
							else {
								Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("int")) {
					else if (oldType.equals("float")) {
						if (operator.indicesInSrc!=null && operator.indicesInSrc.getItem(0)==1970) {
							int a;
							a=0;
							a++;
						}
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							// ���� ���۷���� float�� �ٲ��.
							allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("float")) {
							allowsOperator(oldType, curType, operator);
						}
						else if (curType.equals("double")) {
							// ���� ���۷���� double���� �ٲ��.
							allowsOperator(oldType, curType, operator);
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("char")) {
							allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("java.lang.String")) {
							if (operator.equals("+")) {
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							}
							else {
								Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("float")) {
					else if (oldType.equals("double")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							// ���� ���۷���� double�� �ٲ��.
							allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("float")) {
							// ���� ���۷���� double�� �ٲ��.
							//FindVarUseParams v = (FindVarUseParams) listOfVarUses.list[i];
							//v.fullnameTypeCastByOperator = oldType;
							allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("double")) {
							allowsOperator(oldType, curType, operator);
						}
						else if (curType.equals("char")) {
							allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("java.lang.String")) {
							if (operator.equals("+")) {
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							}
							else {
								Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("double")) {
					else if (oldType.equals("char")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte")) {
							allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							// ���� ���۷���� ���� Ÿ������ �ٲ��.
							//FindVarUseParams v = (FindVarUseParams) listOfVarUses.list[i-1];
							//v.fullnameTypeCastByOperator = curType;
							allowsOperator(oldType, curType, operator);
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;							
						}
						else if (curType.equals("float") || curType.equals("double")) {
							// ���� ���۷���� ���� Ÿ������ �ٲ��.
							allowsOperator(oldType, curType, operator);
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("char")) {
							allowsOperator(oldType, curType, operator);
						}
						else if (curType.equals("java.lang.String")) {
							if (operator.equals("+")) {
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							}
							else {
								Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("char")) {
					else if (oldType.equals("java.lang.String")) {
						// ���� ���۷���� String���� �ٲ��.
						if (operator.equals("+")) {
							if (compiler.IsDefaultType(curType)) {
								curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
								listOfTypes.count -= 2;
								return oldType;
							}
							else if (curType.equals("java.lang.String")) {
								listOfTypes.count -= 2;
								return oldType;
							}
							else {
								// curType�� String�� �ƴ� �ٸ� object�� ���
								CodeStringEx fullnameTypeCast1 = new CodeStringEx("java.lang.String");
								CodeStringEx fullnameTarget1 = curType;
								boolean isCompatible1 = TypeCast.isCompatibleType(compiler, fullnameTypeCast1, fullnameTarget1, 1, null);
								if (isCompatible1) {
									// curType�� java.lang.String�� ����Ŭ������ ���
									//curType.typeFullNameAfterOperation = oldType.str;
									listOfTypes.count -= 2;
									return oldType;
								}
								else {
									// curType�� toString()�Լ��� ȣ��Ǿ�� �Ѵ�.
									if (toStringFuncExists(compiler, curType.str)) {
										//curType.typeFullNameAfterOperation = oldType.str;
										listOfTypes.count -= 2;
										return oldType;								
									}
									// curType�� toString()�Լ��� ������ error�� �߻���Ų��.
									Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
									listOfTypes.count -= 2;
									return new CodeStringEx("null");
								}
							}
						}//+�̸�
						else { // +�� �ƴϸ�
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("java.lang.String")) {
					else {//oldType�� java.lang.String�� �ƴ� object�̴�.
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("char")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							//return curType;
							CodeStringEx fullnameTypeCast1 = new CodeStringEx("java.lang.String");
							CodeStringEx fullnameTarget1 = oldType;
							boolean isCompatible1 = TypeCast.isCompatibleType(compiler, fullnameTypeCast1, fullnameTarget1, 1, null);
							if (isCompatible1) {
								// oldType�� String�� ���� Ŭ������ ���
								if (operator.equals("+")) {
									listOfTypes.count -= 2;
									return curType;
								}
								else {
									Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
									listOfTypes.count -= 2;
									return new CodeStringEx("null");		
								}
							}
							else {
								// oldType�� toString()�Լ��� ȣ��Ǿ�� �Ѵ�.
								if (toStringFuncExists(compiler, oldType.str)) {
									//curType.typeFullNameAfterOperation = oldType.str;
									if (operator.equals("+")) {
										listOfTypes.count -= 2;
										return curType;
									}
									else {
										Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
										listOfTypes.count -= 2;
										return new CodeStringEx("null");
									}
								}
								// oldType�� toString()�� ������								
								Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
						}//else if (curType.equals("java.lang.String")) {
						else { // oldType, curType ��� java.lang.String�� �ƴ� ���
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}//// oldType, curType ��� java.lang.String�� �ƴ� ���
					}//else {//oldType�� java.lang.String�� �ƴ� object�̴�.
				} // for (i=1; i<listOfTypes.count; i++) {
				
				// ���ÿ��� ������ 2���� ���۷��带 ������.
				listOfTypes.count -= 2;
				//listOfVarUses.count -= 2;
				
				// oldType�� operator�� Ÿ������ �ٲ۴�.
				if (operator.value!=null) {
					oldType.setStrAndTypeFullName(operator.typeFullName, operator.typeFullName);
				}
				return oldType;
			} //if (listOfTypes.count==2) {
		} // if (operator.equals("+") || operator.equals("-") || operator.equals("*") || operator.equals("/") || operator.equals("%") {
		
		// >, <, >=, <= �� float-float�� �����ϴ�.boolean-boolean�Ұ���
		if (operator.equals(">") || operator.equals("<") || operator.equals(">=") || operator.equals("<=")) {
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						int a;
						a=0;
						a++;
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (oldType.equals("boolean")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("void")) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("short")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short")) {
							oldType.operandOrOperator.typeFullNameAfterOperation = "int";
							curType.operandOrOperator.typeFullNameAfterOperation = "int";
							oldType.str = "boolean";
						}
						else if (curType.equals("int")) {
							//oldType = new CodeStringEx("boolean");
							oldType.operandOrOperator.typeFullNameAfterOperation = "int";
							oldType.str = "boolean";
						}
						else if (curType.equals("long")) {
							// ����Ʈ�ڵ忡�� int �񱳹ۿ� �����Ƿ� oldType, curType ��� int�� �ٲ۴�.
							oldType.operandOrOperator.typeFullNameAfterOperation = "long";
							oldType.str = "boolean";
						}
						else if (curType.equals("float")) {
							// ����Ʈ�ڵ忡�� int �񱳹ۿ� �����Ƿ� oldType, curType ��� int�� �ٲ۴�.
							oldType.operandOrOperator.typeFullNameAfterOperation = "float";
							oldType.str = "boolean";
						}
						else if (curType.equals("double")) {
							oldType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
						}
						
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("byte") || oldType.equals("char") || oldType.equals("short")) {
					else if (oldType.equals("int")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short")) {
							// ����Ʈ�ڵ忡�� int �񱳹ۿ� �����Ƿ� oldType, curType ��� int�� �ٲ۴�. 
							curType.operandOrOperator.typeFullNameAfterOperation = "int";
							oldType.str = "boolean";
						}
						else if (curType.equals("int")) {
							oldType.str = "boolean";
						}
						else if (curType.equals("long")) {
							oldType.operandOrOperator.typeFullNameAfterOperation = "long";
							oldType.str = "boolean";
						}
						else if (curType.equals("float")) {
							//oldType = new CodeStringEx("boolean");
							oldType.operandOrOperator.typeFullNameAfterOperation = "float";
							oldType.str = "boolean";
						}
						else if (curType.equals("double")) {
							oldType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
						}
						
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("int")) {
					else if (oldType.equals("long")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char") || curType.equals("short")) {
							// ����Ʈ�ڵ忡�� int �񱳹ۿ� �����Ƿ� oldType, curType ��� int�� �ٲ۴�.
							curType.operandOrOperator.typeFullNameAfterOperation = "long";
							oldType.str = "boolean";
						}
						else if (curType.equals("int")) {
							curType.operandOrOperator.typeFullNameAfterOperation = "long";
							oldType.str = "boolean";
						}
						else if (curType.equals("long")) {
							oldType.str = "boolean";
						}
						else if (curType.equals("float")) {
							//oldType = new CodeStringEx("boolean");
							oldType.operandOrOperator.typeFullNameAfterOperation = "float";
							oldType.str = "boolean";
						}
						else if (curType.equals("double")) {
							oldType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
						}
						
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("long")) {
					else if (oldType.equals("float")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char")|| curType.equals("short")) {
							curType.operandOrOperator.typeFullNameAfterOperation = "float";
							oldType.str = "boolean";
						}
						else if (curType.equals("int")) {
							curType.operandOrOperator.typeFullNameAfterOperation = "float";
							oldType.str = "boolean";
						}
						else if (curType.equals("long")) {
							curType.operandOrOperator.typeFullNameAfterOperation = "float";
							oldType.str = "boolean";
							//oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("float")) {
							oldType.str = "boolean";
							//oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("double")) {
							oldType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
							//oldType = new CodeStringEx("boolean");
						}
						
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("float")) {
					else if (oldType.equals("double")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char")|| curType.equals("short")) {
							curType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
						}
						else if (curType.equals("int")) {
							curType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
						}
						else if (curType.equals("long")) {
							curType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
						}
						else if (curType.equals("float")) {
							curType.operandOrOperator.typeFullNameAfterOperation = "double";
							oldType.str = "boolean";
							//oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("double")) {
							oldType.str = "boolean";
							//oldType = new CodeStringEx("boolean");
						}
						
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("double")) {
					
					else if (oldType.equals("java.lang.String")) {
						// ���� ���۷���� String���� �ٲ��.
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("char")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
				} // for (i=1; i<listOfTypes.count; i++) {
				
				// ���ÿ��� ������ 2���� ���۷��带 ������.
				listOfTypes.count -= 2;
				//listOfVarUses.count -= 2;
				
				return oldType;
			} //if (listOfTypes.count==2) {
		} // if (operator.equals("<") || operator.equals(">") || operator.equals("<=") || operator.equals(">=")) {
		
		// ^, <<, >>, |, &, ~(������, ����) �� ����-������ �����ϴ�.
		if (operator.equals("<<") || operator.equals(">>") || operator.equals("<<<") || operator.equals(">>>") ||
			operator.equals("&") || operator.equals("|") || operator.equals("^")) {
			if (operator.equals("|")) {
				int a;
				a=0;
				a++;
			}
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (oldType.equals("boolean")) {
						if (curType.equals("boolean")) {							
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("void")) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else if (oldType.equals("int") || oldType.equals("short") || oldType.equals("long")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte")) {
							allowsOperator(oldType, curType, operator);
							// curType�� oldType���� �ٲ��.
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("int")) {
							allowsOperator(oldType, curType, operator);
							if (oldType.equals("short")) {
								// oldType�� curType���� �ٲ��.
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
								oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
							}
							else if (oldType.equals("long")) {
								// curType�� oldType���� �ٲ��.
								curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
							}
						}
						else if (curType.equals("short")) {
							// ���� ���۷���� int�� �ٲ��.
							allowsOperator(oldType, curType, operator);
							if (oldType.equals("int") || oldType.equals("long")) {
								// curType�� oldType���� �ٲ��.
								curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
							}
						}
						else if (curType.equals("long")) {
							// ���� ���۷���� long���� �ٲ��.							
							allowsOperator(oldType, curType, operator);
							if (oldType.equals("long")==false) {
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
								oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
							}
						}
						else if (curType.equals("float") || curType.equals("double")) {
							// ���� ���۷���� float�� double���� �ٲ��.
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("char")) {
							// ���� ���۷���� int�� �ٲ��.
							allowsOperator(oldType, curType, operator);
							curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
						}
						else if (curType.equals("java.lang.String")) {
							// ���� ���۷���� String���� �ٲ��.
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("int") || oldType.equals("short") || oldType.equals("long")) {
					else if (oldType.equals("float") || oldType.equals("float")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							// ���� ���۷���� float�� �ٲ��.
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("double")) {
							// ���� ���۷���� double���� �ٲ��.
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("char")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {							
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("float") || oldType.equals("float")) {
					
					else if (oldType.equals("byte") || oldType.equals("char")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							// ���� ���۷���� ���� Ÿ������ �ٲ��.
							allowsOperator(oldType, curType, operator);
							oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
							oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
						}
						else if (curType.equals("float") || curType.equals("double")) {
							// ���� ���۷���� ���� Ÿ������ �ٲ��.
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte")) {
							allowsOperator(oldType, curType, operator);
							if (oldType.equals("char")) {
								curType.operandOrOperator.typeFullNameAfterOperation = oldType.str;
							}
						}
						else if (curType.equals("char")) {
							allowsOperator(oldType, curType, operator);
							if (oldType.equals("byte")) {
								oldType.setStrAndTypeFullName(curType.str, curType.typeFullName);
								oldType.operandOrOperator.typeFullNameAfterOperation = curType.str;
							}
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("java.lang.String")) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("char")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
				} // for (i=1; i<listOfTypes.count; i++) {
				
				// ���ÿ��� ������ 2���� ���۷��带 ������.
				listOfTypes.count -= 2;
				//listOfVarUses.count -= 2;
				
				// oldType�� operator�� Ÿ������ �ٲ۴�.
				if (operator.value!=null) {
					oldType.setStrAndTypeFullName(operator.typeFullName, operator.typeFullName);
				}
				return oldType;
			} //if (listOfTypes.count==2) {
		}//if (operator.equals("^") || operator.equals("<<") || operator.equals(">>") || 
		//operator.equals("&") || operator.equals("|")) {
		
		// &&, ||, !(����) float-float�� �Ұ����ϴ�.boolean-boolean�� �����ϴ�.
		if (operator.equals("&&") || operator.equals("||")) {
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (oldType.equals("boolean")) {
						if (curType.equals("boolean")) {
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("void")) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else if (oldType.equals("int")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("short")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("long")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("char")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("float")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("double")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("char")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("double")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("double")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("char")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("byte") || oldType.equals("char")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("char")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("java.lang.String")) {
						// ���� ���۷���� String���� �ٲ��.
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (oldType.equals("byte") || curType.equals("char")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
				} // for (i=1; i<listOfTypes.count; i++) {
				
				// ���ÿ��� ������ 2���� ���۷��带 ������.
				listOfTypes.count -= 2;
				//listOfVarUses.count -= 2;
				
				return oldType;
			} //if (listOfTypes.count==2) {
		}//if (operator.equals("&&") || operator.equals("||")) {
		
		
		if (operator.equals("==") || operator.equals("!=")) {
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (oldType.equals("boolean")) {
						if (curType.equals("boolean")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("void")) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else if (oldType.equals("int") || oldType.equals("short") || oldType.equals("long")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("short")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("long")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("byte") || curType.equals("char")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("int")) {
					else if (oldType.equals("float")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("float")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("double")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("byte") || curType.equals("char")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("float")) {
					else if (oldType.equals("double")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("float")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("double")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("byte") || curType.equals("char")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}//else if (oldType.equals("double")) {
					else if (oldType.equals("byte") || oldType.equals("char")) {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("byte") || curType.equals("char")) {
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("java.lang.String")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}
					else if (oldType.equals("java.lang.String")) {
						// ���� ���۷���� String���� �ٲ��.
						//FindVarUseParams v = (FindVarUseParams) listOfVarUses.list[i];
						//v.fullnameTypeCastByOperator = oldType;
						//return oldType;
						if (curType.equals("null")) { // if (str==null) ���� ���ÿ��� str, "null", ==
							oldType = new CodeStringEx("boolean");
						}
						else if (curType.equals("java.lang.String")) { // if (str1==str2) ���� ���ÿ��� str1, str2, ==
							oldType = new CodeStringEx("boolean");
						}
						else if (compiler.IsDefaultType(curType)) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else { // if (str==obj)
							boolean b = TypeCast.isCompatibleType(compiler, oldType, curType, 0, null);
							if (b==false) {
								Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
						}
					}
					else {
						if (curType.equals("boolean")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("void")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("int") || curType.equals("short") || curType.equals("long")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("float") || curType.equals("double")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("byte") || curType.equals("char")) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else if (curType.equals("java.lang.String")) {
							boolean b = TypeCast.isCompatibleType(compiler, oldType, curType, 0, null);
							if (b==false) {
								Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
							else {
								oldType = new CodeStringEx("boolean");
							}
						}
						else {
							//Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							boolean b = TypeCast.isCompatibleType(compiler, oldType, curType, 0, null);
							if (b==false) {
								Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
								listOfTypes.count -= 2;
								return new CodeStringEx("null");
							}
							else {
								oldType = new CodeStringEx("boolean");
							}
						}
					}
				} // for (i=1; i<listOfTypes.count; i++) {
				
				// ���ÿ��� ������ 2���� ���۷��带 ������.
				listOfTypes.count -= 2;
				//listOfVarUses.count -= 2;
				
				return oldType;
			} //if (listOfTypes.count==2) {
		}//if (operator.equals("==") || operator.equals("!=")) {
		
		
		else if (operator.equals("instanceof")) {
			if (listOfTypes.count>1) {
				oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
				if (oldType==null) {
					Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
					listOfTypes.count -= 2;
					return new CodeStringEx("null");
				}
				oldType.operandOrOperator.affectedBy_left = operator;
				oldType.operandOrOperator.affectedBy = operator;
				operator.affectsLeft = oldType.operandOrOperator;
				for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
					curType = (CodeStringEx) listOfTypes.getItem(i);
					if (curType==null) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					curType.operandOrOperator.affectedBy_right = operator;
					curType.operandOrOperator.affectedBy = operator;
					operator.affectsRight = curType.operandOrOperator;
					if (compiler.IsDefaultType(oldType)) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else {
						//else if (sender instanceof MenuProblemList) 
						boolean b = TypeCast.isCompatibleType(compiler, oldType, curType, 1, null);
						if (b==false) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						else {
							oldType = new CodeStringEx("boolean");
						}
					}
				}// for (i=1; i<listOfTypes.count; i++) {
				
				// ���ÿ��� ������ 2���� ���۷��带 ������.
				listOfTypes.count -= 2;
				//listOfVarUses.count -= 2;
				
				return oldType;
			} //if (listOfTypes.count>1) {
		}//if (operator.equals("instanceof")) {
		
		else if (operator.str.contains("=")) { // =, +=, -= ��
		//else if (CompilerHelper.IsAssignOperator(op1, op2, op3))
			if (operator.indicesInSrc!=null && operator.indicesInSrc.getItem(0)==1950) {
				int a;
				a=0;
				a++;
			}
			
			if (operator.count>1) {
				boolean operatorError = false;
				CodeStringEx op1 = new CodeStringEx(""+operator.str.charAt(0));
				CodeStringEx op2 = null;
				if (op1.equals("<")) {
					
					if (operator.str.length()!=3) operatorError = true;
					else if (operator.str.charAt(1)!='<') operatorError = true;
					if (operatorError) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid operator : ("+operator.str+") "));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					else {// '<<='
						op1 = new CodeStringEx("<<");
					}
				}
				if (operatorError==false) {
					/*// "<<=", "+=", "-=" ���� ���� ���Կ������� ���
					CodeStringEx type = getTypeOfOperator(compiler, funcCall, listOfTypes, op1);
					return type;*/
				}
			}//if (operator.count>1) {
			//else { // '='
				if (listOfTypes.count>1) {
					oldType = (CodeStringEx) listOfTypes.getItem(listOfTypes.count-2);
					if (oldType==null) {
						Compiler.errors.add(new Error(compiler, startIndex, endIndex, "invalid expression : ("+operator.str+") "+"null"));
						listOfTypes.count -= 2;
						return new CodeStringEx("null");
					}
					oldType.operandOrOperator.affectedBy_left = operator;
					oldType.operandOrOperator.affectedBy = operator;
					operator.affectsLeft = oldType.operandOrOperator;
					for (i=listOfTypes.count-1; i<listOfTypes.count; i++) {
						curType = (CodeStringEx) listOfTypes.getItem(i);
						if (curType==null || (curType!=null && curType.equals(""))) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, 
								"invalid expression : ("+operator.str+") "+oldType+", "+"null"));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
						curType.operandOrOperator.affectedBy_right = operator;
						curType.operandOrOperator.affectedBy = operator;
						operator.affectsRight = curType.operandOrOperator;
						if (TypeCast.isCompatibleType(compiler, oldType, curType, 1, null)==false) {
							Compiler.errors.add(new Error(compiler, startIndex, endIndex, 
									"invalid expression : ("+operator.str+") "+oldType+", "+curType));
							listOfTypes.count -= 2;
							return new CodeStringEx("null");
						}
					}// for (i=1; i<listOfTypes.count; i++) {
					
					// ���ÿ��� ������ 2���� ���۷��带 ������.
					listOfTypes.count -= 2;
					//listOfVarUses.count -= 2;
					
					return oldType;
				} //if (listOfTypes.count>1) {
			//}
		}//else if (operator.str.contains("=")) { // =, +=, -= ��
		
		
		Compiler.errors.add(new Error(compiler, startIndex, endIndex, 
				"invalid operator : ("+operator.str+") "));
		return new CodeStringEx("null");
	}//getTypeOfOperator()


/**value�� ũ��� ������ ���� �� Ÿ���� �����Ѵ�.*/
public static String getType(long value) {
	if (Byte.MIN_VALUE<=value && value<=Byte.MAX_VALUE) return "byte";
	else if (Short.MIN_VALUE<=value && value<=Short.MAX_VALUE) return "short";
	else if (Integer.MIN_VALUE<=value && value<=Integer.MAX_VALUE) return "int";
	else if (Long.MIN_VALUE<=value && value<=Long.MAX_VALUE) return "long";
	
	return "long";
}


/** ���� ����� ���ؼ� ������ ������ �Ͽ� �� ���� operator�� value�� �����Ѵ�. 
 * number1, number2�� ���ڻ���� �ƴϸ� false�� �����Ѵ�.
 * ���� ���� operator�� value�� ����ȴ�.*/
public static 
	boolean allowsOperator(CodeStringEx number1, CodeStringEx number2, CodeStringEx operator) {
		if (number1==null) return false;
		if (number1.str==null) return false;
		
		try {
		if ((number1.str.equals("float") || number1.str.equals("double"))==false) {
			if ((operator.equals("+")  && operator.isPlusOrMinusForOne) || 
					(operator.equals("-") && operator.isPlusOrMinusForOne)) {
				try {
					int i = Integer.parseInt(number1.value);
					String strValue = operator.str + number1.value;
					int r = Integer.parseInt(strValue);
					operator.value = String.valueOf(r);
					return true;
				}catch(Exception e) {
					return false;
				}
			} // ���׿�����
			else if ((operator.equals("+") && operator.isPlusOrMinusForOne==false) || 
					(operator.equals("-") && operator.isPlusOrMinusForOne==false) || 
					operator.equals("*") || operator.equals("/") ||	operator.equals("%")) {
				int i1;
				try {
					i1 = Integer.parseInt(number1.value);
				}catch(Exception e) {
					return false;
				}	
				if (operator.equals("+")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1+i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("-")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1-i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("*")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1*i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("/")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1/i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				
			}//else if ((operator.equals("+") && operator.isPlusOrMinusForOne==false) || 
			//(operator.equals("-") && operator.isPlusOrMinusForOne==false) || 
			//operator.equals("*") || operator.equals("/") ||	operator.equals("%")) {
			else if (operator.equals("^") || 
					operator.equals("<<") || operator.equals(">>") || operator.equals("<<<") || operator.equals(">>>") ||
					operator.equals("&") || operator.equals("|")) {
				int i1;
				try {
					i1 = Integer.parseInt(number1.value);
				}catch(Exception e) {
					return false;
				}	
				if (operator.equals("^")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1^i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("<<")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1<<i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals(">>")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1>>i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("&")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1&i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("|")) {
					try {
						int i2 = Integer.parseInt(number2.value);
						String strValue = String.valueOf(i1|i2);
						int r = Integer.parseInt(strValue);
						operator.value = String.valueOf(r);
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				
			}//else if (operator.equals("^") || 
			//operator.equals("<<") || operator.equals(">>") || operator.equals("<<<") || operator.equals(">>>") ||
			//operator.equals("&") || operator.equals("|")) {
		}
		else { // float, double
			if ((operator.equals("+")  && operator.isPlusOrMinusForOne) || 
					(operator.equals("-") && operator.isPlusOrMinusForOne)) {
				try {
					float i = Float.parseFloat(number1.value);
					String strValue = operator.str + number1.value;
					float r = Float.parseFloat(strValue);
					operator.value = String.valueOf(r);
					return true;
				}catch(Exception e) {
					return false;
				}
			} // ���׿�����
			else if ((operator.equals("+") && operator.isPlusOrMinusForOne==false) || 
					(operator.equals("-") && operator.isPlusOrMinusForOne==false) || 
					operator.equals("*") || operator.equals("/") ||	operator.equals("%")) {
				float f1;
				try {
					f1 = Float.parseFloat(number1.value);
				}catch(Exception e) {
					return false;
				}	
				if (operator.equals("+")) {
					try {
						float f2 = Float.parseFloat(number2.value);
						String strValue = String.valueOf(f1+f2);
						operator.value = strValue;
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("-")) {
					try {
						float f2 = Float.parseFloat(number2.value);
						String strValue = String.valueOf(f1-f2);
						operator.value = strValue;
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("*")) {
					try {
						float f2 = Float.parseFloat(number2.value);
						String strValue = String.valueOf(f1*f2);
						operator.value = strValue;
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				else if (operator.equals("/")) {
					try {
						float f2 = Float.parseFloat(number2.value);
						String strValue = String.valueOf(f1/f2);
						operator.value = strValue;
						return true;							
					}catch(Exception e) {
						return false;
					}
				}
				
			}//else if ((operator.equals("+") && operator.isPlusOrMinusForOne==false) || 
			//(operator.equals("-") && operator.isPlusOrMinusForOne==false) || 
			//operator.equals("*") || operator.equals("/") ||	operator.equals("%")) {
			else if (operator.equals("^")) {
				return false;
			}
				
		}
		}finally {
			if (operator.value!=null) {
				if (operator.value.contains(".")==false) {
					long value = Long.parseLong(operator.value);
					operator.typeFullName = getType(value);
				}
				else {
					if (number1!=null && number1.typeFullName!=null && 
							number2!=null && number2.typeFullName!=null) {
						// float, double
						if (number1.typeFullName.equals("double") || number2.typeFullName.equals("double")) {
							operator.typeFullName = "double";
						}
						else {
							operator.typeFullName = "float";
						}
					}
					else {
						operator.typeFullName = "float";
					}
				}
			}
		}
		return false;
	}//allowsOperator()


	/** fullname�� ���� Ŭ�������� String toString()�Լ��� �����ϴ��� Ȯ���Ѵ�.*/
	public static boolean toStringFuncExists(Compiler compiler, String fullname) {
		if (fullname==null || fullname.equals("")) return false;
		FindClassParams c = CompilerHelper.loadClass(compiler, fullname);
		if (c==null) return false;
		int i;
		for (i=0; i<c.listOfFunctionParams.count; i++) {
			FindFunctionParams func = (FindFunctionParams) c.listOfFunctionParams.getItem(i);
			if (func.name.equals("toString")) {
				if (func.returnType==null) continue;
				if (func.returnType.equals("java.lang.String")) return true;
			}
		}
		for (i=0; i<c.listOfFunctionParamsInherited.count; i++) {
			FindFunctionParams func = (FindFunctionParams) c.listOfFunctionParamsInherited.getItem(i);
			if (func.name.equals("toString")) {
				if (func.returnType==null) continue;
				if (func.returnType.equals("java.lang.String")) return true;
			}
		}
		return false;
	}


}