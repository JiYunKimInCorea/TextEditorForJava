package com.gsoft.common.gui;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.View;

import com.gsoft.common.ColorEx;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.CommonGUI_SettingsDialog;
import com.gsoft.common.IO;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.IO.FileHelper;
import com.gsoft.common.IO.TextFormat;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.Size;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.Util.BufferByte;
import com.gsoft.common.gui.Buttons.Button;
import com.gsoft.common.gui.EditText.Edit;
import com.gsoft.common.gui.EditText.ScrollMode;
import com.gsoft.common.gui.Menu.MenuType;
import com.gsoft.common.interfaces.OnTouchListener;
import com.gsoft.common.R.R;

/**ViewEx�� createSettingsDialog(View view)���� �����Ǿ� 
 * CommonGUI_SettingsDialog.settingsDialog�� ����ȴ�.*/
public class SettingsDialog extends Dialog  implements OnTouchListener {
	static int[] colors = {Color.WHITE, Color.RED
	};
	static String[] namesOfColorButtons = {"White", "Red"
	};
	static String[] textesOfColorButtons = {"EditText Color", "Keyboard Color"
	};
	
	float scaleOfGapX = 0.05f;
	
	float scaleOfTitleBar = 0.1f;
	
	// static�� button
	float scaleOfColorButtonsX = (1-scaleOfGapX*3) / 2;
	float scaleOfColorButtonsY = 0.07f;
	
	float scaleOfOKButtonX = (1-scaleOfGapX*3) / 2;
	float scaleOfOKButtonY = 0.07f;
	
	float scaleOfstaticEditTextDirectory = 0.07f;
	
	float scaleOfbuttonTextSaveFormatY = 0.07f;
	
	Static staticButtonTextSaveFormat;
	
	Button buttonTextSaveFormat;
	
	Static staticIsTripleBuffering;
	
	Button buttonIsTripleBuffering;
	
	float scaleOfbuttonIsTripleBuffering = 0.07f;
	
	Static staticEditTextDirectory;
	
	/** ¦����°�� Static, Ȧ����°�� Button*/
	Control[] controlsOfSettings = new Control[namesOfColorButtons.length*2];
	
	ColorDialog colorDialog = CommonGUI.colorDialog;
	//public int[] selectedColor = {Color.WHITE, Color.RED};
	
	
	int indexOfSelectedButton;
	
	/** �ڿ� '/'�� �ٴ°��� �����Ѵ�. ���� ��� /sdcard/adroid/ */
	public EditText editTextDirectory;	
	Button buttonFileExplorer;
	
	float scaleOfstaticTextSaveFormatX = 0.4f;
	
	float scaleOfEditTextDirectoryX = 0.7f;
	float scaleOfButtonFileExplorerX =  1 - (scaleOfEditTextDirectoryX+scaleOfGapX*3);
	
	// scaleOfstaticEditTextDirectory�� ��ģ ũ��, ���߿� ���� ���̸� ����Ҷ��� 
	// scaleOfstaticEditTextDirectory�� ���ش�.
	float scaleOfEditTextDirectoryY = 0.11f + scaleOfstaticEditTextDirectory;
	
	float scaleOfButtonPageControllerY = 0.05f;
	
	float scaleOfButtonPageControllerX = 0.15f;
	
	
	// ������ ���� gap ����
	float scaleOfGapY = (1-(scaleOfTitleBar + scaleOfColorButtonsY*2  +	scaleOfEditTextDirectoryY + 
			scaleOfOKButtonY + scaleOfbuttonTextSaveFormatY + scaleOfbuttonIsTripleBuffering + scaleOfButtonPageControllerY)) / 8;
	
	
	Button buttonPageController;
	
	public static String[] namesOfMenuTextSaveFormat = {"UTF-8", "UTF-16", "MS-949"};
	
	Menu menuTextSaveFormat;
	boolean enablesMenuTextSaveFormat;
	
	/** �ؽ�Ʈ�������� utf-8:0, utf-16:1, ms-949(ksc):2�̴�.*/
	//public int textSaveFormat = 0;
	
	Panel panelControls;
	
	//boolean isTripleBuffering;
	
	/** Ŭ����ĳ�ø� ����ϴ��� ����*/
	float scaleOfStaticUsesClassCacheX = this.scaleOfstaticTextSaveFormatX;
	float scaleOfButtonUsesClassCacheX = this.scaleOfstaticTextSaveFormatX;
	float scaleOfUsesClassCacheY = this.scaleOfbuttonTextSaveFormatY;
	
	/** child ���μ����� ����ؼ� �ڹٹ����� ���� true(MDI), 
	 * �װԾƴ϶� �������μ������� ���� false(SDI)*/
	float scaleOfStaticUsesChildCompilerProcessX = this.scaleOfstaticTextSaveFormatX;
	float scaleOfButtonUsesChildCompilerProcessX = this.scaleOfstaticTextSaveFormatX;
	float scaleOfUsesChildCompilerProcessY = this.scaleOfbuttonTextSaveFormatY;
	
	
	/** ���� ����ϴ� Ŭ���� ���ϵ��� �����带 ����Ͽ� �̸� �ε��ϴ��� ����*/
	float scaleOfStaticLoadsClassesFrequentlyUsedAdvancelyX = this.scaleOfstaticTextSaveFormatX;
	float scaleOfButtonLoadsClassesFrequentlyUsedAdvancelyX = this.scaleOfstaticTextSaveFormatX;
	float scaleOfLoadsClassesFrequentlyUsedAdvancelyY = this.scaleOfbuttonTextSaveFormatY;
	
	float scaleOfStaticEnablesScreenKeyboardX = scaleOfStaticLoadsClassesFrequentlyUsedAdvancelyX;
	float scaleOfButtonEnablesScreenKeyboardX = scaleOfButtonLoadsClassesFrequentlyUsedAdvancelyX;
	float scaleOfEnablesScreenKeyboard = scaleOfLoadsClassesFrequentlyUsedAdvancelyY;
	
	float scaleOfStaticEnablesUnzipLibraryX = scaleOfStaticLoadsClassesFrequentlyUsedAdvancelyX;
	float scaleOfButtonEnablesUnzipLibraryX = scaleOfButtonLoadsClassesFrequentlyUsedAdvancelyX;
	float scaleOfEnablesUnzipLibrary = scaleOfLoadsClassesFrequentlyUsedAdvancelyY;
	
	
	float scaleOfGapXBetweenPageControllers = (1-(scaleOfButtonPageControllerX*3)) / 4;
	
	private Button buttonPageController2;
	private Static staticUsesClassCache;
	private Button buttonUsesClassCache;
	private Static staticUsesChildCompilerProcess;
	private Button buttonUsesChildCompilerProcess;
	private Static staticLoadsClassesFrequentlyUsedAdvancely;
	private Button buttonLoadsClassesFrequentlyUsedAdvancely;
	private Static staticEnablesScreenKeyboard;
	private Button buttonEnablesScreenKeyboard;
	private Static staticEnablesUnzipLibrary;
	private Button buttonEnablesUnzipLibrary;
	private Panel panelControls2;
	
	
	private Button buttonPageController3;
	private Static staticShowsCopyRight;
	public Button buttonShowsCopyRight;
	private Panel panelControls3;
	
	
	void setEnablesShowsCopyRight(boolean showsCopyRight) {
		this.buttonShowsCopyRight.Select(showsCopyRight);
		if (showsCopyRight) this.buttonShowsCopyRight.setText("enabled");
		else this.buttonShowsCopyRight.setText("disabled");
	}
	
	void setIsTripleBuffering(boolean isTripleBuffering) {
		this.buttonIsTripleBuffering.Select(isTripleBuffering);
		if (isTripleBuffering) this.buttonIsTripleBuffering.setText("enabled");
		else this.buttonIsTripleBuffering.setText("disabled");
	}
	
	void setUsesClassCache(boolean usesClassCache) {
		this.buttonUsesClassCache.Select(usesClassCache);
		if (usesClassCache) this.buttonUsesClassCache.setText("enabled");
		else this.buttonUsesClassCache.setText("disabled");
	}
	
	void setUsesChildCompilerProcess(boolean usesChildProcess) {
		//this.usesChildCompilerProcess = usesChildProcess;
		this.buttonUsesChildCompilerProcess.Select(usesChildProcess);
		if (usesChildProcess) this.buttonUsesChildCompilerProcess.setText("enabled");
		else this.buttonUsesChildCompilerProcess.setText("disabled");
	}
	
	void setLoadsClassesFrequentlyUsedAdvancely(boolean loadsClassesFrequentlyUsedAdvancely) {
		//this.loadsClassesFrequentlyUsedAdvancely = loadsClassesFrequentlyUsedAdvancely;
		this.buttonLoadsClassesFrequentlyUsedAdvancely.Select(loadsClassesFrequentlyUsedAdvancely);
		if (loadsClassesFrequentlyUsedAdvancely) this.buttonLoadsClassesFrequentlyUsedAdvancely.setText("enabled");
		else this.buttonLoadsClassesFrequentlyUsedAdvancely.setText("disabled");
	}
	
	void setEnablesScreenKeyboard(boolean enablesScreenKeyboard) {
		//this.loadsClassesFrequentlyUsedAdvancely = loadsClassesFrequentlyUsedAdvancely;
		this.buttonEnablesScreenKeyboard.Select(enablesScreenKeyboard);
		if (enablesScreenKeyboard) this.buttonEnablesScreenKeyboard.setText("enabled");
		else this.buttonEnablesScreenKeyboard.setText("disabled");
	}
	
	void setEnablesUnzipLibrary(boolean enablesUnzipLibrary) {
		//this.loadsClassesFrequentlyUsedAdvancely = loadsClassesFrequentlyUsedAdvancely;
		this.buttonEnablesUnzipLibrary.Select(enablesUnzipLibrary);
		if (enablesUnzipLibrary) this.buttonEnablesUnzipLibrary.setText("enabled");
		else this.buttonEnablesUnzipLibrary.setText("disabled");
	}
	
	
	/**ViewEx�� sized()���� createSettingsDialog(View view)�� ȣ��Ǿ� �����ǰ� 
	 * CommonGUI_SettingsDialog.settingsDialog�� ����ȴ�.*/
	public static SettingsDialog createSettingsDialog(View view) {
		if (CommonGUI_SettingsDialog.settingsDialog!=null) 
			return CommonGUI_SettingsDialog.settingsDialog;
		int width = view.getWidth();
		int height = view.getHeight();
		int w = (int) (width*0.8f);
		int h = (int) (height*0.8f);
		int x = width/2 - w/2;
		int y = height/2 - h/2;
		Rectangle bounds = new Rectangle(x,y,w,h);
		CommonGUI_SettingsDialog.settingsDialog = new SettingsDialog(view, bounds);
		//Control.colorDialog.setOnTouchListener(this);
		CommonGUI_SettingsDialog.settingsDialog.setIsTripleBuffering(CommonGUI_SettingsDialog.settings.isTripleBuffering);
		return CommonGUI_SettingsDialog.settingsDialog;
	}
	
	
	public static class Settings {
		/** 0:backColor, 1:Keyboard Color*/
		public int[] selectedColor = {Color.WHITE, Color.RED};
		/** ����Ʈ �н�*/
		public String pathAndroid = Control.pathAndroid;
		/** ���� ����� finish()�� ���ϰ� ���������� 0, ������ 1*/
		public int isFinishingWhenExitingPrevly = 0;
		
		public boolean isTripleBuffering = false;
		
		/** isTripleBuffering�� true�̰� ����������� �����ϴ�.*/
		public Config bufferedImageType = Config.RGB_565;
		
		/** usesClassCache�� false�̸� Ŭ���� ĳ�ø� ������ Ŭ������ �ҽ� ���� �ڿ��� �����Ѵ�.*/
		public boolean usesClassCache = false;
		
		/** child ���μ����� ����ؼ� �ڹٹ����� ���� true(MDI), 
		 * �װԾƴ϶� �������μ������� ���� false(SDI)*/
		public boolean usesChildCompilerProcess = false;
		
		/** ���� ����ϴ� Ŭ���� ���ϵ��� �����带 ����Ͽ� �̸� �ε��ϴ��� ����*/
		public boolean loadsClassesFrequentlyUsedAdvancely = false;
		public int textSaveFormat;
		
		/** backup_settings ���Ͽ� ���� ��� ����Ʈ�� 800, 700�̴�. �ȵ���̵忡���� �������Ѵ�. �����쿡����*/
		public int viewWidth = 800;
		/** backup_settings ���Ͽ� ���� ��� ����Ʈ�� 800, 700�̴�.�ȵ���̵忡���� �������Ѵ�. �����쿡����*/
		public int viewHeight = 700;
		
		/** ȭ�� Ű���尡 �������� ����*/
		public boolean EnablesScreenKeyboard = false;
		
		/** ���α׷� ���۽� gsoft.zip, project.zip ���� ���������� �������� �����Ѵ�.*/
		public boolean EnablesUnzipLibrary = true;
		
		public boolean EnablesShowsCopyRight = true;
		
		public Settings() {
			/*if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava)) {
				EnablesScreenKeyboard = false;
			}
			else {//�ȵ���̵�
				EnablesScreenKeyboard = true;
			}*/
		}
	}
	
	
	void createMenuTextSaveFormat() {
		
		int viewWidth = view.getWidth();
		int viewHeight = view.getHeight();
		int x, y;
		int width=(int) (viewWidth*0.6f);
		int height=(int) (viewHeight*0.3f);
		x = viewWidth/2-width/2;
		y = viewHeight/2-height/2;
		Rectangle boundsMenuTextSaveFormat = new Rectangle(x,y,width,height);  
		menuTextSaveFormat = new MenuWithClosable("MenuTextSaveFormat", boundsMenuTextSaveFormat, 
				MenuType.Vertical, this, namesOfMenuTextSaveFormat, new Size(3,3), true, this);
	}
	

	public SettingsDialog(Object owner, Rectangle bounds) {
		super(owner, bounds);
		// TODO Auto-generated constructor stub
		this.bounds = bounds;
		heightTitleBar = (int) (bounds.height*scaleOfTitleBar);
		
		
		this.isTitleBarEnable = true;
		this.Text = "Settings";
		
		int heightOfGap = (int)(bounds.height * scaleOfGapY);
		int widthOfGap = (int)(bounds.width * scaleOfGapX);
		int alpha = 255;
		
		this.backColor = Color.CYAN;
		setBackColor(backColor);
		
		Edit.setBackColor(Color.WHITE);
		
		int colorOfButton = ColorEx.darkerOrLighter(Color.WHITE, -100);
		
		int widthOfGapBetweenButtonPageControllers = 
				(int) (bounds.width * this.scaleOfGapXBetweenPageControllers);
		int x, y, width, height;
		
		
		/////////////////////////// Page 1 ���� /////////////////////////
		
		width = (int) (bounds.width * scaleOfButtonPageControllerX);
		height = (int) (bounds.height * scaleOfButtonPageControllerY);
		x = bounds.x + widthOfGapBetweenButtonPageControllers;
		y = bounds.y + heightTitleBar + heightOfGap;
		
		buttonPageController  = new Button(owner, "PageSet 1", "PageSet 1", 
				Color.DKGRAY, new Rectangle(x,y,width,height), false, alpha, true, 0.0f, null, Color.CYAN);
		buttonPageController.setBackColor(Color.DKGRAY);
		buttonPageController.setOnTouchListener(this);
		
		
		
		width = (int) (bounds.width * scaleOfColorButtonsX);
		height = (int) (bounds.height * scaleOfColorButtonsY);
		x = bounds.x;
		y = buttonPageController.bounds.bottom();
		
		
		Rectangle boundsOfColorButtons=null;
		
		int i, j, k=0;
		for (j=0; j<namesOfColorButtons.length; j++) {
			y += heightOfGap;
			x = bounds.x; 
			for (i=0; i<2; i++) {				
				x += widthOfGap;
				boundsOfColorButtons = new Rectangle(x, y,width,height);
				//k = j*1+i;
				if (i%2==0) {
					Static text = new Static(owner, textesOfColorButtons[j], textColor, boundsOfColorButtons);
					controlsOfSettings[k] = text;
				}
				else {
					Button button  = new Button(owner, namesOfColorButtons[j], namesOfColorButtons[j], 
							colors[j], boundsOfColorButtons, false, alpha, true, 0.0f, null, Color.CYAN);
					controlsOfSettings[k] = button;
					button.ColorSelected = Color.DKGRAY;				
					button.setOnTouchListener(this);
				}
				k++;
				x += width;
			}
			y += height;
		}
		
		int widthOfGapOfTextSaveFormat = (int) ((1 - 2 * scaleOfstaticTextSaveFormatX) * bounds.width / 3);
		
		width = (int) (bounds.width * this.scaleOfstaticTextSaveFormatX);
		height = (int) (bounds.height * this.scaleOfbuttonTextSaveFormatY);
		x = bounds.x + widthOfGapOfTextSaveFormat;
		y = boundsOfColorButtons.bottom() + heightOfGap;
		Rectangle boundsOfstaticButtonTextSaveFormat = new Rectangle(x,y,width,height);
		
		this.staticButtonTextSaveFormat = new Static(owner, "Text Save Format", textColor, boundsOfstaticButtonTextSaveFormat);
		
		
		width = (int) (bounds.width * this.scaleOfstaticTextSaveFormatX);
		height = (int) (bounds.height * this.scaleOfbuttonTextSaveFormatY);
		x = boundsOfstaticButtonTextSaveFormat.right() + widthOfGapOfTextSaveFormat;
		y = boundsOfColorButtons.bottom() + heightOfGap;
		Rectangle boundsOfButtonTextSaveFormat = new Rectangle(x,y,width,height);
		
		this.buttonTextSaveFormat  = new Button(owner, "textSaveFormat", "textSaveFormat", 
				Color.WHITE, boundsOfButtonTextSaveFormat, false, alpha, true, 0.0f, null, Color.CYAN);
		buttonTextSaveFormat.setOnTouchListener(this);
		
		this.createMenuTextSaveFormat();
		this.menuTextSaveFormat.setOnTouchListener(this);
		
		
		
		x = bounds.x + widthOfGapOfTextSaveFormat;
		y = boundsOfstaticButtonTextSaveFormat.bottom() + heightOfGap;
		Rectangle boundsOfstaticIsTripleBuffering = new Rectangle(x,y,width,height);
		
		this.staticIsTripleBuffering = new Static(owner, "IsTripleBuffering", textColor, boundsOfstaticIsTripleBuffering);
		
		
		x = boundsOfstaticIsTripleBuffering.right() + widthOfGapOfTextSaveFormat;
		Rectangle boundsOfButtonIsTripleBuffering = new Rectangle(x,y,width,height);
		
		this.buttonIsTripleBuffering  = new Button(owner, "IsTripleBuffering", "enabled", 
				Color.WHITE, boundsOfButtonIsTripleBuffering, true, alpha, true, 0.0f, null, Color.CYAN);
		buttonIsTripleBuffering.toggleable = true;
		buttonIsTripleBuffering.setOnTouchListener(this);
		
		
		
		
		width = (int) (bounds.width * this.scaleOfEditTextDirectoryX);
		height = (int) (bounds.height * this.scaleOfstaticEditTextDirectory);
		x = bounds.x + widthOfGap;
		y = boundsOfstaticIsTripleBuffering.bottom() + heightOfGap;
		Rectangle boundsOfstaticEditTextDirectory = new Rectangle(x,y,width,height);
		
		this.staticEditTextDirectory = new Static(owner, "SDK directory", textColor, boundsOfstaticEditTextDirectory);
		
		
		// staticEditTextDirectory�� ���� �ٷ� �Ʒ��� boundsOfEditTextDirectory�� ������ ��´�.
		width = (int) (bounds.width * this.scaleOfEditTextDirectoryX);
		// ������ ũ�⸦ scaleOfEditTextDirectoryY�� ũ�⿡�� scaleOfstaticEditTextDirectory�� ũ�⸦ ��
		// ũ��� �����Ѵ�. ����) scaleOfGapY�� ����Ҷ� gapY�� ������ 4���� �����ѰͰ� ���Ѵ�.
		height = (int) (bounds.height * (this.scaleOfEditTextDirectoryY-this.scaleOfstaticEditTextDirectory));
		x = bounds.x + widthOfGap;
		y = boundsOfstaticEditTextDirectory.bottom()/* + heightOfGap*/;
		Rectangle boundsOfEditTextDirectory = new Rectangle(x,y,width,height);
		
		width = (int) (bounds.width * this.scaleOfButtonFileExplorerX);
		height = boundsOfEditTextDirectory.height;
		x = boundsOfEditTextDirectory.right() + widthOfGap;
		Rectangle boundsOfButtonFileExplorer = new Rectangle(x,y,width,height);
		
		/*EditText(boolean hasToolbarAndMenuFontSize, boolean isDockingOfToolbarFlexiable, Object owner, 
				String name, RectangleF paramBounds, float fontSize, 
				boolean isSingleLine, CodeString text, ScrollMode scrollMode, int backColor) {*/
		this.editTextDirectory = new EditText(false, false, this, "Directory", boundsOfEditTextDirectory, 
				boundsOfEditTextDirectory.height*0.5f, true, 
				new CodeString("",Color.BLACK), ScrollMode.VScroll, Color.WHITE);
		editTextDirectory.isReadOnly = true;
		
		this.buttonFileExplorer = new Button(owner, "Explorer", "Explorer", 
				colorOfButton, boundsOfButtonFileExplorer, false, alpha, true, 0.0f, null, Color.CYAN);
		buttonFileExplorer.setOnTouchListener(this);
		
		
		
		
		// ���������� ��Ʈ�ѵ��� ��� �г��� �����.
		x = bounds.x;
		y = this.buttonPageController.bounds.bottom();
		width = bounds.width;
		height = boundsOfEditTextDirectory.bottom() - y;
		
		panelControls = new Panel(new Rectangle(x,y,width,height));
		for (k=0; k<controlsOfSettings.length; k++) {
			panelControls.add(controlsOfSettings[k]);
		}
		panelControls.add(staticButtonTextSaveFormat);
		panelControls.add(buttonTextSaveFormat);
		// �޴��� setHides(false)�� �ϸ� ���ÿ� ��ϵǾ� �ڵ������� �׷����Ƿ�
		// ���� �ʴ´�.
		//panelControls.add(menuTextSaveFormat);
		panelControls.add(staticIsTripleBuffering);
		panelControls.add(buttonIsTripleBuffering);
		panelControls.add(staticEditTextDirectory);
		panelControls.add(editTextDirectory);
		panelControls.add(buttonFileExplorer);
		
		/////////////////////////// Page 1 �� /////////////////////////
		
		
		/////////////////////////// Page 2 ���� /////////////////////////
		
		width = (int) (bounds.width * scaleOfButtonPageControllerX);
		height = (int) (bounds.height * scaleOfButtonPageControllerY);
		x = buttonPageController.bounds.right() + widthOfGapBetweenButtonPageControllers;
		y = bounds.y + heightTitleBar + heightOfGap;
		
		buttonPageController2  = new Button(owner, "PageSet 2", "PageSet 2", 
				Color.DKGRAY, new Rectangle(x,y,width,height), false, alpha, true, 0.0f, null, Color.CYAN);
		buttonPageController2.setBackColor(Color.DKGRAY);
		buttonPageController2.setOnTouchListener(this);
		
		
		width = (int) (bounds.width * this.scaleOfStaticUsesClassCacheX);
		height = (int) (bounds.height * this.scaleOfUsesClassCacheY);
		x = bounds.x + widthOfGapOfTextSaveFormat;
		y = buttonPageController2.bounds.bottom() + heightOfGap;
		
		this.staticUsesClassCache = new Static(owner, "Uses Class Cache", textColor, new Rectangle(x,y,width,height));
		
		
		width = (int) (bounds.width * this.scaleOfstaticTextSaveFormatX);
		height = (int) (bounds.height * this.scaleOfbuttonTextSaveFormatY);
		x = staticUsesClassCache.bounds.right() + widthOfGapOfTextSaveFormat;
		
		this.buttonUsesClassCache  = new Button(owner, "UsesClassCache", "UsesClassCache", 
				Color.WHITE, new Rectangle(x,y,width,height), true, alpha, true, 0.0f, null, Color.CYAN);
		buttonUsesClassCache.toggleable = true;
		buttonUsesClassCache.setOnTouchListener(this);
		
		
		
		
		x = bounds.x + widthOfGapOfTextSaveFormat;
		width = (int) (bounds.width * this.scaleOfStaticUsesChildCompilerProcessX);
		height = (int) (bounds.height * this.scaleOfUsesChildCompilerProcessY);
		y = staticUsesClassCache.bounds.bottom() + heightOfGap;		
		this.staticUsesChildCompilerProcess = new Static(owner, "Uses child process", textColor, new Rectangle(x,y,width,height));
		
		
		x = staticUsesChildCompilerProcess.bounds.right() + widthOfGapOfTextSaveFormat;		
		this.buttonUsesChildCompilerProcess  = new Button(owner, "Uses child process", "Uses child process", 
				Color.WHITE, new Rectangle(x,y,width,height), true, alpha, true, 0.0f, null, Color.CYAN);
		buttonUsesChildCompilerProcess.toggleable = true;
		buttonUsesChildCompilerProcess.setOnTouchListener(this);
		
		
		x = bounds.x + widthOfGapOfTextSaveFormat;
		width = (int) (bounds.width * this.scaleOfStaticLoadsClassesFrequentlyUsedAdvancelyX);
		height = (int) (bounds.height * this.scaleOfLoadsClassesFrequentlyUsedAdvancelyY);
		y = staticUsesChildCompilerProcess.bounds.bottom() + heightOfGap;		
		this.staticLoadsClassesFrequentlyUsedAdvancely = new Static(owner, "Loads classes advancely", textColor, new Rectangle(x,y,width,height));
		
		
		x = staticLoadsClassesFrequentlyUsedAdvancely.bounds.right() + widthOfGapOfTextSaveFormat;		
		this.buttonLoadsClassesFrequentlyUsedAdvancely  = new Button(owner, "LoadsClassesFrequentlyUsedAdvancely", "LoadsClassesFrequentlyUsedAdvancely", 
				Color.WHITE, new Rectangle(x,y,width,height), true, alpha, true, 0.0f, null, Color.CYAN);
		buttonLoadsClassesFrequentlyUsedAdvancely.toggleable = true;
		buttonLoadsClassesFrequentlyUsedAdvancely.setOnTouchListener(this);
		
		
		
		x = bounds.x + widthOfGapOfTextSaveFormat;
		width = (int) (bounds.width * this.scaleOfStaticEnablesScreenKeyboardX);
		height = (int) (bounds.height * this.scaleOfEnablesScreenKeyboard);
		y = staticLoadsClassesFrequentlyUsedAdvancely.bounds.bottom() + heightOfGap;		
		this.staticEnablesScreenKeyboard = new Static(owner, "Enables screen keyboard", textColor, new Rectangle(x,y,width,height));
		
		
		x = staticEnablesScreenKeyboard.bounds.right() + widthOfGapOfTextSaveFormat;		
		this.buttonEnablesScreenKeyboard  = new Button(owner, "EnablesScreenKeyboard", "EnablesScreenKeyboard", 
				Color.WHITE, new Rectangle(x,y,width,height), true, alpha, true, 0.0f, null, Color.CYAN);
		buttonEnablesScreenKeyboard.toggleable = true;
		buttonEnablesScreenKeyboard.setOnTouchListener(this);
		
		
		x = bounds.x + widthOfGapOfTextSaveFormat;
		width = (int) (bounds.width * this.scaleOfStaticEnablesUnzipLibraryX);
		height = (int) (bounds.height * this.scaleOfEnablesUnzipLibrary);
		y = staticEnablesScreenKeyboard.bounds.bottom() + heightOfGap;		
		this.staticEnablesUnzipLibrary = new Static(owner, "Enables Unzipping library", textColor, new Rectangle(x,y,width,height));
		
		
		x = staticEnablesUnzipLibrary.bounds.right() + widthOfGapOfTextSaveFormat;		
		this.buttonEnablesUnzipLibrary  = new Button(owner, "EnablesUnzipLibrary", "EnablesUnzipLibrary", 
				Color.WHITE, new Rectangle(x,y,width,height), true, alpha, true, 0.0f, null, Color.CYAN);
		buttonEnablesUnzipLibrary.toggleable = true;
		buttonEnablesUnzipLibrary.setOnTouchListener(this);
		
		
		// ���������� ��Ʈ�ѵ��� ��� �г��� �����.
		x = bounds.x;
		y = this.buttonPageController2.bounds.bottom();
		width = bounds.width;
		height = boundsOfEditTextDirectory.bottom() - y;
		
		panelControls2 = new Panel(new Rectangle(x,y,width,height));
		
		panelControls2.add(staticUsesClassCache);
		panelControls2.add(buttonUsesClassCache);
		panelControls2.add(this.staticUsesChildCompilerProcess);
		panelControls2.add(this.buttonUsesChildCompilerProcess);
		panelControls2.add(this.staticLoadsClassesFrequentlyUsedAdvancely);
		panelControls2.add(this.buttonLoadsClassesFrequentlyUsedAdvancely);
		panelControls2.add(this.staticEnablesScreenKeyboard);
		panelControls2.add(this.buttonEnablesScreenKeyboard);
		panelControls2.add(this.staticEnablesUnzipLibrary);
		panelControls2.add(this.buttonEnablesUnzipLibrary);
		
		panelControls2.setIsOpen(false);
		
		
		/////////////////////////// Page 2 �� /////////////////////////
		
		
		/////////////////////////// Page 3 ���� /////////////////////////
		
		
		width = (int) (bounds.width * scaleOfButtonPageControllerX);
		height = (int) (bounds.height * scaleOfButtonPageControllerY);
		x = buttonPageController2.bounds.right() + widthOfGapBetweenButtonPageControllers;
		y = bounds.y + heightTitleBar + heightOfGap;
		
		buttonPageController3  = new Button(owner, "PageSet 3", "PageSet 3", 
				Color.DKGRAY, new Rectangle(x,y,width,height), false, alpha, true, 0.0f, null, Color.CYAN);
		buttonPageController3.setBackColor(Color.DKGRAY);
		buttonPageController3.setOnTouchListener(this);
		
		
		width = (int) (bounds.width * this.scaleOfStaticUsesClassCacheX);
		height = (int) (bounds.height * this.scaleOfUsesClassCacheY);
		x = bounds.x + widthOfGapOfTextSaveFormat;
		y = buttonPageController3.bounds.bottom() + heightOfGap;
		
		this.staticShowsCopyRight = new Static(owner, "Shows CopyRight", textColor, new Rectangle(x,y,width,height));
		
		
		width = (int) (bounds.width * this.scaleOfstaticTextSaveFormatX);
		height = (int) (bounds.height * this.scaleOfbuttonTextSaveFormatY);
		x = staticShowsCopyRight.bounds.right() + widthOfGapOfTextSaveFormat;
		
		this.buttonShowsCopyRight  = new Button(owner, "ShowsCopyRight", "ShowsCopyRight", 
				Color.WHITE, new Rectangle(x,y,width,height), true, alpha, true, 0.0f, null, Color.CYAN);
		buttonShowsCopyRight.toggleable = true;
		buttonShowsCopyRight.setOnTouchListener(this);
		
		this.setEnablesShowsCopyRight(false/*true*/);
		
		
		// ���������� ��Ʈ�ѵ��� ��� �г��� �����.
		x = bounds.x;
		y = this.buttonPageController3.bounds.bottom();
		width = bounds.width;
		height = boundsOfEditTextDirectory.bottom() - y;
		
		panelControls3 = new Panel(new Rectangle(x,y,width,height));
		
		panelControls3.add(staticShowsCopyRight);
		panelControls3.add(buttonShowsCopyRight);
		
		panelControls3.setIsOpen(false);
		
		
		/////////////////////////// Page 3 �� /////////////////////////
		
		
				
		width = (int) (bounds.width * scaleOfOKButtonX);
		height = (int) (bounds.height * scaleOfOKButtonY);
		x = bounds.x + widthOfGap;
		y = boundsOfEditTextDirectory.bottom() + heightOfGap;
		Rectangle boundsOfButtonOK = new Rectangle(x,y,width,height);
		x = boundsOfButtonOK.right() + widthOfGap;
		Rectangle boundsOfButtonCancel = new Rectangle(x,y,width,height);
		
		controls = new Button[2];
		controls[0] = new Button(owner, NameButtonOk, Control.res.getString(R.string.OK), 
				colorOfButton, boundsOfButtonOK, false, alpha, true, 0.0f, null, Color.CYAN);
		controls[1] = new Button(owner, NameButtonCancel, Control.res.getString(R.string.cancel), 
				colorOfButton, boundsOfButtonCancel, false, alpha, true, 0.0f, null, Color.CYAN);
		// �̺�Ʈ�� �� Ŭ�������� ���� ó��
		controls[0].setOnTouchListener(this);
		controls[1].setOnTouchListener(this);
	}
	
	/*public void open() {
		super.open(true);		
	}*/
	
	
	public void draw(Canvas canvas)
    {
		if (hides) return;
		synchronized(this) {
			try {
		        super.draw(canvas);
		        /*int i;
		        for (i=0; i<controlsOfSettings.length; i++){
		        	controlsOfSettings[i].draw(canvas);
				}
		        this.staticButtonTextSaveFormat.draw(canvas);
		        this.buttonTextSaveFormat.draw(canvas);
		        
		        staticIsTripleBuffering.draw(canvas);
		        buttonIsTripleBuffering.draw(canvas);
		        
		        staticEditTextDirectory.draw(canvas);
		        this.editTextDirectory.draw(canvas);
		        this.buttonFileExplorer.draw(canvas);*/
		        
		        this.buttonPageController.draw(canvas);
		        this.buttonPageController2.draw(canvas);
		        this.buttonPageController3.draw(canvas);
		        this.panelControls.draw(canvas);
		        this.panelControls2.draw(canvas);
		        this.panelControls3.draw(canvas);
			}catch(Exception e) { 	}
    	}
    }
	
	public void open(OnTouchListener listener, boolean isOpen) {
		// slave �� �����Ҷ��� settings�� �ٲ��� ���Ѵ�.
		if (isOpen) {
			if (CommonGUI_SettingsDialog.settings.usesChildCompilerProcess) {
				if (Control.isMasterOrSlave==false) return;
			}
		}
		super.open(isOpen);
		if (isOpen) {
			boolean isTripleBuffering = CommonGUI_SettingsDialog.settings.isTripleBuffering;
			boolean usesClassCache = CommonGUI_SettingsDialog.settings.usesClassCache;
			boolean usesChildCompilerProcess = CommonGUI_SettingsDialog.settings.usesChildCompilerProcess;
			boolean loadsClassesFrequentlyUsedAdvancely = CommonGUI_SettingsDialog.settings.loadsClassesFrequentlyUsedAdvancely;
			boolean enablesScreenKeyboard = CommonGUI_SettingsDialog.settings.EnablesScreenKeyboard;
			boolean enablesUnzipLibrary = CommonGUI_SettingsDialog.settings.EnablesUnzipLibrary;
			
			this.setIsTripleBuffering(isTripleBuffering);
			this.setUsesClassCache(usesClassCache);
			this.setUsesChildCompilerProcess(usesChildCompilerProcess);
			this.setLoadsClassesFrequentlyUsedAdvancely(loadsClassesFrequentlyUsedAdvancely);
			this.setEnablesScreenKeyboard(enablesScreenKeyboard);
			this.setEnablesUnzipLibrary(enablesUnzipLibrary);
			
		}
	}
	
	public static Settings restoreSettings() {
		Context context = Control.activity.getApplicationContext();
		FileInputStream stream=null;
		BufferedInputStream bis=null;
		String absFilename=null;
		Settings settings = null;
		boolean r = false;
		try {
			//File contextDir = context.getFilesDir();
			absFilename = Control.pathGSoftFiles + File.separator + "backup_settings";
			stream = new FileInputStream(absFilename);
			bis = new BufferedInputStream(stream);
			settings = SettingsDialog.load(bis);
			
			r= true;
		} 
		catch (Exception e) {
			settings = new Settings();
			r=false;
		}
		finally {
			Control.pathAndroid = settings.pathAndroid;
			FileHelper.close(bis);
			FileHelper.close(stream);
			if (!r) {
				if (absFilename!=null) {
					//File file = new File(absFilename);
					//file.delete();
				}
			}
		}
		return settings;
	}
	
	
	
	/** �ε�ÿ��� pathAndroid�� ���� '/'�� ����.(����� ���� '/'�� �����Ƿ�)*/
	public static Settings load(InputStream is) {
		Settings settings = new Settings();
		settings.selectedColor[0] = IO.readInt(is, true);
		if (settings.selectedColor[0]==0) {
			settings.selectedColor[0] = Color.WHITE;
		}
		settings.selectedColor[1] = IO.readInt(is, true);
		if (settings.selectedColor[1]==0) {
			settings.selectedColor[1] = Color.RED;
		}
		//settings.isFinishingWhenExitingPrev = IO.readInt(is);
		try {
			BufferByte bufferByte = IO.readUntilNull(is);
			
			//settings.pathAndroid = IO.readString(is, TextFormat.UTF_8);
			settings.pathAndroid = IO.readStringIncludingNull(bufferByte, TextFormat.UTF_8, true);
			if (settings.pathAndroid==null || settings.pathAndroid.equals("")) {
				settings.pathAndroid = Control.pathAndroid;
			}
			String pathAndroid = settings.pathAndroid;
			if (pathAndroid.length()>1 && pathAndroid.charAt(pathAndroid.length()-1)==File.separator.charAt(0)) {
				settings.pathAndroid = pathAndroid.substring(0, pathAndroid.length()-1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			settings.pathAndroid = Control.pathAndroid;
			e.printStackTrace();
		}
		settings.isTripleBuffering = IO.readBoolean(is);
		settings.usesClassCache = IO.readBoolean(is);
		settings.usesChildCompilerProcess = IO.readBoolean(is);
		
		settings.loadsClassesFrequentlyUsedAdvancely = IO.readBoolean(is);
		settings.EnablesScreenKeyboard = IO.readBoolean(is);
		settings.EnablesUnzipLibrary = IO.readBoolean(is);
		
		return settings;
	}
	
	/** CommonGUI_SettingsDialog.settings �� �����Ѵ�.
	 * ����ÿ��� pathAndroid�� ���� '/'�� ������ �����Ѵ�.*/
	public void save(OutputStream os) {
		Settings settings = CommonGUI_SettingsDialog.settings;
		if (settings.selectedColor[0]==0) {
			settings.selectedColor[0] = Color.WHITE;
		}
		IO.writeInt(os, settings.selectedColor[0], true);
		if (settings.selectedColor[1]==0) {
			settings.selectedColor[1] = Color.WHITE;
		}
		IO.writeInt(os, settings.selectedColor[1], true);
		
		//int v = Control.activity.isFinishing() ? 1 : 0;
		//IO.writeInt(os, v);
		
		String pathAndroid = settings.pathAndroid;
		// ������ "/"�� �����Ѵ�.
		if (pathAndroid.length()>1 && pathAndroid.charAt(pathAndroid.length()-1)==File.separator.charAt(0)) {
			pathAndroid = pathAndroid.substring(0, pathAndroid.length()-1);
		}
		IO.writeString(os, pathAndroid, TextFormat.UTF_8, true, true);
		
		IO.writeBoolean(os, settings.isTripleBuffering);
		IO.writeBoolean(os, settings.usesClassCache);
		IO.writeBoolean(os, settings.usesChildCompilerProcess);
		
		IO.writeBoolean(os, settings.loadsClassesFrequentlyUsedAdvancely);
		IO.writeBoolean(os, settings.EnablesScreenKeyboard);
		IO.writeBoolean(os, settings.EnablesUnzipLibrary);
		
	}
	
	public void setSelectedColorOfEditText(int selectedColorOfEditText) {
		//this.selectedColor[0] = selectedColorOfEditText;
		Button button = (Button)controlsOfSettings[1]; 
		button.setText(ColorEx.toString(selectedColorOfEditText));
		button.setBackColor(selectedColorOfEditText);
	}
	
	public void setSelectedColorOfKeyboard(int selectedColor) {
		//this.selectedColor[1] = selectedColor;
		Button button = (Button)controlsOfSettings[3]; 
		button.setText(ColorEx.toString(selectedColor));
		button.setBackColor(selectedColor);
	}
		
    
    @Override
    public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
    	boolean r;
    	int i;
    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
	    	r = super.onTouch(event, scaleFactor);
	    	if (!r) return false;
	    	for (i=0; i<controls.length; i++) {
	    		r = controls[i].onTouch(event, scaleFactor);
	    		if (r) return true;
	    	}
	        /*for (i=0; i<controlsOfSettings.length; i++) {
	        	r = controlsOfSettings[i].onTouch(event, scaleFactor);
	        	if (r) return true;
	        }
	        r = this.buttonTextSaveFormat.onTouch(event, scaleFactor);
	        if (r) return true;
	        r = this.buttonIsTripleBuffering.onTouch(event, scaleFactor);
	        if (r) return true;
	        r = this.editTextDirectory.onTouch(event, scaleFactor);
	        if (r) return true;
	        r = this.buttonFileExplorer.onTouch(event, scaleFactor);
	        if (r) return true;
	        return true;*/
	    	
	    	r = this.buttonPageController.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = this.buttonPageController2.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = this.buttonPageController3.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = this.panelControls.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = this.panelControls2.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	r = this.panelControls3.onTouch(event, scaleFactor);
	    	if (r) return true;
	    	
	    	return true;
    	}
    	return false;
    }   
    
    public void cancel() {
		OK(false);
		open(false);
    }
    
    /** @param textSaveFormat : -1�̸� error, 0�̸� utf-8, 1�̸� utf-16, 2�̸� ms-949*/
    public void setTextSaveFormat(int textSaveFormat) {
    	//this.textSaveFormat = textSaveFormat;
    	if (textSaveFormat==-1) {
    		this.buttonTextSaveFormat.setText("load error");
    	}
    	else {
    		this.buttonTextSaveFormat.setText(namesOfMenuTextSaveFormat[textSaveFormat]);
    	}
    }
    
    public void setEditTextDirectory(String pathAndroid) {
    	this.editTextDirectory.setText(0, new CodeString(pathAndroid, editTextDirectory.textColor));
    }
    
    /** ��ȭ���ڿ��� OK ��ư�� ������ ȣ��ȴ�. 
     * SettingsDialog�� �ִ� ��Ʈ�ѵ��� ������
     * CommonGUI_SettingsDialog.settings�� �����Ѵ�.*/
    public void setSettings() {
    	Settings settings = CommonGUI_SettingsDialog.settings;
		Button colorButton1 = (Button)this.controlsOfSettings[1];
		Button colorButton3 = (Button)this.controlsOfSettings[3];
		settings.selectedColor[0] = colorButton1.backColor;
		settings.selectedColor[1] = colorButton3.backColor;				
						
		settings.pathAndroid = this.editTextDirectory.getText().str;
		settings.isTripleBuffering = this.buttonIsTripleBuffering.isSelected;
		settings.usesClassCache = this.buttonUsesClassCache.isSelected;
		settings.usesChildCompilerProcess = this.buttonUsesChildCompilerProcess.isSelected;
		settings.loadsClassesFrequentlyUsedAdvancely = this.buttonLoadsClassesFrequentlyUsedAdvancely.isSelected;
		settings.EnablesScreenKeyboard = this.buttonEnablesScreenKeyboard.isSelected;
		settings.EnablesUnzipLibrary = this.buttonEnablesUnzipLibrary.isSelected;
		
		// �ȵ���̵��� ��� isTripleBuffering, usesChildCompilerProcess ���� false�� �Ѵ�.
		if (Control.CurrentSystem.equals(Control.CurrentSystemIsAndroid)) {
			settings.isTripleBuffering = false;
			settings.usesClassCache = false;
			settings.usesChildCompilerProcess = false;
		}
    }

	@Override
	public void onTouchEvent(Object sender, MotionEvent e) {
		// TODO Auto-generated method stub
		if (sender instanceof Button) {
			Button button = (Button)sender;
			int i;
			// button�鿡 ���ؼ���, �� static�� �ƴ�
			for (i=1; i<controlsOfSettings.length; i+=2) {
				//if (button.name.equals(namesOfColorButtons[i])) {
				if (button.iName==controlsOfSettings[i].iName) {
					indexOfSelectedButton = i;
					CommonGUI.colorDialog.open(this, true);					
					//selectedColor[i/2] = Control.colorDialog.selectedColor;
					return;
				}
			}
			if (button.iName==controls[0].iName) // OK
            { 
				this.setSettings();
				
				// settings �� ���⿡�� �����Ѵ�. 
				// slave �� �����Ҷ��� settings �� ������ ���ϰ� �Ѵ�.
				this.backupSettings();
				
				OK(true);
            	open(false);
            	callTouchListener(this, null);
            	
            	ThreadAutoTerminating thread = new ThreadAutoTerminating(this);
            	thread.start();
            	
            	
            }
            else if (button.iName==controls[1].iName) // Cancel
            {
            	cancel();
            }
            else if (button.iName==this.buttonFileExplorer.iName) {
            	CommonGUI.fileDialog.isFullScreen = true;
            	CommonGUI.fileDialog.canSelectFileType = false;
            	CommonGUI.fileDialog.isForViewing = true;
            	CommonGUI.fileDialog.setScaleValues();
            	CommonGUI.fileDialog.changeBounds(new Rectangle(0,0,view.getWidth(),view.getHeight()));
            	CommonGUI.fileDialog.createAndSetFileListButtons(CommonGUI.fileDialog.curDir, FileDialog.Category.All);
				//integrationKeyboard.setHides(true);
            	CommonGUI.fileDialog.open(this, "Set SDK Directory");
            	CommonGUI.fileDialog.setOnTouchListener(this);
            }
            else if (button.iName==this.buttonTextSaveFormat.iName) {
            	if (enablesMenuTextSaveFormat) {
            		this.menuTextSaveFormat.open(true);
            	}
            }
            else if (button.iName==this.buttonIsTripleBuffering.iName) {
            	this.setIsTripleBuffering(button.isSelected);
            }
            else if (button.iName==this.buttonPageController.iName) {
            	this.panelControls.setIsOpen(true);
            	this.panelControls2.setIsOpen(false);            	
            	this.panelControls3.setIsOpen(false);
            }
            else if (button.iName==this.buttonPageController2.iName) {
            	this.panelControls.setIsOpen(false);
            	this.panelControls2.setIsOpen(true);
            	this.panelControls3.setIsOpen(false);
            }
            else if (button.iName==this.buttonPageController3.iName) {
            	this.panelControls.setIsOpen(false);
            	this.panelControls2.setIsOpen(false);
            	this.panelControls3.setIsOpen(true);
            }
            else if (button.iName==this.buttonUsesClassCache.iName) {
            	this.setUsesClassCache(button.isSelected);
            }
            else if (button.iName==this.buttonUsesChildCompilerProcess.iName) {
            	this.setUsesChildCompilerProcess(button.isSelected);
            }
            else if (button.iName==this.buttonLoadsClassesFrequentlyUsedAdvancely.iName) {
            	this.setLoadsClassesFrequentlyUsedAdvancely(button.isSelected);
            }
            else if (button.iName==this.buttonEnablesScreenKeyboard.iName) {
            	this.setEnablesScreenKeyboard(button.isSelected);
            }
            else if (button.iName==this.buttonEnablesUnzipLibrary.iName) {
            	this.setEnablesUnzipLibrary(button.isSelected);
            }
            else if (button.iName==this.buttonShowsCopyRight.iName) {
            	this.setEnablesShowsCopyRight(button.isSelected);
            }
            else {
            	if (button.iName==this.menuTextSaveFormat.buttons[0].iName) { // UTF-8
            		this.setTextSaveFormat(0);
            		menuTextSaveFormat.open(false);
            	}
            	else if (button.iName==this.menuTextSaveFormat.buttons[1].iName) { // UTF-16
            		this.setTextSaveFormat(1);
            		menuTextSaveFormat.open(false);
            		
            	}
            	else if (button.iName==this.menuTextSaveFormat.buttons[2].iName) { // MS-949
            		this.setTextSaveFormat(2);
            		menuTextSaveFormat.open(false);
            	}
            }
		}//if (sender instanceof Button) {
		else if (sender instanceof ColorDialog) {
			ColorDialog colorDialog = (ColorDialog)sender;
			//selectedColor[indexOfSelectedButton/2] = colorDialog.selectedColor;
			String strSelectedColor = CommonGUI.colorDialog.strSelectedColor; 
			Button button = (Button)controlsOfSettings[indexOfSelectedButton];
			button.setBackColor(colorDialog.selectedColor);
			button.setText(strSelectedColor);
			
		}
		else if (sender instanceof FileDialog) {
			FileDialog fileDialog = (FileDialog)sender;
			if (fileDialog.isOK) {
				String dir = fileDialog.buttonDir.text;
				this.editTextDirectory.setText(0, new CodeString(dir,Color.BLACK));
			}
		}
		
	}
	
	/** CommonGUI_SettingsDialog.settings �� �����Ѵ�.
	 * ����ÿ��� pathAndroid�� ���� '/'�� ������ �����Ѵ�.*/
	public void backupSettings() {
		Context context = view.getContext();
		FileOutputStream stream=null;
		BufferedOutputStream bos=null;
		boolean r = false;
		String absFilename=null;
		try {
			//File contextDir = context.getFilesDir();
			absFilename = Control.pathGSoftFiles + File.separator + "backup_settings";
			stream = new FileOutputStream(absFilename);
			bos = new BufferedOutputStream(stream/*, IO.DefaultBufferSize*/);
			CommonGUI_SettingsDialog.settingsDialog.save(bos);
			
			//IO.writeInt(bos, v);
			r = true;
		} catch (FileNotFoundException e) {
			r= false;
		}
		catch (Exception e) {
			r = false;
		}
		finally {
			FileHelper.close(bos);
			FileHelper.close(stream);
			if (!r) {
				if (absFilename!=null) {
					File file = new File(absFilename);
					file.delete();
				}
			}
		}
	}
	
	static class ThreadAutoTerminating extends Thread {
		SettingsDialog owner;
		ThreadAutoTerminating(SettingsDialog owner) {
			this.owner = owner;
		}
		public void run() {
			CommonGUI.loggingForMessageBox.setText(true, "Terminating autoly after 3 seconds..",  false);
        	CommonGUI.loggingForMessageBox.setHides(false);
        	Control.view.postInvalidate();
        	
        	try {
				Thread.sleep(3000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        	
        	
        	
        	Control.exit(false);
		}
	}

}
