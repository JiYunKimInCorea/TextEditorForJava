package com.gsoft.common.gui;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.RectF;

import com.gsoft.DataTransfer.pipe.Pipe;
import com.gsoft.common.ByteCode_Types;
import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.CommonGUI;
import com.gsoft.common.CommonGUI_SettingsDialog;
import com.gsoft.common.Compiler_types;
import com.gsoft.common.IO;
import com.gsoft.common.Compiler_types.Language;
import com.gsoft.common.Compiler_gui.MenuClassList;
import com.gsoft.common.Compiler_gui.MenuProblemList;
import com.gsoft.common.Compiler_gui.MenuProblemList_EditText;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.IO.TextFormat;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.Compiler;
import com.gsoft.common.CompilerHelper;
import com.gsoft.common.Compiler_types.HighArray_CodeString;

public class EditText_Compiler extends EditText {
	
	
	
	
	
	public EditText_Compiler(boolean hasToolbarAndMenuFontSize,
			boolean isDockingOfToolbarFlexiable, Object owner, String name,
			Rectangle paramBounds, float fontSize, boolean isSingleLine,
			CodeString text, EditText.ScrollMode scrollMode, int backColor) {
		super(hasToolbarAndMenuFontSize, isDockingOfToolbarFlexiable, owner, name,
				paramBounds, fontSize, isSingleLine, text, scrollMode, backColor);
		// TODO Auto-generated constructor stub
		CommonGUI.editText_compiler = this;
	}
	
	/** resetDocument()�� ȣ���Ͽ� ������ �ٲ𶧸��� �޸𸮸� �����Ѵ�.*/
	public void initialize() {
		resetDocument();
		super.initialize();
	}
	
	public void changeBounds(Rectangle newBounds) {
		super.changeBounds(newBounds);
		if (compiler!=null) {
			compiler.changeBounds();
		}
	}
	
	@Override
    public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
    	boolean r=false;
    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
	    	r = super.onTouch(event, scaleFactor);
	    	if (!r) {
	    		return false;
	    	}
	    	else return true;
    	}
    	else if (event.actionCode==MotionEvent.ActionMove || event.actionCode==MotionEvent.ActionUp) {
    		if (event.actionCode==MotionEvent.ActionUp) {
    		}
    		
			// drag������ scrollBar�̸� scrollBar��, editText��� editText�� �ڵ鸵
			if (capturedControl==this) {// �����˻縦 �����ʰ� ������ ������� �ڽ��� �ڵ鸵�Ѵ�.
				if (event.actionCode==MotionEvent.ActionMove) {
					if (this.compiler!=null) {
		    			Compiler.textViewExpressionTreeAndMessage.setHides(true);
		    		}
				}
				onTouchEvent(this, event);
				return true;
			}
			
						
		}
    	return false;
    }
	
	void toolbar_Listener(Object sender, String buttonName) {
		if (buttonName.equals("S")) {	// ���ٹ�ư
			EditText.Edit.menuFontSize.open(this, true);
			//menuFontSize.setOnTouchListener(this);
			return;
		}
		else if (buttonName.equals("M")) {
			EditText.ScrollMode scrollMode=this.scrollMode; 
			if (scrollMode==EditText.ScrollMode.VScroll) {
				scrollMode = EditText.ScrollMode.Both;
			}
			else {
				scrollMode = EditText.ScrollMode.VScroll;
			}
			this.setScrollMode(scrollMode);
			return;
		}
		else if (buttonName.equals("FN")) {
			EditText.Edit.menuFunction.open(this, true);
			//menuFunction.setOnTouchListener(this);
		}
		else if (buttonName.equals("O")) {
			if (compiler==null && CommonGUI.textViewLogBird!=null) {
				//Control.textViewLogBird.setHides(false);
				CommonGUI.textViewLogBird.open(true);
			}
			else if (compiler!=null && compiler.menuClassList!=null) {
				compiler.menuClassList.open(true);
				compiler.menuClassList.setOnTouchListener(this);
				//Compiler.menuProblemList_EditText.setOnTouchListener(this);
				if (compiler.menuProblemList_EditText!=null) {
					compiler.menuProblemList_EditText.setOnTouchListener(this);
				}
			}
			else if (compiler!=null && compiler.menuClassList==null) {
				CommonGUI.textViewLogBird.open(true);
			}
		}
		else if (buttonName.equals("U")) {
			/*if (lang!=null) {
				if (isModified) {
					//String input = getText();
					boolean hasLogMessage = false;
					//if (Control.loggingForMessageBox.getHides()) {
						Control.loggingForMessageBox.setText(true, "loading...", false);
						Control.loggingForMessageBox.setHides(false);
						hasLogMessage = true;
					//}
					ThreadSetIsProgramCode thread = new ThreadSetIsProgramCode(hasLogMessage, true);
					thread.start();
				}
				else {
					//if (preProcessor!=null) {
						compiler.menuClassList.open(true);
						compiler.menuClassList.setOnTouchListener(this);
					//}
				}
			}*/
		}
		else if (buttonName.equals("R/W")) {
			if (toolbar.buttons[4].isSelected) {
				this.isReadOnly = true;
			}
			else {
				this.isReadOnly = false;
			}
		}
	}
	
	/** .class ���Ͽ��� Ŀ�� ��ǥ�� ���带 ã�´�.*/
	CodeString findWordInClassFile(int cursorPosX, int cursorPosY) {		
		CodeString line = this.textArray[cursorPosY];
		int left, right;
		int i;
		for (i=cursorPosX; i>=0; i--) {
			CodeChar c = line.charAt(i);
			if (c.c==' ' || c.c=='\b' || c.c=='\t' || c.c=='\r' || c.c=='\n') break;
		}
		//if (i<0) i = 0;
		left = i;
		
		for (i=cursorPosX; i<line.count; i++) {
			CodeChar c = line.charAt(i);
			if (c.c==' ' || c.c=='\b' || c.c=='\t' || c.c=='\r' || c.c=='\n') break;
		}
		//if (i>=line.count) i = line.count-1;
		right = i;
		
		CodeString r = null;
		if (left!=right) {
			r = line.substring(left+1, right);
			if (r.count>0 && r.charAt(r.count-1).c==';')
				r = r.substring(0, r.count-1);
		}
		return r;
	}
	
	
	
	
	
	public CodeString getCompileOutput(Language lang) {
		if (compiler!=null) return compiler.strOutput;
		return null;
	}
	
	
	public void setBackColor(int backColor) {
		super.setBackColor(backColor);
		
		if (compiler!=null) {
			compiler.setBackColor(backColor);
		}
		
		int j, i;
		for (j=0; j<numOfLines; j++) {
			CodeString line = textArray[j];
			for (i=0; i<line.count; i++) {
				CodeChar c = line.charAt(i); 
				if (c.color==backColor) {
					c.color = textColor;
				}
			}
		}
		if (EditText.isTripleBuffering) this.drawToImage(mCanvas);
	}
	
	/** ������ �ٲ𶧸��� compiler �� ����ϴ� �޸𸮸� �����Ѵ�. 
	 * Compiler.start2() ȣ��� settings.usesClassCache �� false �̸� Ŭ���� ĳ�ø� ��� �����Ѵ�.
	 * Ŭ���� ĳ�ð� ��� �����ɶ� compiler �� ����ϴ� �޸𸮵� ��� �����ȴ�.*/
	void resetDocument() {
		// ������ �ٲ𶧸��� compiler �� ����ϴ� �޸𸮸� �����Ѵ�.
		if (CommonGUI_SettingsDialog.settings.usesClassCache==false) {
			if (this.compiler!=null) {
				this.compiler.destroy();
				this.compiler = null;
				System.gc();
			}
		}
		
		if (this.textArray!=null) {
			int i;
			for (i=0; i<textArray.length; i++) {
				if (textArray[i]!=null) {
					textArray[i].destroy();
					textArray[i] = new CodeString("", Compiler.textColor);
				}
			}
		}
	}
	
	
	/** ������ �ٲ𶧸��� compiler �� ����ϴ� �޸𸮸� �����Ѵ�. 
	 * Compiler.start2() ȣ��� settings.usesClassCache �� false �̸� Ŭ���� ĳ�ø� ��� �����Ѵ�.
	 * Ŭ���� ĳ�ð� ��� �����ɶ� compiler �� ����ϴ� �޸𸮵� ��� �����ȴ�.*/
	public boolean setIsProgramCode(Compiler_types.Language lang, String filename) {
		
		FileInputStream stream = null;
		BufferedInputStream bis = null;
		try {
			this.lang = lang;
			if (lang!=null) {
				
				if (CommonGUI_SettingsDialog.settings.usesChildCompilerProcess) {
					if (Control.isMasterOrSlave==false) {
						//"rename"-numOfProcess(Control.numOfCurProcess)-�ٲ� filePath
						// ������ ��������.
						Pipe.renameProcess(Control.numOfCurProcess, filename);
						
						stream = new FileInputStream(filename);
						bis = new BufferedInputStream(stream);
						
						String input = null;
						if (lang==Compiler_types.Language.Java)
							input = IO.readString(bis, TextFormat.MS949_Korean);
						else if (lang==Compiler_types.Language.Html)
							input = IO.readString(bis, TextFormat.UTF_8);
						else if (lang==Compiler_types.Language.Class) {
							//input = IO.readString(bis, TextFormat.UTF_8);
						}
						else return false;
						
						this.compiler = new Compiler();
						compiler.start2(input, lang, backColor, filename);
						isModified = false;
						return true;
					}
					else {
						Pipe.createCompilerProcess(filename);
						return true;
					}
				}//if (CommonGUI_SettingsDialog.settings.usesChildCompilerProcess) {
				else {
					stream = new FileInputStream(filename);
					bis = new BufferedInputStream(stream);
					
					String input = null;
					if (lang==Compiler_types.Language.Java)
						input = IO.readString(bis, TextFormat.MS949_Korean);
					else if (lang==Compiler_types.Language.Html)
						input = IO.readString(bis, TextFormat.UTF_8);
					else if (lang==Compiler_types.Language.Class) {
						//input = IO.readString(bis, TextFormat.UTF_8);
					}
					else return false;
					
					this.compiler = new Compiler();
					compiler.start2(input, lang, backColor, filename);
					isModified = false;
					return true;
				}
			}
			return false;
		}catch(Exception e) {
			e.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e);
			return false;
		}finally {
			if (stream!=null)
				try {
					stream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if (bis!=null)
				try {
					bis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	
	
	
	/** EditText�� �̺�Ʈ ������, ���Ŀ� draw�� ȣ��ȴ�*/
	void editText_Listener(Object sender, MotionEvent e) {
		try {
		super.editText_Listener(sender, e);
		
		if (e.actionCode==MotionEvent.ActionDown) {
			if (lang==Language.Java || lang==Language.C) {
				//
				if (compiler==null) return;				
				HighArray_CodeString mBuffer = compiler.mBuffer;
				indexInmBuffer = findWord(cursorPos.x,cursorPos.y);
				if (indexInmBuffer!=-1) {
					CodeString str = mBuffer.getItem(indexInmBuffer);
					CodeString message = null;
					if (str!=null) {
						if (str.equals("{") || str.equals("}")) {
							message = compiler.findParenthesis(mBuffer, indexInmBuffer);
						}
						else {
							message = compiler.findNode(mBuffer, indexInmBuffer);
						}
						if (message!=null && message.count!=0) {														
							Compiler.textViewExpressionTreeAndMessage.initCursorAndScrollPos();
							Compiler.textViewExpressionTreeAndMessage.setText(0, message);
							Compiler.textViewExpressionTreeAndMessage.setHides(false);							
						}
					}
				}
			}//if (lang==Language.Java || lang==Language.C) {
			else if (lang==Language.Class) {
				//CodeString word = findWordInClassFile(cursorPos.x, cursorPos.y);
				CodeString word = null;
				if (compiler==null) return;				
				HighArray_CodeString mBuffer = compiler.mBuffer;
				int indexInmBuffer = findWord(cursorPos.x,cursorPos.y);
				if (indexInmBuffer!=-1) {
					word = mBuffer.getItem(indexInmBuffer);
				}
				if (word!=null) {
					int i;
					boolean found = false;
					ByteCode_Types.ByteCodeInstruction instruction = null;
					for (i=0; i<ByteCode_Types.instructionSet.length; i++) {
						instruction = ByteCode_Types.instructionSet[i];
						if (instruction.mnemonic.equals(word.str)) {
							found = true;
							break;
						}
					}
					if (found) {
						Compiler.textViewExpressionTreeAndMessage.initCursorAndScrollPos();
						Compiler.textViewExpressionTreeAndMessage.setText(0, new CodeString(instruction.message, Compiler.textColor));
						Compiler.textViewExpressionTreeAndMessage.setHides(false);
					}
				}
			}
		}
		}catch(Exception e1) {
			//Log.e("EditText-OnTouchEvent ActionMove", e1.toString());
			e1.printStackTrace();
			CompilerHelper.printStackTrace(CommonGUI.textViewLogBird, e1);
			//return;
		}
		
		// scrollMode�� VScroll���� Both������ ����� ����. 
		// getCursorPos���� ó���ϱ� �����̴�.
		/*try{
		paint.setTextSize(fontSize);
		
		if (e.actionCode==MotionEvent.ActionDown) {
			// ���� ������ �ؽ�Ʈ ��ġ�� backup�Ѵ�.
			if (isSelecting) {
				selectStartLine = selectIndices[0].y;
				selectEndLine = selectIndices[selectIndicesCount-2].y;
			}
						
			isFound = false;
			getCursorPos(e);
			//setToolbarAndCurState(cursorPos);
			isSelecting = false;
			this.selectLenY = 0;
			this.selectP1 = new Point(cursorPos.x,cursorPos.y);
			selectIndicesCount = 0;
			
			//if (preProcessor!=null) {
			if (lang==Language.Java || lang==Language.C) {
				int indexInmBuffer = -1;
				HighArray_CodeString mBuffer = compiler.mBuffer;
				indexInmBuffer = findWord(cursorPos.x,cursorPos.y);
				if (indexInmBuffer!=-1) {
					CodeString str = mBuffer.getItem(indexInmBuffer);
					CodeString message = null;
					if (str!=null) {
						if (str.equals("{") || str.equals("}")) {
							message = compiler.findParenthesis(mBuffer, indexInmBuffer);
						}
						else {
							message = compiler.findNode(mBuffer, indexInmBuffer);
						}
						if (message!=null && message.count!=0) {
														
							Compiler.textViewExpressionTreeAndMessage.initCursorAndScrollPos();
							Compiler.textViewExpressionTreeAndMessage.setText(0, message);
							Compiler.textViewExpressionTreeAndMessage.setHides(false);
							
						}
					}
				}
			}
		}
		}catch(Exception e1) {
			//Log.e("EditText-OnTouchEvent ActionMove", e1.toString());
			e1.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird, e1);
			//return;
		}
		
		int scrollBounds = (int)(view.getHeight() * 0.03f);
		
		try {
		// 0 line   : start, end -> (startX, 0), (endX, ���ÿ����� ù��°(0))
		// 1-Y line : start, end -> (startX, 1-Y), (endX, ���ÿ����� �߰�(1))
		// Y line   : start, end -> (startX, Y), (endX, ���ÿ����� ������(2))
		if (e.actionCode==MotionEvent.ActionMove) {
			getCursorPos(e);
			if (isSelecting) { // �ڵ� ��ũ�� �Ѵ�.				
				// scrollMode�� ������� �ڵ� ��ũ�� �Ѵ�.
				if (e.y>bounds.bottom()-scrollBounds) {
					if (numOfLines>numOfLinesPerPage) {
						//setHeightOfVScrollPos(heightOfvScrollInc);
						vScrollPos++;
						setVScrollBar();
						Point r = cursorPos;
						selectP2 = new Point(r.x,r.y);					
						makeSelectIndices(true, selectP1, selectP2);
						return;
					}							
				}
				else if (e.y<bounds.y){
					if (numOfLines>numOfLinesPerPage) {
						//setHeightOfVScrollPos(-heightOfvScrollInc);
						//setVScrollBar(true);
						vScrollPos--;
						setVScrollBar();
						Point r = cursorPos;
						selectP2 = new Point(r.x,r.y);					
						makeSelectIndices(true, selectP1, selectP2);
						return;
					}
				}
				
				if (scrollMode==ScrollMode.Both) {
					if (e.x>bounds.right()-scrollBounds) {
						float widthOfCurLine = paint.measureText(textArray[cursorPos.y].toString());
						if (widthOfCurLine>widthOfCharsPerPage) {
							//setWidthOfHScrollPos(widthOfhScrollInc);
							widthOfhScrollPos += widthOfhScrollInc;
							setHScrollBar();
							Point r = cursorPos;
							selectP2 = new Point(r.x,r.y);					
							makeSelectIndices(true, selectP1, selectP2);
							return;
						}							
					}
					else if (e.x<bounds.x){
						float widthOfCurLine = paint.measureText(textArray[cursorPos.y].toString());
						if (widthOfCurLine>widthOfCharsPerPage) {
							//setWidthOfHScrollPos(-widthOfhScrollInc);
							//setHScrollBar(true);
							widthOfhScrollPos -= widthOfhScrollInc;
							setHScrollBar();
							Point r = cursorPos;
							selectP2 = new Point(r.x,r.y);					
							makeSelectIndices(true, selectP1, selectP2);
							return;
						}
					}
				}
			}	// if (isSelecting==true)
			Point r = cursorPos;
			isSelecting = true;
			selectP2 = new Point(r.x,r.y);					
			makeSelectIndices(true, selectP1, selectP2);
			
		} // if (e.actionCode==MotionEvent.ActionMove)
		
		
		}catch(Exception e1) {
			//Log.e("EditText-OnTouchEvent ActionMove", e1.toString());
			e1.printStackTrace();
			CompilerHelper.printStackTrace(textViewLogBird, e1);
			return;
		}
		finally {
			// ��ġ�� �ѱ۸��� ���۸� �ʱ�ȭ	
			Hangul.mode = Hangul.Mode.None;
			Hangul.resetBuffer();
		}*/
	}
	
	public synchronized void draw(Canvas canvas) {
		super.draw(canvas);
		
		RectF rectBounds = bounds.toRectF();
		paintOfBorder.setColor(Compiler.keywordColor);
    	canvas.drawRect(rectBounds, paintOfBorder); 
	}
	
	
	public void onTouchEvent(Object sender, MotionEvent e) {
		super.onTouchEvent(sender, e);
		
		if (e==null) {
			// Compiler�� MenuProblemList_EditText�� ����EditText�� ��ġ�� ȣ��
			if (sender instanceof MenuProblemList_EditText) {
				MenuProblemList_EditText list = (MenuProblemList_EditText)sender;
				int countOfNewLineChars = list.countOfNewLineChars;
				list.open(false);
				
				cursorPos.x = 0;
				if (scrollMode==EditText.ScrollMode.VScroll) {
					cursorPos.y = getNumOfLines(0, countOfNewLineChars) + 1;
				}
				else {
					cursorPos.y = countOfNewLineChars;
					cursorPos.x = list.countOfCol;
				}
				
				vScrollPos = cursorPos.y;
				setVScrollPos();
				setVScrollBar();
				if (scrollMode==EditText.ScrollMode.Both) {
					//widthOfhScrollPos = cursorPos.x;
					setHScrollPosFromMenuProblemList();
					setHScrollBar();
					com.gsoft.common.Compiler_types.Error selectedError = list.selectedError;
					CommonGUI.loggingForMessageBox.setText(true, selectedError.msg, false);
					CommonGUI.loggingForMessageBox.open(true);
				}
				
			}
			else if (sender instanceof MenuClassList) {
				MenuClassList classList = (MenuClassList)sender;
				int countOfNewLineChars = classList.countOfNewLineChars;
				classList.open(false);
				
				cursorPos.x = 0;
				if (scrollMode==EditText.ScrollMode.VScroll) {
					cursorPos.y = getNumOfLines(0, countOfNewLineChars) + 1;
				}
				else {
					cursorPos.y = countOfNewLineChars;
				}
				vScrollPos = cursorPos.y;
				setVScrollPos();
				setVScrollBar();
				if (scrollMode==EditText.ScrollMode.Both) {
					widthOfhScrollPos = 0;
					setHScrollPos();
					setHScrollBar();
				}
				
			}
			// Compiler�� MenuProblemList�� ������ư�� ��ġ�� ȣ��
			else if (sender instanceof MenuProblemList) {
				MenuProblemList list = (MenuProblemList)sender;
				int countOfNewLineChars = list.countOfNewLineChars;
				list.open(false);
				
				cursorPos.x = 0;
				if (scrollMode==EditText.ScrollMode.VScroll) {
					cursorPos.y = getNumOfLines(0, countOfNewLineChars) + 1;
				}
				else {
					cursorPos.y = countOfNewLineChars;
				}
				vScrollPos = cursorPos.y;
				setVScrollPos();
				setVScrollBar();
				if (scrollMode==EditText.ScrollMode.Both) {
					widthOfhScrollPos = 0;
					setHScrollPos();
					setHScrollBar();
				}
				
			}
			if (EditText.isTripleBuffering) this.drawToImage(mCanvas);
		}
	}
}
