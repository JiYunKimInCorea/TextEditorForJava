package com.gsoft.common.gui;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Paint.Style;
import android.graphics.RectF;

import com.gsoft.common.ColorEx;
import com.gsoft.common.CommonGUI_SettingsDialog;
import com.gsoft.common.ContentManager;
import com.gsoft.common.Font;
import com.gsoft.common.PaintEx;
import com.gsoft.common.Font.FontSortVert;
import com.gsoft.common.Events.MotionEvent;
import com.gsoft.common.Sizing.Rectangle;
import com.gsoft.common.Sizing.RectangleF;
import com.gsoft.common.Sizing.SizeF;
import com.gsoft.common.Util.Array;
import com.gsoft.common.Util.ArrayList;
import com.gsoft.common.gui.SettingsDialog.Settings;

import android.view.View;

public class Buttons {
	
	public static class TreeNodeButton extends Button {

		public TreeNodeButton(Object owner, String name, String text,
				int backColor, Rectangle srcBounds, boolean selectable,
				int alpha, boolean bRoundRect, float changeValueY, Object addedInfo, int colorOfPlaceOfButtonLying) {
			super(owner, name, text, backColor, srcBounds, selectable, alpha, bRoundRect,
					changeValueY, addedInfo, colorOfPlaceOfButtonLying);
			// TODO Auto-generated constructor stub
		}

		/** Buttons[]*/
		ArrayList listOfChildButtons;
		
	}
	
	public static class ButtonGroup {
		/**��ư�� �����ִ� �׷� �� ��ư���� �ε�����*/ 
	    public Byte[] indicesOfButtonsInGroup;
	    /**�׷� �� ��ư��*/
		public Button[] buttons;
		public int indexOfSelectedButton;
		
		public ButtonGroup(Byte[] indicesOfButtonsInGroup, Button[] buttons) {
			this.indicesOfButtonsInGroup = indicesOfButtonsInGroup;
			this.buttons = buttons;
		}
	}
	
	public static class Button extends Control 
	{
		enum ButtonState
		{    
		    MouseDown,
		    Normal,
		    MouseOver
		}
		
		protected static Settings settings = CommonGUI_SettingsDialog.settings;
		
		public static boolean isTripleBuffering = settings.isTripleBuffering;
		
	    
	    Bitmap texture;
	    ButtonState buttonState;
	    
	    boolean isTextOrImage;
	    float textSize;
	    
	    public boolean selectable;
	    public boolean isSelected;
	    
	    public boolean toggleable;
	            
	    //Object owner;
	    
	    /**text�� ���� ���� ������ ������ setText�� ����Ѵ�*/
	    public String text;
	    float changeValueY;
	    boolean isTextIncludeNewLineChar;
	    int[] arrNewLineCharPos;
	    
	    public boolean bRoundRect;
	    
	    private ButtonGroup buttonGroup;
	    private int indexOfButtonInGroup;
		
		MotionEvent motionEvent;
		
		RectangleF[] arrLocAndSizeOfText = new RectangleF[20];
		int countOfArrLocAndSizeOfText;
		String[] arrSubText = new String[20];
		
		/** ��ư�� �ؽ�Ʈ �ܿ� �ΰ������� �������ִ�.*/
		public Object addedInfo;
		
		int incxForBitmapRendering;
		int incyForBitmapRendering;
	    
	    //2��ư���� ����=50*6+28(��ư����)*7=500,    ���ʹ�ư�� top : 501-160=340/2=170+50=220
	    public static final Rectangle InitMenuButtonBounds = new Rectangle(0, 50+28+50*0, 40, 50);
	    public static final Rectangle InitLineButtonBounds = new Rectangle(0, 50+28*2+50, 40, 50);
	    
	    // public static Rectangle InitProgressBarBackgroundBounds = new Rectangle(877, 50, 40, 501);
	    // 3��ư���� ����=30*4+100(��ư����)*3=420,    ���ʹ�ư�� top : 501-420=80/2=40+50=105
	    public static final Rectangle InitLeftButtonBounds = new Rectangle(0, 50+28*3+50*2, 40, 50); 
	    public static final Rectangle InitRightButtonBounds = new Rectangle(0, 50+28*4+50*3,40,50);
	    public static final Rectangle InitSpaceButtonBounds = new Rectangle(0, 50+28*5+50*4,40,50);
	    public static final Rectangle InitEnterButtonBounds = new Rectangle(0, 50+28*6+50*5,40,50);
	   
	    
	    public static int LeftButton = 0;
	    public static int RightButton = 1;
	    public static int SpaceButton = 2;
	    public static int EnterButton = 3;
	    public static int MenuButton = 4;
	    public static int LineButton = 5;
	    
	    public PaintEx paint = new PaintEx();
	    public Paint paintOfImageButton = new Paint();
	    public Paint paintOfBorder = new Paint();
	
	    //public static Texture2D TextureIsSelected;
	    public int ColorSelected = Color.MAGENTA;
	    public static int ColorMouseDowned = Color.YELLOW;
	    public static int BorderColor = Color.YELLOW;
	    
	    public int textColor;
	    
	    public void setBackColor(int backColor) {
	    	this.backColor = backColor;
	    	textColor = ColorEx.reverseColor(backColor);
	    	ColorSelected = ColorEx.darkerOrLighter(backColor, 0.3f);
	    	//ColorSelected = Color.DKGRAY;
	    	if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
	    			isTripleBuffering) {
	    		this.drawToImage(mCanvas);
	    	}
	    }
	    
	    public boolean isManualOrAutoSize;
	    
	    int colorOfPlaceOfButtonLying;

		private Rectangle oldBounds = new Rectangle(0,0,0,0);
	
	   
	    public void setGroup(ButtonGroup buttonGroup, int indexOfButtonInGroup) {
	    	this.buttonGroup = buttonGroup;
	    	this.indexOfButtonInGroup = indexOfButtonInGroup;
	    }
	       
	
	    // �̹��� ��ư
	    public Button(Object owner, String name, Rectangle srcBounds, int resid, 
	    		boolean selectable,	int alpha)
	    {
	    	super();
	    	this.owner = owner;
	        this.name = name;
	        //this.srcBounds = srcBounds;
	        this.bounds = new Rectangle(srcBounds.x, srcBounds.y, srcBounds.width, srcBounds.height);
	        
	        if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
	    			isTripleBuffering) {
	        	 // �̹����� �׸���
		        this.bitmapForRendering = 
	 					Bitmap.createBitmap((int)this.bounds.width, (int)this.bounds.height, CommonGUI_SettingsDialog.settings.bufferedImageType);
	 			mCanvas = new Canvas(this.bitmapForRendering);
	        }
	     			
	        buttonState = ButtonState.Normal;
	        hides = false;        
	        this.selectable = selectable;        
	        //paint.setStyle(Style.FILL);
	        paintOfImageButton.setStyle(Style.FILL);
	        paintOfImageButton.setAlpha(alpha);
	        texture = ContentManager.LoadBitmap(((View)owner).getContext(), resid);
	        isTextOrImage = false;
	        this.alpha = alpha;
	        paintOfBorder.setStyle(Style.STROKE);
	        paintOfBorder.setColor(ColorEx.darkerOrLighter(Color.LTGRAY, -100));
	        
	        if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
	    			isTripleBuffering) {
		        	drawToImage(mCanvas);
		        }
	    }   
	    
	    // �ؽ�Ʈ ��ư
	    public Button(Object owner, String name, String text, int backColor, Rectangle srcBounds, 
	    		boolean selectable, int alpha, boolean bRoundRect, float changeValueY, Object addedInfo, int colorOfPlaceOfButtonLying)
	    {
	    	super();
	    	this.owner = owner;
	        this.name = name;
	        this.bounds = new Rectangle(srcBounds.x, srcBounds.y, srcBounds.width, srcBounds.height);
	        
	        if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
	    			isTripleBuffering) {
			        // �̹����� �׸���
					this.bitmapForRendering = 
							Bitmap.createBitmap((int)this.bounds.width, (int)this.bounds.height, CommonGUI_SettingsDialog.settings.bufferedImageType);
					mCanvas = new Canvas(this.bitmapForRendering);
		        }
	        
	        paint.setTypeface(Control.typefaceDefault);
	        
	        this.text = text;
	        
	        setBackColor(backColor);
	        //this.srcBounds = srcBounds;
	        
	        buttonState = ButtonState.Normal;
	        hides = false;
	        this.selectable = selectable;
	        
	        paint.setStyle(Style.FILL);
	        isTextOrImage = true;
	        this.alpha = alpha;
	        
	        this.bRoundRect = bRoundRect;
	        if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
	    			isTripleBuffering) {
	        	this.bRoundRect = false;
	        }
	        paintOfBorder.setStyle(Style.STROKE);
	        paintOfBorder.setColor(ColorEx.darkerOrLighter(backColor, -100));
	        this.changeValueY = changeValueY;
	        this.addedInfo = addedInfo;
	        
	        setText(text);
	        
	        if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
	    			isTripleBuffering) {
		        drawToImage(mCanvas);
		    }
	        
	        this.colorOfPlaceOfButtonLying = colorOfPlaceOfButtonLying;
	    }
	    
	    public void changeBounds(Rectangle bounds) {
	    	if (this.oldBounds.equals(bounds)) {
	    		if (text!=null) {
		    		setText(text);
		    	}
	    		return;
	    	}
	    	oldBounds.copy(bounds);
	    	this.bounds = bounds;
	    	
	    	if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
	    			isTripleBuffering) {
			    	// �̹����� �׸���
			    	this.bitmapForRendering = 
							Bitmap.createBitmap((int)this.bounds.width, (int)this.bounds.height, CommonGUI_SettingsDialog.settings.bufferedImageType);
					mCanvas = new Canvas(this.bitmapForRendering);
		    	}
	    				
	    	if (text!=null) {
	    		setText(text);
	    	}
	    }
	    
	    public void changeBoundsFast(Rectangle bounds) {
	    	this.bounds = bounds;
	    	
	    	// �̹����� �׸���
	    	/*this.bitmapForRendering = 
					Bitmap.createBitmap((int)this.bounds.width+1, (int)this.bounds.height+1, null);
			mCanvas = new Canvas(this.bitmapForRendering);*/
	    	
	    }
	    
	    /*public void scale(SizeF scaleFactor) {
	    	bounds.x = (srcBounds.x * scaleFactor.width);
	    	bounds.y = (srcBounds.y * scaleFactor.height);
	    	bounds.width = (srcBounds.width * scaleFactor.width);
	    	bounds.height = (srcBounds.height * scaleFactor.height);
	    	if (isTextOrImage==false) {
	    		texture = Bitmap.createScaledBitmap(texture, (int)bounds.width, (int)bounds.height, false);
	    	}
	    	else {
	    		
	    	}
	    }*/
	    
	    /** ��ư�� ������ ���¸� ���´�.
	     * - toggleable���� : toggleable, selectable ��� true�̴�. toggle�Ѵ�. 
	     * �׷쿡 ������ ���� �ʰ� �ڽ��� ���� ���¸� �����Ѵ�.
	     * - selectable���� : �׷쿡 �����ִ� �ٸ� ��ư�� select���¸� �ʱ�ȭ�ϸ鼭 
	     * �ڽ��� ���û��¸� true�� �ٲ۴�.
	     * - default���� : ���� �ִ� ��� ����� ���� �ʰ� listener�� ȣ���Ѵ�.
	     */
	    public boolean onTouch(MotionEvent event, SizeF scaleFactor) {
	    	boolean r = super.onTouch(event, scaleFactor);
	    	if (!r) return false;
	    	
	    	if (event.actionCode==MotionEvent.ActionDown || event.actionCode==MotionEvent.ActionDoubleClicked) {
	    		SetButtonState(ButtonState.MouseDown);
	    		if (toggleable) {
	    			Toggle();
	    		}
	    		else if (selectable) {
	    			// �׷쿡 ���� ������ �ٸ� ��ư���� ���û��¸� �ʱ�ȭ�ϰ� �ڽ��� ���û��¸�
	    			// true�� �ٲ۴�.
	    			if (buttonGroup!=null) {
	    				/*int i, indexOfButton;
	    				for (i=0; i<buttonGroup.indicesOfButtonsInGroup.length; i++) {
	    					indexOfButton = buttonGroup.indicesOfButtonsInGroup[i];
	    					if (buttonGroup.buttons[indexOfButton].selectable) {
	    						buttonGroup.buttons[indexOfButton].Select(false);
	    					}
	    				}*/
	    				if (buttonGroup.buttons[buttonGroup.indexOfSelectedButton].selectable) {
    						buttonGroup.buttons[buttonGroup.indexOfSelectedButton].Select(false);
    						buttonGroup.indexOfSelectedButton = indexOfButtonInGroup;
    					}
	    			}
	    			Select(true);
	    		}
	    		callTouchListener(this, event);
	    	}
	    	else if (event.actionCode==MotionEvent.ActionMove) {
	    		SetButtonState(ButtonState.MouseOver);
	    	}
	    	else if (event.actionCode==MotionEvent.ActionUp) {
	    		SetButtonState(ButtonState.Normal);
	    	} 
	    	
	    	if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
	    			isTripleBuffering) {
		    		drawToImage(mCanvas);
		    	}
	    	
	    	return true;
	    }
	        
	    
	    
	    public void SetButtonState(ButtonState myButtonState)
	    {
	        buttonState = myButtonState;
	    }
	
	    public void Select(boolean s)
	    {
	    	//if (!toggleable) {
		        if (selectable)
		        {
		        	if (this.text.equals("desktop.ini")) {
		        		int a;
		        		a=0;
		        		a++;
		        	}
		            isSelected = s;
		            
		            if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
			    			isTripleBuffering) {
			            	drawToImage(mCanvas);
			            }
		        }
	    	//}
	    }
	    
	    public void Toggle() {
	    	if (toggleable && selectable) {
	    		isSelected = !isSelected;
	    		if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
		    			isTripleBuffering) {
		    			drawToImage(mCanvas);
		    		}
	    	}
	    }
	    
	    public synchronized void setText(String paramText) {
	    	try{
	    	text = paramText;
	    	isTextIncludeNewLineChar = false;
	    	if (text==null || text.equals("")) return;
	    	
	    	int i;
			int count = 0;
			int textLen = text.length();
			for (i=0; i<textLen; i++) {
				if (text.substring(i,i+1).equals("\n")) {
					isTextIncludeNewLineChar = true;
					count++;    				
				}
			}    		
			if (isTextIncludeNewLineChar) {
				arrNewLineCharPos = new int[count];
				int index;
	    		for (i=0, index=0; i<textLen; i++) {
	    			if (text.substring(i,i+1).equals("\n")) {
	    				arrNewLineCharPos[index++] = i;
	    			}
	    		}
	    		if (bounds.width>bounds.height) {
	    			char[] arrText = text.toCharArray();
	    			for (i=0; i<arrNewLineCharPos.length; i++) {
	    				arrText = Array.Delete(arrText, arrNewLineCharPos[i], 1);
	    				for (int j=i+1; j<arrNewLineCharPos.length; j++) {
	    					arrNewLineCharPos[j]--;
	    				}
	    			}
	    			text = new String(arrText);   
	    			isTextIncludeNewLineChar = false;
	    		}
	    	}
	    	
	    	if (!isTextIncludeNewLineChar) {
	    		if (text.equals("desktop.ini")) {
	    			int a;
	    			a=0;
	    			a++;
	    		}
	    		if (!isManualOrAutoSize) {
		    		arrLocAndSizeOfText[0] = Font.getLocAndTextSize(paint, bounds, 
		    				text, FontSortVert.Middle, changeValueY);
		    		// �������� ������� ��ǥ�̴�.
		    		arrLocAndSizeOfText[0].x -= bounds.x;
		    		arrLocAndSizeOfText[0].y -= bounds.y;
		    		
		    		countOfArrLocAndSizeOfText = 1;
		    		arrSubText[0] = text;
	    		}
	    		else {
	    			arrLocAndSizeOfText[0] = Font.getLocAndTextSizeManual(paint, bounds, 
		    				text, FontSortVert.Middle, changeValueY);
	    			// �������� ������� ��ǥ�̴�.
		    		arrLocAndSizeOfText[0].x -= bounds.x;
		    		arrLocAndSizeOfText[0].y -= bounds.y;
		    		
		    		countOfArrLocAndSizeOfText = 1;
		    		arrSubText[0] = text.substring(0,(int)arrLocAndSizeOfText[0].height);
	    		}
			}
			else {
				int x = bounds.x;
				int width = bounds.width;
				int height = bounds.height / (arrNewLineCharPos.length+1);
				int y = bounds.y+(0*height);    				 
				Rectangle boundsLocal = new Rectangle(x,y,width,height);
				
				int start=0, end;
				start = 0;
				end = arrNewLineCharPos[0];
				String textLocal = text.substring(start, end);
				arrLocAndSizeOfText[0] = Font.getLocAndTextSize(paint, boundsLocal, 
						textLocal, FontSortVert.Middle, changeValueY);
				// �������� ������� ��ǥ�̴�.
	    		arrLocAndSizeOfText[0].x -= bounds.x;
	    		arrLocAndSizeOfText[0].y -= bounds.y;
	    		
	    		countOfArrLocAndSizeOfText = 1;
	    		arrSubText[0] = textLocal;
	    		
				for (i=0; i<arrNewLineCharPos.length; i++) {    				
					y = bounds.y+(i+1)*height;    				 
					boundsLocal = new Rectangle(x,y,width,height);
					if (i==arrNewLineCharPos.length-1) {
						start = arrNewLineCharPos[i]+1;
						end = text.length();
					}
					else {
						start = arrNewLineCharPos[i]+1;
						end = arrNewLineCharPos[i+1];
					}    				
					
					textLocal = text.substring(start, end);				
					arrLocAndSizeOfText[countOfArrLocAndSizeOfText] = 
						Font.getLocAndTextSize(paint, boundsLocal, 
							textLocal, FontSortVert.Middle, changeValueY);
					// �������� ������� ��ǥ�̴�.
		    		arrLocAndSizeOfText[countOfArrLocAndSizeOfText].x -= bounds.x;
		    		arrLocAndSizeOfText[countOfArrLocAndSizeOfText].y -= bounds.y;
		    		
					arrSubText[countOfArrLocAndSizeOfText++] = textLocal;
				}
			}
	    	}
	    	finally {
	    		if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
		    			isTripleBuffering) {
		    			drawToImage(mCanvas);
		    		}
	    	}
		}
	    
	    /** CustomView�� ��Ʈ�ʿ� ��Ʈ���� ���� bitmapForRendering ��Ʈ��(Ʈ���� ���۸�)�� �׸���.
	     * @param canvas : CustomView�� mCanvas(���ο� ��Ʈ���� �����Ƿ� �������۸��̴�.)*/
	    public synchronized void draw(Canvas canvas) {
	    	if (this.iName==134) {
	    		int a;
	    		a=0;
	    		a++;
	    	}
	    	
	    	if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
	    			isTripleBuffering) {
		    	Rect src = (new Rectangle(0,0,bounds.width,bounds.height)).toRect();
				
				RectF dst = this.bounds.toRectF();
				canvas.drawBitmap(this.bitmapForRendering, src, dst, paint);
	    	}
	    	else {
	    		drawCommon(canvas);
	    	}
		}
	    
	    /**isTripleBuffering�� true�̸� mCanvas �ȿ� �ִ� bitmapForRendering ��Ʈ�ʿ� �׸���. 
	     * ��Ʈ���� �������� �����ϹǷ� bounds���� bounds.x�� bounds.y�� ���� �׷��� ��Ʈ�ʿ� �׸� �� �ִ�.<br>
	     * isTripleBuffering�� false�̸� ���� bounds�� �׸���.
	     *  @param canvas : isTripleBuffering�� true�̸� ��Ʈ���� ���� �ִ� mCanvas�̰�<br>
	     *  CustomView�� mCanvas(���ο� ��Ʈ���� �����Ƿ� �������۸��̴�.)
	     *  */
	    public synchronized void drawCommon(Canvas canvas) {
	    	if (this.iName==134) {
	    		int a;
	    		a=0;
	    		a++;
	    	}
	    	synchronized(this) {
	    	try {
	    	if (hides) return;
	    	if (isTextOrImage==false) {	// �̹�����ư    		
		        if (!isSelected)
		        {	        	
		        	paintOfImageButton.setColor(Color.WHITE);
		        	paintOfImageButton.setAlpha(alpha);
		        	Rectangle src = new Rectangle(0,0,texture.getWidth(),texture.getHeight());
		        	//RectangleF dst = this.bounds;
		        	RectF dst;
		        	if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
		        			isTripleBuffering) {
		        		dst = RectangleF.toRectF(bounds, bounds.x, bounds.y);
		        	}
		        	else {
		        		dst = this.bounds.toRectF();
		        	}
		        	canvas.drawBitmap(texture, src.toRect(), dst, paintOfImageButton);
		        	
		        	canvas.drawRect(dst, paintOfBorder);
		        }
		        else
		        {	        	
		        	paintOfImageButton.setColor(ColorSelected);
		        	paintOfImageButton.setAlpha(alpha);
		        	Rectangle src = new Rectangle(0,0,texture.getWidth(),texture.getHeight());
		        	//RectangleF dst = this.bounds;
		        	//RectF dst = RectangleF.toRectF(bounds, bounds.x, bounds.y);
		        	RectF dst;
		        	if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
		        			isTripleBuffering) {
		        		dst = RectangleF.toRectF(bounds, bounds.x, bounds.y);
		        	}
		        	else {
		        		dst = this.bounds.toRectF();
		        	}
		        	canvas.drawBitmap(texture, src.toRect(), dst, paintOfImageButton);
		        	
		        	canvas.drawRect(dst, paintOfBorder);
		        }
	    	}
	    	else {		// �ؽ�Ʈ ��ư
	    		if (!isSelected)
		        {
	    			paint.setColor(backColor);
	    			if (bRoundRect==false) {
	    				//RectF dst = RectangleF.toRectF(bounds, bounds.x, bounds.y);
	    				RectF dst;
			        	if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
			        			isTripleBuffering) {
			        		dst = RectangleF.toRectF(bounds, bounds.x, bounds.y);
			        	}
			        	else {
			        		dst = this.bounds.toRectF();
			        	}
			        	
	    				canvas.drawRect(dst, paint);    				
	    	        	canvas.drawRect(dst, paintOfBorder);
	    			}
	    			else {
	    				float rx = bounds.width * 0.1f;
	    		        float ry = rx;
	    		        //RectF dst = RectangleF.toRectF(bounds, bounds.x, bounds.y);
	    		        RectF dst;
			        	if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
			        			isTripleBuffering) {
			        		dst = RectangleF.toRectF(bounds, bounds.x, bounds.y);
			        	}
			        	else {
			        		dst = this.bounds.toRectF();
			        	}
			        	//paint.setColor(colorOfPlaceOfButtonLying);
			        	//canvas.drawRect(dst, paint); // ��ư �� ����÷�
			        	
			        	paint.setColor(backColor);
	    		        canvas.drawRoundRect(dst, rx, ry, paint);    		        
	    	        	canvas.drawRoundRect(dst, rx, ry, paintOfBorder);
	    			}
		        }
	    		else {    			
	    			paint.setColor(ColorSelected);
	    			if (bRoundRect==false) {
	    				//RectF dst = RectangleF.toRectF(bounds, bounds.x, bounds.y);
	    				RectF dst;
			        	if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
			        			isTripleBuffering) {
			        		dst = RectangleF.toRectF(bounds, bounds.x, bounds.y);
			        	}
			        	else {
			        		dst = this.bounds.toRectF();
			        	}
	    				canvas.drawRect(dst, paint);    				
	    	        	canvas.drawRect(dst, paintOfBorder);
	    	        	
	    	        	
	    			}
	    			else {
	    				float rx = bounds.width * 0.1f;
	    		        float ry = rx;
	    		        //RectF dst = RectangleF.toRectF(bounds, bounds.x, bounds.y);
	    		        RectF dst;
			        	if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
			        			isTripleBuffering) {
			        		dst = RectangleF.toRectF(bounds, bounds.x, bounds.y);
			        	}
			        	else {
			        		dst = this.bounds.toRectF();
			        	}
			        	//paint.setColor(colorOfPlaceOfButtonLying);
			        	//canvas.drawRect(dst, paint); // ��ư �� ����÷�
			        	
			        	paint.setColor(ColorSelected);
	    		        canvas.drawRoundRect(dst, rx, ry, paint);    		        
	    	        	canvas.drawRoundRect(dst, rx, ry, paintOfBorder);
	    	        	
	    			}
	    		}	    		
	    		
				paint.setColor(textColor);
	    		for (int i=0; i<countOfArrLocAndSizeOfText; i++) {
	    			paint.setTextSize(arrLocAndSizeOfText[i].width);
	    			if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
	    					isTripleBuffering) {
		    			// arrLocAndSizeOfText[i].x, arrLocAndSizeOfText[i].y ����
		    			// �������� ������� ��ǥ�� ��������Ƿ� �ٲ� �ʿ䰡 ����.	    			
		        		canvas.drawText(arrSubText[i], arrLocAndSizeOfText[i].x, 
		        				arrLocAndSizeOfText[i].y, paint);
	    			}
	    			else {
	    				canvas.drawText(arrSubText[i], arrLocAndSizeOfText[i].x+bounds.x, 
		        				arrLocAndSizeOfText[i].y+bounds.y, paint);
	    			}
	    		}
	    		
	    	}// �ؽ�Ʈ��ư
	    	}catch(Exception e) {
	    		
	    	}
	    	}
	    	
	    }
	    
	    /**mCanvas �ȿ� �ִ� bitmapForRendering ��Ʈ�ʿ� �׸���. 
	     * ��Ʈ���� �������� �����ϹǷ� bounds���� bounds.x�� bounds.y�� ���� �׷��� ��Ʈ�ʿ� �׸� �� �ִ�.
	     *  @param canvas : ��Ʈ���� ���� �ִ� mCanvas*/
	    public synchronized void drawToImage(Canvas canvas)
	    {
	    	drawCommon(canvas);
	    		
	    }	// draw
	    
	    
	    /** MenuWithScrollBar�� draw()���� ȣ��ȴ�.
	     * isTripleBuffering�� true �̸� CustomView�� ��Ʈ�ʿ� ��Ʈ���� ���� bitmapForRendering ��Ʈ��(Ʈ���� ���۸�)�� �׸���.<br>
	     * isTripleBuffering�� false �̸� CustomView�� ��Ʈ�ʿ� ��Ʈ���� bounds �� �׸���.
	     * @param canvas : CustomView�� mCanvas(���ο� ��Ʈ���� �����Ƿ� �������۸��̴�.)*/
	    public synchronized void draw(Canvas canvas, int x, int y)
	    {
	    	if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava) &&
	    			isTripleBuffering) {
		    	Rect src = (new Rectangle(0,0,bounds.width,bounds.height)).toRect();
				
				RectF dst = Rectangle.toRectF(this.bounds.toRect(), -this.bounds.x + x, -this.bounds.y + y);
				canvas.drawBitmap(this.bitmapForRendering, src, dst, paint);
	    	}
	    	else {
	    		draw(canvas, (float)x, (float)y);
	    	}
			
	    		
	    }	// draw
	    
	    
	    /** MenuWithScrollBar�� draw()���� ȣ��ȴ�.
	     * CustomView�� ��Ʈ�ʿ� ��Ʈ���� bounds �� �׸���.
	     * @param canvas : CustomView�� mCanvas(���ο� ��Ʈ���� �����Ƿ� �������۸��̴�.)*/ 
	    public synchronized void draw(Canvas canvas, float x, float y)
	    {
	    	synchronized(this) {
	    	try {
	    	if (hides) return;
	    	if (isTextOrImage==false) {	// �̹�����ư    		
		        if (!isSelected)
		        {	        	
		        	paintOfImageButton.setColor(Color.WHITE);
		        	paintOfImageButton.setAlpha(alpha);
		        	Rectangle src = new Rectangle(0,0,texture.getWidth(),texture.getHeight());
		        	Rectangle dst = this.bounds;
		        	canvas.drawBitmap(texture, src.toRect(), dst.toRectF(), paintOfImageButton);
		        	
		        	canvas.drawRect(bounds.toRectF(), paintOfBorder);
		        }
		        else
		        {	        	
		        	paintOfImageButton.setColor(ColorSelected);
		        	paintOfImageButton.setAlpha(alpha);
		        	Rectangle src = new Rectangle(0,0,texture.getWidth(),texture.getHeight());
		        	Rectangle dst = this.bounds;
		        	canvas.drawBitmap(texture, src.toRect(), dst.toRectF(), paintOfImageButton);
		        	
		        	canvas.drawRect(bounds.toRectF(), paintOfBorder);
		        }
	    	}
	    	else {		// �ؽ�Ʈ ��ư
	    		if (!isSelected)
		        {
	    			paint.setColor(backColor);
	    			if (bRoundRect==false) {
	    				Rectangle dst = this.bounds;
	    				canvas.drawRect(dst.toRectF(), paint);    				
	    	        	canvas.drawRect(dst.toRectF(), paintOfBorder);
	    			}
	    			else {
	    				float rx = bounds.width * 0.1f;
	    		        float ry = rx;
	    		        Rectangle dst = this.bounds;
	    		        canvas.drawRoundRect(dst.toRectF(), rx, ry, paint);    		        
	    	        	canvas.drawRoundRect(dst.toRectF(), rx, ry, paintOfBorder);
	    			}
		        }
	    		else {    			
	    			paint.setColor(ColorSelected);
	    			if (bRoundRect==false) {
	    				Rectangle dst = this.bounds;
	    				canvas.drawRect(dst.toRectF(), paint);    				
	    	        	canvas.drawRect(dst.toRectF(), paintOfBorder);
	    			}
	    			else {
	    				float rx = bounds.width * 0.1f;
	    		        float ry = rx;
	    		        Rectangle dst = this.bounds;
	    		        canvas.drawRoundRect(dst.toRectF(), rx, ry, paint);    		        
	    	        	canvas.drawRoundRect(dst.toRectF(), rx, ry, paintOfBorder);
	    			}
	    			
	    		}
	    		
	    		
				paint.setColor(textColor);
	    		for (int i=0; i<countOfArrLocAndSizeOfText; i++) {
	    			paint.setTextSize(arrLocAndSizeOfText[i].width);
	        		canvas.drawText(arrSubText[i], x+arrLocAndSizeOfText[i].x, 
	        				y+arrLocAndSizeOfText[i].y, paint);
	    		}
	    		
	    	}// �ؽ�Ʈ��ư
	    	}catch(Exception e) {
	    		
	    	}
	    	}
	    	
	    		
	    }	// draw
	    
	    
	}
}
