package com.gsoft.common;

import com.gsoft.common.Code.CodeChar;
import com.gsoft.common.Code.CodeString;
import com.gsoft.common.Code.CodeStringType;
import com.gsoft.common.Compiler_types.Comment;
import com.gsoft.common.Compiler_types.Error;
import com.gsoft.common.Compiler_types.HighArray_CodeString;
import com.gsoft.common.Compiler_types.IReset;
import com.gsoft.common.Compiler_types.Language;
import com.gsoft.common.Util.ArrayListCodeChar;
import com.gsoft.common.Util.ArrayListIReset;

public class StringTokenizer implements IReset {
	
	static int WordLengthLimit = 70;
	
	public HighArray_CodeString mBuffer;
	
	/** ���ϻ��� �ּ�, ��ť�ּ����� ����Ʈ, ������ ����Ʈ�� ���鶧 ���, Comment[], 
	 * mlistOfFindStatementParams�� ����*/
	ArrayListIReset mlistOfComments = new ArrayListIReset(100);
	
	StringTokenizer() {

	}
	
	/** ���� ��� �� ���� ����, 
     * ����(����, ���), �Ǽ�, ����, ���ڻ��, ������(����, ������, ��ȣ ��)�� �����Ѵ�.
     * ������ �������̴�. ���� id�� ����� ������ �־�� �ȵȴ�. 
     * start2()�� start_onlyInterface()���� ȣ��ȴ�.
	 * @param compiler : CompilerHelper�� loadClassFromSrc_onlyInterface()���� 
	 * compiler.start_onlyInterface(...) �̷��� ȣ���� �ǰ�  start_onlyInterface()����
	 * RegisterPackageName(...)ȣ���� �ϸ�
	 * RegisterPackageName()������ this�� this�� ���� 
	 * CompilerŬ������ ��� ����� compiler�� �������̹Ƿ� ��� �Ǵ� ���̴�.
	 * start2()���� ȣ���� �Ǿ ���������̴�.
	 * @param src : compiler.mBuffer�� ����.*/
    public HighArray_CodeString ConvertToStringArray2(CodeString input, int initMaxLengthOfArray, Language language)
    {
        CodeString word = null;
        ArrayListCodeChar word_wchar = new ArrayListCodeChar(WordLengthLimit);

        CodeString str;     // �ο��ȣ���� ���ڿ�
        ArrayListCodeChar str_wchar = new ArrayListCodeChar(WordLengthLimit);
        
        boolean isComment = false;
        ArrayListCodeChar str_Comment = new ArrayListCodeChar(WordLengthLimit);

        boolean strPutted = false;
        boolean isStrOrChar = true;
        
        
        if (mBuffer==null) {
        	mBuffer = new HighArray_CodeString(initMaxLengthOfArray/10);
        	//mBuffer = new ArrayListCodeString(initMaxLengthOfArray);
        	//mBuffer.resizeInc = initMaxLengthOfArray;
        }
        else {
        	//mBuffer.reset2();
        }
    
        int i, j;
        boolean isSignalOfPosOrNeg = false;
        CodeChar c;
        int startIndexInmBuffer = -1;
    	int endIndexInmBuffer = -1;
    	int len = input.length();

        for (i = 0; i < len; i++)
        {
        	if (i==11215) {
        		int a;
        		a=0;
        		a++;
        	}
        	try{
        	c = input.charAt(i);
        	
        	if (c.c=='\\') {
        		int a;
        		a=0;
        		a++;
        	}
        	
        	// �ּ� "/*" ó��
            if (input.charAt(i).c == '/' && 
            		(i + 1 < input.length() && input.charAt(i + 1).c == '*'))
            {
            	
            	if (!strPutted)
                {
                    //���� ��ū
                	if (word==null && word_wchar.count>0)
                    {
                    	word = new CodeString(word_wchar.getItems(), word_wchar.count);
                        PutTomBuffer(mBuffer, word);
                        word_wchar.reset2();
                        word = null;
                    }
                }
                else//��Ʈ���̸�
                {
                	str_wchar.add(input.charAt(i));
                	continue;
                }
            	
            	int startOfComment = i;
            	int endOfComment = input.length()-1;
            	boolean isDocuComment = false;            	
            	                	
                for (j = i+2; j < input.length(); j++)
                {
                	if (input.charAt(j).c == '*' && 
                			(j + 1 < input.length() && input.charAt(j + 1).c == '/'))
                    {
                		endOfComment = j + 1;
                		break;
                    }
                }
                
                // "/**" ��ť��Ʈ �ּ�,  /**/�� �ƴ�
                if (j<input.length() && i+2<input.length() && input.charAt(i+2).c=='*' && 
                		i+3<input.length() && input.charAt(i+3).c!='/') { 
                	isDocuComment = true;
                }
                
                
                
                int k;
                if (isDocuComment==false) {
                	// "/*" �ֱ�
                	CodeChar[] cs0 = {input.charAt(i)};	// Separator�ֱ�
                	cs0[0].type = CodeStringType.Comment;
                	cs0[0].color = Compiler.commentColor;
                	startIndexInmBuffer = PutTomBuffer(mBuffer, new CodeString(cs0, cs0.length));
                    
                	CodeChar[] cs1 = {input.charAt(i+1)};	// Separator�ֱ�
                	cs1[0].type = CodeStringType.Comment;
                	cs1[0].color = Compiler.commentColor;
                    PutTomBuffer(mBuffer, new CodeString(cs1, cs1.length));
                    
                	int startIndex = startOfComment+2;
                	int endIndex = endOfComment-2;
                	str_Comment.reset2();
                    for (k=startIndex; k<=endIndex; k++) {                    	
                    	CodeChar ch = input.charAt(k);
                    	if (ch.c=='\n' || ch.c=='\r') {
                    		if (str_Comment.count>0) {
	                    		 CodeString comment = new CodeString(str_Comment.getItems(), str_Comment.count);
	                             comment.setType(CodeStringType.Comment);
	                             comment.setColor(Compiler.commentColor);
	                             PutTomBuffer(mBuffer, comment);
	                             str_Comment.reset2();
                    		}
                             
                             CodeChar[] special = {ch};// '\n', '\r'
                             CodeString commentSpecial = new CodeString(special, special.length);
                             commentSpecial.setType(CodeStringType.Comment);
                             commentSpecial.setColor(Compiler.commentColor);
                             PutTomBuffer(mBuffer, commentSpecial);
                    	}
                    	else {
                    		str_Comment.add(ch);
                    	}
                    }
                    // �ּ��� ������ �κ�
                    if (str_Comment.count>0) {
	                    CodeString comment = new CodeString(str_Comment.getItems(), str_Comment.count);
	                    comment.setType(CodeStringType.Comment);
	                    comment.setColor(Compiler.commentColor);
	                    PutTomBuffer(mBuffer, comment);
                    }
                    
                 // "*/" �ֱ�
                	CodeChar[] cs3 = {input.charAt(endOfComment-1)};	// Separator�ֱ�
                	cs3[0].type = CodeStringType.Comment;
                	cs3[0].color = Compiler.commentColor;
                    PutTomBuffer(mBuffer, new CodeString(cs3, cs3.length));
                	CodeChar[] cs4 = {input.charAt(endOfComment)};	// Separator�ֱ�
                	cs4[0].type = CodeStringType.Comment;
                	cs4[0].color = Compiler.commentColor;
                	endIndexInmBuffer = PutTomBuffer(mBuffer, new CodeString(cs4, cs4.length));
                }//if (isDocuComment==false) {
                else {
                	// "/**" �ֱ�
                	CodeChar[] cs0 = {input.charAt(i)};	// Separator�ֱ�
                	cs0[0].type = CodeStringType.DocuComment;
                	cs0[0].color = Compiler.docuCommentColor;
                	startIndexInmBuffer = PutTomBuffer(mBuffer, new CodeString(cs0, cs0.length));
                	
                	CodeChar[] cs1 = {input.charAt(i+1)};	// Separator�ֱ�
                	cs1[0].type = CodeStringType.DocuComment;
                	cs1[0].color = Compiler.docuCommentColor;
                    PutTomBuffer(mBuffer, new CodeString(cs1, cs1.length));
                    CodeChar[] cs2 = {input.charAt(i+2)};	// Separator�ֱ�
                    cs2[0].type = CodeStringType.DocuComment;
                	cs2[0].color = Compiler.docuCommentColor;
                    PutTomBuffer(mBuffer, new CodeString(cs2, cs2.length));
                    
                	int startIndex = startOfComment+3;
                	int endIndex = endOfComment-2;
                	str_Comment.reset2();
                	for (k=startIndex; k<=endIndex; k++) {                		
                    	CodeChar ch = input.charAt(k);
                    	if (ch.c=='\n' || ch.c=='\r') {
                    		if (str_Comment.count>0) {
	                   		 	CodeString comment = new CodeString(str_Comment.getItems(), str_Comment.count);
	                            comment.setType(CodeStringType.DocuComment);
	                            comment.setColor(Compiler.docuCommentColor);
	                            PutTomBuffer(mBuffer, comment);
	                            str_Comment.reset2();
                    		}
                            
                            CodeChar[] special = {ch}; // '\n', '\r'
                            CodeString commentSpecial = new CodeString(special, special.length);
                            commentSpecial.setType(CodeStringType.DocuComment);
                            commentSpecial.setColor(Compiler.docuCommentColor);
                            PutTomBuffer(mBuffer, commentSpecial);
	                   	}
	                   	else {
	                   		str_Comment.add(ch);
	                   	}
                    }
                	// �ּ��� ������ �κ�
                	if (str_Comment.count>0) {
	                	CodeString comment = new CodeString(str_Comment.getItems(), str_Comment.count);
	                    comment.setType(CodeStringType.DocuComment);
	                    comment.setColor(Compiler.docuCommentColor);
	                    PutTomBuffer(mBuffer, comment);
                	}
                    
                 // "*/" �ֱ�
                	CodeChar[] cs3 = {input.charAt(endOfComment-1)};	// Separator�ֱ�
                	cs3[0].type = CodeStringType.DocuComment;
                	cs3[0].color = Compiler.docuCommentColor;
                    PutTomBuffer(mBuffer, new CodeString(cs3, cs3.length));
                	CodeChar[] cs4 = {input.charAt(endOfComment)};	// Separator�ֱ�
                	cs4[0].type = CodeStringType.DocuComment;
                	cs4[0].color = Compiler.docuCommentColor;
                	endIndexInmBuffer = PutTomBuffer(mBuffer, new CodeString(cs4, cs4.length));
                }//if (isDocuComment==false) {
                
                mlistOfComments.add(new Comment(mBuffer, startIndexInmBuffer, endIndexInmBuffer));
                
                i = endOfComment;
                continue;
                
               
            }//if (input.charAt(i).c == '/' && 
    		// (i + 1 < input.length() && input.charAt(i + 1).c == '*'))
        	
            // �ּ� "//" ó��
            else if (input.charAt(i).c == '/' && 
            		(i + 1 < input.length() && input.charAt(i + 1).c == '/'))
            {
            	if (!strPutted)
                {
                    //if (i > 0 && Character.isLetterOrDigit(input.charAt(i - 1).c))    // ���ڳ� ���� �ֱ�
                	if (word==null && word_wchar.count>0)
                    {
                    	word = new CodeString(word_wchar.getItems(), word_wchar.count);
                        PutTomBuffer(mBuffer, word);
                        word_wchar.reset2();
                        word = null;
                    }
                	// "//" �ֱ�
                    CodeChar[] cs = {input.charAt(i)};	// Separator�ֱ�
                    cs[0].type = CodeStringType.Comment;
                	cs[0].color = Compiler.commentColor;
                	startIndexInmBuffer = PutTomBuffer(mBuffer, new CodeString(cs, cs.length));
                	
                    CodeChar[] cs2 = {input.charAt(i+1)};	// Separator�ֱ�
                    cs2[0].type = CodeStringType.Comment;
                	cs2[0].color = Compiler.commentColor;
                    PutTomBuffer(mBuffer, new CodeString(cs2, cs2.length));
                }
                else // strPutted==true
                {
                	str_wchar.add(input.charAt(i));
                	continue;
                }
            	
            	int startOfComment = i;
            	int endOfComment = input.length()-1;     	
            	                	
                for (j = i+2; j < input.length(); j++)
                {
                	if (input.charAt(j).c == '\r' && 
                    		(j + 1 < input.length() && input.charAt(j + 1).c == '\n'))
                    {
                		endOfComment = j + 1;
                		break;
                    }
                	else if (input.charAt(j).c == '\n') {
                		endOfComment = j;
                		break;
                	}
                }
                
                
                
                
                int startIndex = startOfComment+2;
            	int endIndex = endOfComment;
            	
            	int k;
            	str_Comment.reset2();
                for (k=startIndex; k<=endIndex; k++) {                	
                	CodeChar ch = input.charAt(k);
                	if (ch.c=='\n' || ch.c=='\r') {
                		if (str_Comment.count>0) {
	               		 	CodeString comment = new CodeString(str_Comment.getItems(), str_Comment.count);
	                        comment.setType(CodeStringType.Comment);
	                        comment.setColor(Compiler.commentColor);
	                        PutTomBuffer(mBuffer, comment);
	                        str_Comment.reset2();
                		}
                        
                        CodeChar[] special = {ch};// '\n', '\r'
                        CodeString commentSpecial = new CodeString(special, special.length);
                        commentSpecial.setType(CodeStringType.Comment);
                        commentSpecial.setColor(Compiler.commentColor);
                        endIndexInmBuffer = PutTomBuffer(mBuffer, commentSpecial);
	               	}
	               	else {
	               		str_Comment.add(ch);
	               	}
                }
                // �ּ��� ������ �κ�
                if (str_Comment.count>0) {
	                CodeString comment = new CodeString(str_Comment.getItems(), str_Comment.count);
	                comment.setType(CodeStringType.Comment);
	                comment.setColor(Compiler.commentColor);
	                PutTomBuffer(mBuffer, comment);
                }
                
                mlistOfComments.add(new Comment(mBuffer, startIndexInmBuffer, endIndexInmBuffer));
               
                i = endOfComment;
                continue;
            }// �ּ�
        	
			if (c.c=='_') {
        		if (strPutted==false) {
        			word_wchar.add(c);
        		}
        		else {
        			str_wchar.add(c);
        		}
        	}
        	// ������ ���� ��ȣ Ȥ�� ���������� Ȯ���Ѵ�.
			// �������� ��� ������ else ó�� ���� ��ū�� �����ڸ� �ִ´�.
        	else if ((c.c=='-' || c.c=='+')) {
        		isSignalOfPosOrNeg = false;
        		char prev=0, next=0;
        		int prevIndex = CompilerHelper.SkipBlank(input, true, 0, i-1);
        		if (prevIndex!=-1) prev = input.charAt(prevIndex).c;
        		int nextIndex = CompilerHelper.SkipBlank(input, false, i+1, input.count-1);
        		if (nextIndex!=input.count) next = input.charAt(nextIndex).c;
        		/*if ( (prev=='=' || prev=='(' || prev=='[' || prev=='{' || prev==',' || prev==')' || CompilerHelper.IsOperator(prev)) &&        	
        				java.lang.Character.isDigit(next)) {
        			// 2 + -3 ���� c�� '-'�̴�.
        			
        			if (prev==')') {
        				// (byte)-32 ���� c.c�� -�̴�.
        				int rightPairIndex = mBuffer.count-1;
        				rightPairIndex = SkipBlank(mBuffer, true, 0, rightPairIndex-1);
        				if (rightPairIndex==21885 || rightPairIndex==21886) {
        					int a;
        					a=0;
        					a++;
        				}
        				int leftPairIndex = CompilerHelper.CheckParenthesis(mBuffer, "(", ")", 0, rightPairIndex, true);
        				if (leftPairIndex==-1) {
        					// ��ȣ�� �ƴ϶� �����ڷ� ó���ϱ� ���� �ƹ� �ϵ� ���Ѵ�.
        				}
        				else {
	        				int indexRightPairOfTemplate = SkipBlank(mBuffer, true, 0, rightPairIndex-1);
	        				if (indexRightPairOfTemplate==-1) {
	        					// ��ȣ�� �ƴ϶� �����ڷ� ó���ϱ� ���� �ƹ� �ϵ� ���Ѵ�.
	        				}
	        				else {
		        				int prevTypeIndex;
		        				int typeIndex;
		        				if (mBuffer.getItem(indexRightPairOfTemplate).equals(">")) {
		        					Template template = new Template();
		        					typeIndex = IsType(mBuffer, true, indexRightPairOfTemplate, template);
		        				}
		        				else {
		        					typeIndex = IsType(mBuffer, true, indexRightPairOfTemplate, null);
		        				}
		        				if (typeIndex==-1) {
		        					// ��ȣ�� �ƴ϶� �����ڷ� ó���ϱ� ���� �ƹ� �ϵ� ���Ѵ�.
		        				}
		        				else {
			        				prevTypeIndex = SkipBlank(mBuffer, true, 0, typeIndex-1);
			        				if (prevTypeIndex==leftPairIndex) {
			        					int idIndex = SkipBlank(mBuffer, true, 0, leftPairIndex-1);
			        					if (this.IsIdentifier(mBuffer.getItem(idIndex))) {
			        						// Ÿ��ĳ��Ʈ�� �ƴ϶� �Լ�ȣ���̴�. func(a)+1���� c.c�� +�̴�.
			        						// ��ȣ�� �ƴ϶� �����ڷ� ó���ϱ� ���� �ƹ� �ϵ� ���Ѵ�.
			        					}
			        					else { // Ÿ��ĳ��Ʈ�̹Ƿ� ��ȣ�̴�.
			        						// (byte)-32 ���� c.c�� -�̴�.
				        					if (strPutted==false) { // ������ �����Ѵ�.
				    	        				isSignalOfPosOrNeg = true;
				    	            			word_wchar.add(c);
				    	            		}
				    	            		else {
				    	            			str_wchar.add(c);
				    	            		}
			        					}
			        				} 
			        				else { // ��ȣ�� �ƴ϶� �����ڷ� ó���ϱ� ���� �ƹ� �ϵ� ���Ѵ�.
			        					
			        				}
		        				}//typeIndex�� -1�� �ƴϴ�.
	        				}//indexRightPairOfTemplate�� -1�� �ƴϴ�.
        				}//leftPairIndex�� -1�� �ƴϴ�.
        				
        			}//if (prev==')') {
        			else {    // �Ϲ����� ���� ��ȣ�� ó���Ѵ�.			
	        			if (strPutted==false) { // ������ �����Ѵ�.
	        				isSignalOfPosOrNeg = true;
	            			word_wchar.add(c);
	            		}
	            		else {
	            			str_wchar.add(c);
	            		}
        			}
        		}//if ( (prev=='=' || prev=='(' || prev=='[' || prev=='{' || prev==',' || prev==')' || CompilerHelper.IsOperator(prev)) &&
        		*/
        		// -, +�� �������� ���
        		if (!isSignalOfPosOrNeg) {
        			if (!strPutted)
                    {
                        //if (i > 0 && Character.isLetterOrDigit(input.charAt(i - 1).c))    // ���ڳ� ���� �ֱ�
                    	if (word==null && word_wchar.count>0)
                        {
                        	word = new CodeString(word_wchar.getItems(), word_wchar.count);
                            PutTomBuffer(mBuffer, word);
                            word_wchar.reset2();
                            word = null;
                        }
                        CodeChar[] cs = {input.charAt(i)};	// Separator�ֱ�
                        PutTomBuffer(mBuffer, new CodeString(cs, cs.length));
                    }
                    else
                    {
                    	str_wchar.add(input.charAt(i));
                    }
        		}
        		
        	}
			// ����, �����ΰ��
        	else if (c.c!='"' && c.c!='\'' && CompilerHelper.IsSeparator(c.c)==false/* && IsBlank(c.c)==false*/) {
        		if (strPutted==false) {
        			word_wchar.add(c);
        		}
        		else {
        			str_wchar.add(c);
        		}
        	}
			
        	// �Ǽ������ ���, �Ҽ����յڿ� ������ �־�� �ȵȴ�. 1.f ����
            else if (c.c == '.' && 
            		(i > 0 && java.lang.Character.isDigit(input.charAt(i - 1).c)) && 
            		(i < input.length() - 1 && java.lang.Character.isDigit(input.charAt(i + 1).c) 
            				/*|| input.charAt(i + 1).c=='f' || input.charAt(i + 1).c=='d'*/))
            {
                if (!strPutted)
                {
                	word_wchar.add(input.charAt(i));
                }
                else
                {
                	str_wchar.add(input.charAt(i));
                }
            }
        	
           
            // �ο��ȣ���� ���ڿ�, �ּ����� ���ڿ��� �����Ѵ�.
            else if (c.c == '"' && CompilerHelper.IsComment(c)==false)
            {
                if (!strPutted)
                {
                    //if (i > 0 && Character.isLetterOrDigit(input.charAt(i - 1).c) )  // ���ڳ� ���� �ֱ�
                	if (word==null && word_wchar.count>0)
                    {
                        word = new CodeString(word_wchar.getItems(), word_wchar.count);
                        PutTomBuffer(mBuffer, word);
                        word_wchar.reset2();
                        word = null;
                        
                    }
                    str_wchar.add(input.charAt(i));
                    strPutted = true;
                    isStrOrChar = true;
                }
                else //if (isStrOrChar)
                {
                	if (c.c=='c') {
                		int a;
                		a=0;
                		a++;
                	}
                	
                	// �ο빮�ڿ��� ���� ", �� "\", '\"' �� ���Ѵ�.
                	// String a = "\"; // ��Ʈ�� ����
                	// char ch = '\'; // char ����
                	// String test1 = "c:\"; // ��Ʈ�� ����
                	// String test2 = "c:\\";  // ����
                	if ((str_wchar.count-1>=0 && str_wchar.getItem(str_wchar.count-1).c=='\\') && 
                			(str_wchar.count-2>=0 && str_wchar.getItem(str_wchar.count-2).c!='\\')) {
                		str_wchar.add(input.charAt(i));
                	}
                	else if (isStrOrChar==false) { // '"'
                		str_wchar.add(input.charAt(i));
                	}
                	// "\\" ��, �ο��ȣ�� ��
                	else {
                		str_wchar.add(input.charAt(i));                    	
                        str = new CodeString(str_wchar.getItems(), str_wchar.count);
                        str.setType(CodeStringType.Constant);
                        str.setColor(Compiler.keywordColor);
                        
                        PutTomBuffer(mBuffer, str);
                        str_wchar.reset2();
                        strPutted = false;
                	}
                }
            }
            
            else if (c.c == '\''  && CompilerHelper.IsComment(c)==false)
            {
                if (!strPutted && language!=Language.Html)
                {
                    //if (i > 0 && Character.isLetterOrDigit(input.charAt(i - 1).c) )  // ���ڳ� ���� �ֱ�
                	if (word==null && word_wchar.count>0)
                    {
                        word = new CodeString(word_wchar.getItems(), word_wchar.count);
                        PutTomBuffer(mBuffer, word);
                        word_wchar.reset2();
                        word = null;
                        
                    }
                    str_wchar.add(input.charAt(i));
                    strPutted = true;
                    isStrOrChar = false;
                }
                else //if (!strPutted && language!=Language.Html)
                {
                	// �������� ��� �ο빮�� �ƴѵ��� '�� ���̴� ��찡 �ִ�.
                	if (language==Language.Html) {
                		if (!strPutted) {
                			if (word==null && word_wchar.count>0)
                            {
                                word = new CodeString(word_wchar.getItems(), word_wchar.count);
                                PutTomBuffer(mBuffer, word);
                                word_wchar.reset2();
                                word = null;
                                
                            }
                			CodeChar[] cs = {input.charAt(i)};	// ' �ֱ�
                            PutTomBuffer(mBuffer, new CodeString(cs, cs.length));
                            strPutted = false;
                		}
                	}
                	else { // strPutted==true
	                	// �ο빮�ڿ��� ���� ', �� '\''�� ���Ѵ�.
	                	if ((str_wchar.count-1>=0 && str_wchar.getItem(str_wchar.count-1).c=='\\') && 
	                			(str_wchar.count-2>=0 && str_wchar.getItem(str_wchar.count-2).c!='\\')) {
	                		str_wchar.add(input.charAt(i));
	                	}
	                	else if (isStrOrChar) { // "'"
	                		str_wchar.add(input.charAt(i));
	                	}
	                	// '\\' ��, �ο��ȣ�� ��
	                	else {
	                		str_wchar.add(input.charAt(i));                    	
	                        str = new CodeString(str_wchar.getItems(), str_wchar.count);
	                        str.setType(CodeStringType.Constant);
	                        str.setColor(Compiler.keywordColor);
	                        PutTomBuffer(mBuffer, str);
	                        str_wchar.reset2();
	                        strPutted = false;
	                	}
                	}
                }//else //if (isStrOrChar==false)
            }// else if (c.c == '\''  && CompilerHelper.IsComment(c)==false)
			
            else if (input.charAt(i).c=='\\' && 
            		(i+1<input.length() && input.charAt(i+1).c=='\\') && 
            		CompilerHelper.IsComment(c)==false)   { 
            	
            	
            	if (!strPutted)
                { // ���丮 ��� ����
                    // ���ڳ� ���� �ֱ�
                	if (word==null && word_wchar.count>0)
                    {
                    	word = new CodeString(word_wchar.getItems(), word_wchar.count);
                        PutTomBuffer(mBuffer, word);
                        word_wchar.reset2();
                        word = null;
                    }
                    CodeChar[] cs = {input.charAt(i)};	// Separator�ֱ�
                    PutTomBuffer(mBuffer, new CodeString(cs, cs.length));
                    
                    i++; // �ڿ� ������ '\' �� �ǳʶڴ�.
                }
                else
                {
                	str_wchar.add(input.charAt(i));
                }
            	
            	
            	
            }
			

            // Separator : �Ǽ������ ��� �Ҽ���, ������ ���� ��ȣ�� ������ 
        	// ������, ����, �����ݷ�, �ݷ� ��Ÿ ��� 
            else /*if (IsSeparator(input.charAt(i)))*/
            {
            	//CodeChar c = input.charAt(i);
            	if (c.c=='\\') {
            		int a;
            		a=0;
            		a++;
            	}
            	if (c.c=='@') {
            		int a;
            		a=0;
            		a++;
            	}
                if (!strPutted)
                {
                    //if (i > 0 && Character.isLetterOrDigit(input.charAt(i - 1).c))    // ���ڳ� ���� �ֱ�
                	if (word==null && word_wchar.count>0)
                    {
                    	word = new CodeString(word_wchar.getItems(), word_wchar.count);
                        PutTomBuffer(mBuffer, word);
                        word_wchar.reset2();
                        word = null;
                    }
                    CodeChar[] cs = {input.charAt(i)};	// Separator�ֱ�
                    PutTomBuffer(mBuffer, new CodeString(cs, cs.length));
                }
                else
                {
                	str_wchar.add(input.charAt(i));
                }
            }//else /*if (IsSeparator(input.charAt(i)))*/

        	}catch(Exception e) {
        		int debug;
        		debug=0;
        		debug++;
        	}
        } //for (i = 0; i < input.length(); i++)

        if (i == input.length())
        {
            //if (i > 0 && Character.isLetterOrDigit(input.charAt(i - 1).c))
        	if (word==null && word_wchar.count>0)
            // ���ڳ� ������ ������ : �����ڰ� �̹� �� �� �ֱ� ����
            {
            	word = new CodeString(word_wchar.getItems(), word_wchar.count);
                PutTomBuffer(mBuffer, word);
                word = null;
            }
            
            if (strPutted) {
            	//Compiler.errors.add(new Error(mBuffer, mBuffer.count-1, mBuffer.count-1, "invalid leftParenthesis.. RightParenthesis not exist.."));
            }
        }
        
        return mBuffer;

    }
    
    static int PutTomBuffer(HighArray_CodeString mBuffer, CodeString str)
    {
    	int r = -1;
    	try {
    		r = mBuffer.count;
    		if (r>=11735) {
        		int a;
        		a=0;
        		a++;
        	}
    		if (str.str.equals("buttonLatin2.draw")) {
    			int a;
    			a=0;
    			a++;
    		}
    		mBuffer.add(str);
    		return r;
    	}catch(OutOfMemoryError e) {
    		CompilerHelper.showMessage(true, "buffer count:"+mBuffer.count+ " " + e.toString());
    	}
        return r;
    }

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		if (this.mlistOfComments!=null) {
			this.mlistOfComments.reset();
			this.mlistOfComments = null;
		}
	}
}
