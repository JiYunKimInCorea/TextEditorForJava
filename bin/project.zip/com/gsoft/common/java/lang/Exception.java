package com.gsoft.common.java.lang;

public class Exception extends java.lang.Throwable {
	/**Constructs a new exception with null as its detail message.*/
	public Exception() {
		
	}
	/**Constructs a new exception with the specified detail message.*/
	public Exception(java.lang.String message) {
	 		
	}
	/**Constructs a new exception with the specified detail message and cause.*/
	Exception(java.lang.String message, java.lang.Throwable cause) {
		
	}
	/**Constructs a new exception with the specified detail message, cause, suppression enabled or disabled, and writable stack trace enabled or disabled.*/
	Exception(java.lang.String message, java.lang.Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		
	}
	/**Constructs a new exception with the specified cause and a detail message of (cause==null ? null : cause.toString()) (which typically contains the class and detail message of cause).*/
	Exception(java.lang.Throwable cause) {
		
	}
	
}