package com.gsoft.common.java.lang;

public class Math {
	/**Returns the greater of two double values.*/
	static double	max(double a, double b) {
		return 0;
	}
	/**Returns the greater of two float values.*/
	static float	max(float a, float b) {
		return 0;
	}
	/**Returns the greater of two int values.*/
	static int	max(int a, int b) {
		return 0;
	}
	/**Returns the greater of two long values.*/
	static long	max(long a, long b) {
		return 0;
	}
	/**Returns the smaller of two double values.*/
	static double	min(double a, double b) {
		return 0;
	}
	/**Returns the smaller of two float values.*/
	static float	min(float a, float b) {
		return 0;
	}
	/**Returns the smaller of two int values.*/
	static int	min(int a, int b) {
		return 0;
	}
	/**Returns the smaller of two long values.*/
	static long	min(long a, long b) {
		return 0;
	}
	
}
