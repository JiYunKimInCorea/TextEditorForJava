package com.gsoft.common.hardware;

import android.view.KeyCharacterMap;
import android.view.KeyEvent;

import com.gsoft.common.CommonGUI;
import com.gsoft.common.gui.Control;
import com.gsoft.common.gui.IntegrationKeyboard;
import com.gsoft.common.gui.IntegrationKeyboard.Mode;

public class HardwareKeyboard {
	int keyCode;
	KeyEvent event;
	public static boolean isEnglishKeyboard = true;
	
	static KeyCharacterMap keyCharacterMap;
	public String key;
	
	static char[] buf = new char[2];
	static int count = 0;
	
	/** ��������� �ȵ���̵� Ű���� ó���� �ٸ��� ������ �����Ѵ�.
	 * Control.CurrentSystem�� "JAVA"�̸� makeKeyForJava()�� ȣ��,
	 * Control.CurrentSystem�� "ANDROID"�̸� makeKeyForAndroid()�� ȣ���Ѵ�.*/
	private void makeKeyForAndroid(int keyCode, KeyEvent event) {
		int metaState = event.getMetaState();
		//char c = (char) keyCharacterMap.get(keyCode, metaState);
		int unicode = event.getUnicodeChar(metaState); 
		char c = (char)unicode;
		
		boolean isShiftPressed = event.isShiftPressed();
		boolean isAltPressed = event.isAltPressed();
		boolean isCtrlPressed = event.isCtrlPressed();
		
		// 0(keyCode==59, 65)
		if (keyCode==67) {
			key = "BkSp";
			count = 0;
		}
		else if (c=='\n') {
			key = IntegrationKeyboard.Enter;
			count = 0;
		}
		else if (isShiftPressed && keyCode==KeyEvent.KEYCODE_SHIFT_LEFT || keyCode==KeyEvent.KEYCODE_SHIFT_RIGHT) {
			key = "Shift";
			count = 0;
		}
		else if (c=='%') {
			buf[count++] = c;
			char[] arg = {c};
			key = new String(arg);
		}
		else if (c=='h') {				
			if (isEnglishKeyboard) {
				char[] arg = {c};
				key = new String(arg);
			}
			else {
				key = convertToHangul(c);
			}
			if (count>0 && buf[count-1]=='%') {
				isEnglishKeyboard = !isEnglishKeyboard;
				if (isEnglishKeyboard) {
					CommonGUI.keyboard.mode = Mode.Eng;
				}
				else {
					CommonGUI.keyboard.mode = Mode.Hangul;
				}
				//process����(Control.keyboard.mode);
			}
			count = 0;
		}
		else if (keyCode==KeyEvent.KEYCODE_PAGE_UP) {
			key = "PgUp";
			count = 0;
		}
		else if (keyCode==KeyEvent.KEYCODE_PAGE_DOWN) {
			key = "PgDn";
			count = 0;
		}
		else {
			count = 0;
			if (keyCode==KeyEvent.KEYCODE_DPAD_LEFT) {
				key = "Left";// IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			}
			else if (keyCode==KeyEvent.KEYCODE_DPAD_RIGHT) {
				key = "Right";// IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			}
			else if (keyCode==KeyEvent.KEYCODE_DPAD_UP) {
				key = "Up";// IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			}
			else if (keyCode==KeyEvent.KEYCODE_DPAD_DOWN) {
				key = "Down";// IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			}
			else if (keyCode==KeyEvent.KEYCODE_HOME) {
				key = "Home";// IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			}
			else if (keyCode==KeyEvent.KEYCODE_ENDCALL) {
				key = "End";// IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			}
			else if (unicode==65535 && !isShiftPressed) { // Window Ű, ����Ű ��
				key = IntegrationKeyboard.Shift;
				count = 0;
			}
			else {
				if (isCtrlPressed) { // Ű���� ���ӱ�
					IntegrationKeyboard.isCtrlPressed = true;
					if (keyCode==KeyEvent.KEYCODE_Z) {//undo
						key = new String("Z");
					}
					else if (keyCode==KeyEvent.KEYCODE_Y) {//redo
						key = new String("Y");
					}
					else if (keyCode==KeyEvent.KEYCODE_F) {//find/replace
						key = new String("F");
					}
					else if (keyCode==KeyEvent.KEYCODE_C) {//copy
						key = new String("C");
					}
					else if (keyCode==KeyEvent.KEYCODE_X) {//cut
						key = new String("X");
					}
					else if (keyCode==KeyEvent.KEYCODE_V) {//paste
						key = new String("V");
					}
					else if (keyCode==KeyEvent.KEYCODE_A) {//select all
						key = new String("A");
					}
				}//if (isCtrlPressed) { // Ű���� ���ӱ�
				else if (isAltPressed) { // Ű���� ���ӱ�
					IntegrationKeyboard.isAltPressed = true;
				}
				else { // �Ϲ����� Ű
					if (isEnglishKeyboard) {
						char[] arg = {c};
						key = new String(arg);
					}
					else {
						key = convertToHangul(c);
					}
				}// �Ϲ����� Ű
			}//else
			/*count = 0;
			if (isEnglishKeyboard) {
				char[] arg = {c};
				key = new String(arg);
			}
			else {
				key = convertToHangul(c);
			}*/
		}//else
	}
	
	
	
	/** ��������� �ȵ���̵� Ű���� ó���� �ٸ��� ������ �����Ѵ�.
	 * Control.CurrentSystem�� "JAVA"�̸� makeKeyForJava()�� ȣ��,
	 * Control.CurrentSystem�� "ANDROID"�̸� makeKeyForAndroid()�� ȣ���Ѵ�.*/
	private void makeKeyForJava(int keyCode, KeyEvent event) {
		
		IntegrationKeyboard.isCtrlPressed = false;
		IntegrationKeyboard.isAltPressed = false;
		
		int metaState = event.getMetaState();
		//char c = (char) keyCharacterMap.get(keyCode, metaState);
		int unicode = event.getUnicodeChar(metaState); 
		char c = (char)unicode;
		boolean isShiftPressed = event.isShiftPressed();
		boolean isAltPressed = event.isAltPressed();
		boolean isCtrlPressed = event.awtKeyEvent.isControlDown();
		
		if (c=='1') {
			int a;
			a=0;
			a++;
		}
		
		int awtKeyCode = event.awtKeyEvent.getKeyCode();
		
		// 0(keyCode==59, 65)
		if (keyCode==KeyEvent.KEYCODE_BACK) {
			key = IntegrationKeyboard.BackSpace;
			count = 0;
		}
		else if (keyCode==KeyEvent.KEYCODE_DEL) {
			key = IntegrationKeyboard.Delete;
			count = 0;
		}
		else if (c=='\n' || keyCode==KeyEvent.KEYCODE_ENTER) {
			key = IntegrationKeyboard.Enter;
			count = 0;
		}
		
		else if (isShiftPressed && awtKeyCode==java.awt.event.KeyEvent.VK_SPACE) {
			isEnglishKeyboard = !isEnglishKeyboard;
			
			if (isEnglishKeyboard) { // �ѱ۸�忡�� �������� �ٲ��
				if (IntegrationKeyboard.Hangul.mode != 
						IntegrationKeyboard.Hangul.Mode.None) { 
					// �ѱ��� �������϶��� Ŀ���� ����
					IntegrationKeyboard.Hangul.forwardCursor();
				}
				IntegrationKeyboard.Hangul.resetBuffer();
				IntegrationKeyboard.Hangul.mode = IntegrationKeyboard.Hangul.Mode.None;
				
				CommonGUI.keyboard.mode = Mode.Eng;
			}
			else { // ������忡�� �ѱ۸��� �ٲ��
				IntegrationKeyboard.Hangul.resetBuffer();
				CommonGUI.keyboard.mode = Mode.Hangul;
			}
			count = 0;
			
			key = IntegrationKeyboard.Shift;
			
			//IntegrationKeyboard.Hangul.mode = IntegrationKeyboard.Hangul.Mode.None;
			//IntegrationKeyboard.Hangul.isNextToCursor = true;
		}
		
		else if (unicode==65535 && isShiftPressed) {
			key = IntegrationKeyboard.Shift;
			count = 0;
		}
		
		
		
		
		else if (c=='%') {
			count = 0;
			buf[count++] = c;
			char[] arg = {c};
			key = new String(arg);
		}
		else if (c=='h') {				
			if (isEnglishKeyboard) {
				char[] arg = {c};
				key = new String(arg);
			}
			else {
				key = convertToHangul(c);
			}
			if (count>0 && buf[count-1]=='%') {
				isEnglishKeyboard = !isEnglishKeyboard;
				if (isEnglishKeyboard) {
					CommonGUI.keyboard.mode = Mode.Eng;
				}
				else {
					CommonGUI.keyboard.mode = Mode.Hangul;
				}				
				//process����(Control.keyboard.mode);
			}
			count = 0;
		}
		else if (keyCode==KeyEvent.KEYCODE_PAGE_UP) {
			key = "PgUp";  // IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			count = 0;
		}
		else if (keyCode==KeyEvent.KEYCODE_PAGE_DOWN) {
			key = "PgDn";// IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			count = 0;
		}
		else {
			count = 0;
			awtKeyCode = event.awtKeyEvent.getKeyCode();
			if (awtKeyCode==java.awt.event.KeyEvent.VK_LEFT) {
				key = "Left";// IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			}
			else if (awtKeyCode==java.awt.event.KeyEvent.VK_RIGHT) {
				key = "Right";// IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			}
			else if (awtKeyCode==java.awt.event.KeyEvent.VK_UP) {
				key = "Up";// IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			}
			else if (awtKeyCode==java.awt.event.KeyEvent.VK_DOWN) {
				key = "Down";// IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			}
			else if (awtKeyCode==java.awt.event.KeyEvent.VK_HOME) {
				key = "Home";// IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			}
			else if (awtKeyCode==java.awt.event.KeyEvent.VK_END) {
				key = "End";// IntegrationKeyboard.SpecialKeys�� �����Ѵ�.
			}
			else if (unicode==65535 && !isShiftPressed) { // Window Ű, ����Ű ��
				key = IntegrationKeyboard.Shift;
				count = 0;
			}
			else {
				if (isCtrlPressed) { // Ű���� ���ӱ�
					IntegrationKeyboard.isCtrlPressed = true;
					if (awtKeyCode==java.awt.event.KeyEvent.VK_Z) {//undo
						key = new String("Z");
					}
					else if (awtKeyCode==java.awt.event.KeyEvent.VK_Y) {//redo
						key = new String("Y");
					}
					else if (awtKeyCode==java.awt.event.KeyEvent.VK_F) {//find/replace
						key = new String("F");
					}
					else if (awtKeyCode==java.awt.event.KeyEvent.VK_C) {//copy
						key = new String("C");
					}
					else if (awtKeyCode==java.awt.event.KeyEvent.VK_X) {//cut
						key = new String("X");
					}
					else if (awtKeyCode==java.awt.event.KeyEvent.VK_V) {//paste
						key = new String("V");
					}
					else if (awtKeyCode==java.awt.event.KeyEvent.VK_A) {//select all
						key = new String("A");
					}
				}//if (isCtrlPressed) { // Ű���� ���ӱ�
				else if (isAltPressed) { // Ű���� ���ӱ�
					IntegrationKeyboard.isAltPressed = true;
				}
				else { // �Ϲ����� Ű
					if (isEnglishKeyboard) {
						char[] arg = {c};
						key = new String(arg);
					}
					else {
						key = convertToHangul(c);
					}
				}// �Ϲ����� Ű
			}//else
		}//else
	}
	
	/** key �� �����.*/
	public HardwareKeyboard(int keyCode, KeyEvent event) {
		this.keyCode = keyCode;
		this.event = event;
		
		if (CommonGUI.keyboard.getHides()==false) {
			CommonGUI.keyboard.setHides(true);
		}
		
		int deviceId = event.getDeviceId();
		if (keyCharacterMap==null) {
			keyCharacterMap = KeyCharacterMap.load(deviceId);
		}
		
		if (Control.CurrentSystem.equals(Control.CurrentSystemIsJava)) {
			this.makeKeyForJava(keyCode, event);
		}
		else if (Control.CurrentSystem.equals(Control.CurrentSystemIsAndroid)) {
			this.makeKeyForAndroid(keyCode, event);
		} 
		else {
			this.makeKeyForJava(keyCode, event);
		}
	}
	
	String convertToHangul(char c) {
		switch (c) {
		case 'a': return "��";
		case 'b': return "��";
		case 'c': return "��";
		case 'd': return "��";
		case 'e': return "��";
		case 'f': return "��";
		case 'g': return "��";
		case 'h': return "��";
		case 'i': return "��";
		case 'j': return "��";
		case 'k': return "��";
		case 'l': return "��";
		case 'm': return "��";
		case 'n': return "��";
		case 'o': return "��";
		case 'p': return "��";
		case 'q': return "��";
		case 'r': return "��";
		case 's': return "��";
		case 't': return "��";
		case 'u': return "��";
		case 'v': return "��";
		case 'w': return "��";
		case 'x': return "��";
		case 'y': return "��";
		case 'z': return "��";
		
		case 'A': return "��";
		case 'B': return "��";
		case 'C': return "��";
		case 'D': return "��";
		case 'E': return "��";
		case 'F': return "��";
		case 'G': return "��";
		case 'H': return "��";
		case 'I': return "��";
		case 'J': return "��";
		case 'K': return "��";
		case 'L': return "��";
		case 'M': return "��";
		case 'N': return "��";
		case 'O': return "��";
		case 'P': return "��";
		case 'Q': return "��";
		case 'R': return "��";
		case 'S': return "��";
		case 'T': return "��";
		case 'U': return "��";
		case 'V': return "��";
		case 'W': return "��";
		case 'X': return "��";
		case 'Y': return "��";
		case 'Z': return "��";			
		}
		char[] r = {c};
		return new String(r);
	}
	
}