package com.gsoft.common;

public class Array {
	int dimension;
	int length;
	String fullnameElementType;
	
	
}
